package com.evcharging.model;

public enum UserRole {
    ADMIN,
    EV_DRIVER
}
