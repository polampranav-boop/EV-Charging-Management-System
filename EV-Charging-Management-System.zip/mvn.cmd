@echo off
"C:\Users\ADMIN\apache-maven-3.9.9\bin\mvn.cmd" %*
