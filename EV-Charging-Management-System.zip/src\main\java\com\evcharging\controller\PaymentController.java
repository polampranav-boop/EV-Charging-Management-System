package com.evcharging.controller;

import com.evcharging.dto.PaymentRequestDto;
import com.evcharging.dto.PaymentResponseDto;
import com.evcharging.model.Invoice;
import com.evcharging.model.PaymentType;
import com.evcharging.service.BillingService;
import com.evcharging.service.PaymentService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/payments")
@CrossOrigin(origins = "*")
public class PaymentController {

    private final PaymentService paymentService;
    private final BillingService billingService;

    public PaymentController(PaymentService paymentService, BillingService billingService) {
        this.paymentService = paymentService;
        this.billingService = billingService;
    }

    @PostMapping("/process")
    public ResponseEntity<PaymentResponseDto> processPayment(@Valid @RequestBody PaymentRequestDto request) {
        PaymentResponseDto response = paymentService.processPayment(request);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/estimate")
    public ResponseEntity<Map<String, Object>> estimatePayment(
            @RequestParam Long invoiceId,
            @RequestParam PaymentType paymentType) {
        return ResponseEntity.ok(paymentService.calculateEstimateWithMethod(invoiceId, paymentType));
    }

    @GetMapping("/calculate-estimate")
    public ResponseEntity<Map<String, Object>> calculateQuickEstimate(
            @RequestParam(required = false) Double unitsKwh,
            @RequestParam(required = false) Double ratePerKwh) {
        return ResponseEntity.ok(billingService.calculateEstimate(unitsKwh, ratePerKwh));
    }

    @GetMapping("/invoices/{id}")
    public ResponseEntity<Invoice> getInvoice(@PathVariable Long id) {
        return ResponseEntity.ok(billingService.getInvoiceById(id));
    }

    @GetMapping("/invoices/driver/{driverId}")
    public ResponseEntity<List<Invoice>> getDriverInvoices(@PathVariable Long driverId) {
        return ResponseEntity.ok(billingService.getInvoicesByDriver(driverId));
    }

    @GetMapping("/invoices")
    public ResponseEntity<List<Invoice>> getAllInvoices() {
        return ResponseEntity.ok(billingService.getAllInvoices());
    }
}
