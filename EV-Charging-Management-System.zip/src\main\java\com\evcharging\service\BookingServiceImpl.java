package com.evcharging.service;

import com.evcharging.dto.BookingRequestDto;
import com.evcharging.exception.InvalidBookingException;
import com.evcharging.exception.ResourceNotFoundException;
import com.evcharging.exception.SlotUnavailableException;
import com.evcharging.model.*;
import com.evcharging.repository.BookingRepository;
import com.evcharging.repository.ChargerRepository;
import com.evcharging.repository.EVDriverRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.UUID;

@Service
@Transactional
public class BookingServiceImpl implements BookingService {

    private final BookingRepository bookingRepository;
    private final EVDriverRepository driverRepository;
    private final ChargerRepository chargerRepository;

    public BookingServiceImpl(BookingRepository bookingRepository,
                              EVDriverRepository driverRepository,
                              ChargerRepository chargerRepository) {
        this.bookingRepository = bookingRepository;
        this.driverRepository = driverRepository;
        this.chargerRepository = chargerRepository;
    }

    @Override
    public Booking createBooking(BookingRequestDto request) {
        EVDriver driver = driverRepository.findById(request.getDriverId())
                .orElseThrow(() -> new ResourceNotFoundException("Driver not found with ID: " + request.getDriverId()));

        Charger charger = chargerRepository.findById(request.getChargerId())
                .orElseThrow(() -> new ResourceNotFoundException("Charger not found with ID: " + request.getChargerId()));

        if (charger.getStatus() == ChargerStatus.MAINTENANCE || charger.getStatus() == ChargerStatus.OUT_OF_SERVICE) {
            throw new SlotUnavailableException("Selected charger is currently in " + charger.getStatus() + " mode and cannot be reserved.");
        }

        LocalDateTime start = request.getStartTime();
        int minutes = (request.getDurationMinutes() != null && request.getDurationMinutes() > 0)
                ? request.getDurationMinutes() : 45;
        LocalDateTime end = start.plusMinutes(minutes);

        if (start.isBefore(LocalDateTime.now().minusMinutes(2))) {
            throw new InvalidBookingException("Booking start time cannot be in the past.");
        }

        // Check for conflicting reservations for this charger
        List<Booking> conflicts = bookingRepository.findConflictingBookings(charger.getId(), start, end);
        if (!conflicts.isEmpty()) {
            throw new SlotUnavailableException("This charger is already reserved for the chosen time interval ("
                    + start.format(DateTimeFormatter.ofPattern("HH:mm")) + " - "
                    + end.format(DateTimeFormatter.ofPattern("HH:mm")) + "). Please select another slot or charger.");
        }

        // Calculate estimated energy (kWh) and cost
        // Energy (kWh) = Power (kW) * (duration / 60) * 0.85 (average acceptance efficiency)
        double durationHours = minutes / 60.0;
        double estimatedKwh = charger.getPowerRatingKw() * durationHours * 0.85;
        if (request.getTargetBatteryKwh() != null && request.getTargetBatteryKwh() > 0) {
            estimatedKwh = Math.min(estimatedKwh, request.getTargetBatteryKwh());
        }
        estimatedKwh = Math.round(estimatedKwh * 100.0) / 100.0;

        double baseCost = estimatedKwh * charger.getRatePerKwh();
        double totalWithGst = baseCost * 1.18; // 18% GST
        BigDecimal estimatedCost = BigDecimal.valueOf(totalWithGst).setScale(2, RoundingMode.HALF_UP);

        String reference = "BK-" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"))
                + "-" + UUID.randomUUID().toString().substring(0, 5).toUpperCase();

        Booking booking = new Booking(
                reference,
                driver,
                charger.getStation(),
                charger,
                start,
                end,
                minutes,
                estimatedKwh,
                estimatedCost
        );

        return bookingRepository.save(booking);
    }

    @Override
    public Booking cancelBooking(Long bookingId, String reason) {
        Booking booking = getBookingById(bookingId);
        booking.cancel(reason);
        return bookingRepository.save(booking);
    }

    @Override
    @Transactional(readOnly = true)
    public Booking getBookingById(Long id) {
        return bookingRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found with ID: " + id));
    }

    @Override
    @Transactional(readOnly = true)
    public Booking getBookingByReference(String bookingReference) {
        return bookingRepository.findByBookingReference(bookingReference)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found with reference: " + bookingReference));
    }

    @Override
    @Transactional(readOnly = true)
    public List<Booking> getBookingsByDriver(Long driverId) {
        return bookingRepository.findByDriverIdOrderByStartTimeDesc(driverId);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Booking> getAllBookings() {
        return bookingRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public List<Booking> getBookingsByStation(Long stationId) {
        return bookingRepository.findByStationIdOrderByStartTimeDesc(stationId);
    }
}
