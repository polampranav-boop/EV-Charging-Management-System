package com.evcharging.service;

import com.evcharging.dto.UserRegistrationDto;
import com.evcharging.exception.ResourceNotFoundException;
import com.evcharging.model.*;
import com.evcharging.repository.AdminRepository;
import com.evcharging.repository.EVDriverRepository;
import com.evcharging.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.util.List;

@Service
@Transactional
public class UserService {

    private final UserRepository userRepository;
    private final EVDriverRepository driverRepository;
    private final AdminRepository adminRepository;

    public UserService(UserRepository userRepository,
                       EVDriverRepository driverRepository,
                       AdminRepository adminRepository) {
        this.userRepository = userRepository;
        this.driverRepository = driverRepository;
        this.adminRepository = adminRepository;
    }

    @Transactional(readOnly = true)
    public User getUserById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with ID: " + id));
    }

    @Transactional(readOnly = true)
    public User getUserByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with email: " + email));
    }

    @Transactional(readOnly = true)
    public List<EVDriver> getAllDrivers() {
        return driverRepository.findAll();
    }

    @Transactional(readOnly = true)
    public List<Admin> getAllAdmins() {
        return adminRepository.findAll();
    }

    public User registerUser(UserRegistrationDto dto) {
        if (userRepository.existsByEmail(dto.getEmail())) {
            throw new IllegalArgumentException("User with email " + dto.getEmail() + " already exists.");
        }

        if (dto.getRole() == UserRole.ADMIN) {
            Admin admin = new Admin(
                    dto.getName(),
                    dto.getEmail(),
                    dto.getPhone(),
                    dto.getPassword(),
                    dto.getDepartment() != null ? dto.getDepartment() : "Charging Operations",
                    dto.getEmployeeCode() != null ? dto.getEmployeeCode() : "ADM-" + System.currentTimeMillis() % 10000,
                    dto.getAdminLevel() != null ? dto.getAdminLevel() : "Senior Operator"
            );
            return adminRepository.save(admin);
        } else {
            EVDriver driver = new EVDriver(
                    dto.getName(),
                    dto.getEmail(),
                    dto.getPhone(),
                    dto.getPassword(),
                    dto.getVehicleModel() != null ? dto.getVehicleModel() : "Tata Nexon EV Max",
                    dto.getVehicleRegistrationNumber() != null ? dto.getVehicleRegistrationNumber() : "TS 09 EV 2026",
                    dto.getBatteryCapacityKwh() != null ? dto.getBatteryCapacityKwh() : 40.5,
                    dto.getPreferredConnectorType() != null ? dto.getPreferredConnectorType() : ConnectorType.CCS2,
                    dto.getInitialWalletBalance() != null ? dto.getInitialWalletBalance() : BigDecimal.valueOf(500.00)
            );
            return driverRepository.save(driver);
        }
    }

    public EVDriver rechargeWallet(Long driverId, BigDecimal amount) {
        EVDriver driver = driverRepository.findById(driverId)
                .orElseThrow(() -> new ResourceNotFoundException("Driver not found with ID: " + driverId));
        driver.creditWallet(amount);
        return driverRepository.save(driver);
    }

    public EVDriver updateDriverVehicle(Long driverId, String vehicleModel, String registrationNumber,
                                        Double batteryCapacity, ConnectorType connectorType) {
        EVDriver driver = driverRepository.findById(driverId)
                .orElseThrow(() -> new ResourceNotFoundException("Driver not found with ID: " + driverId));
        if (vehicleModel != null) driver.setVehicleModel(vehicleModel);
        if (registrationNumber != null) driver.setVehicleRegistrationNumber(registrationNumber);
        if (batteryCapacity != null) driver.setBatteryCapacityKwh(batteryCapacity);
        if (connectorType != null) driver.setPreferredConnectorType(connectorType);
        return driverRepository.save(driver);
    }

    public EVDriver loginOrRegisterDriver(String name, String email, String phone, String vehicleModel, String registrationNumber) {
        if (email == null || email.trim().isEmpty()) {
            throw new IllegalArgumentException("Email address is required for logging in.");
        }
        String cleanEmail = email.trim().toLowerCase();
        java.util.Optional<EVDriver> existingOpt = driverRepository.findByEmail(cleanEmail);
        if (existingOpt.isPresent()) {
            EVDriver driver = existingOpt.get();
            if (name != null && !name.trim().isEmpty()) driver.setName(name.trim());
            if (phone != null && !phone.trim().isEmpty()) driver.setPhone(phone.trim());
            if (vehicleModel != null && !vehicleModel.trim().isEmpty()) driver.setVehicleModel(vehicleModel.trim());
            if (registrationNumber != null && !registrationNumber.trim().isEmpty()) driver.setVehicleRegistrationNumber(registrationNumber.trim());
            return driverRepository.save(driver);
        }

        String driverName = (name != null && !name.trim().isEmpty()) ? name.trim() : "EV Driver";
        String driverPhone = (phone != null && !phone.trim().isEmpty()) ? phone.trim() : "+91 98765 00000";
        String car = (vehicleModel != null && !vehicleModel.trim().isEmpty()) ? vehicleModel.trim() : "Electric Vehicle";
        String reg = (registrationNumber != null && !registrationNumber.trim().isEmpty()) ? registrationNumber.trim() : "TS 09 EV " + (1000 + (int)(Math.random() * 9000));

        EVDriver newDriver = new EVDriver(
                driverName,
                cleanEmail,
                driverPhone,
                "driver123",
                car,
                reg,
                45.0,
                ConnectorType.CCS2,
                BigDecimal.valueOf(1000.00)
        );
        return driverRepository.save(newDriver);
    }
}
