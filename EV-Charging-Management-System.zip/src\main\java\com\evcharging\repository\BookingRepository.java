package com.evcharging.repository;

import com.evcharging.model.Booking;
import com.evcharging.model.BookingStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Long> {

    Optional<Booking> findByBookingReference(String bookingReference);

    List<Booking> findByDriverIdOrderByStartTimeDesc(Long driverId);

    List<Booking> findByStationIdOrderByStartTimeDesc(Long stationId);

    List<Booking> findByStatusOrderByStartTimeDesc(BookingStatus status);

    @Query("SELECT b FROM Booking b WHERE b.charger.id = :chargerId " +
           "AND b.status IN ('CONFIRMED', 'ACTIVE') " +
           "AND ((b.startTime < :endTime AND b.endTime > :startTime))")
    List<Booking> findConflictingBookings(@Param("chargerId") Long chargerId,
                                         @Param("startTime") LocalDateTime startTime,
                                         @Param("endTime") LocalDateTime endTime);

    long countByStatus(BookingStatus status);
}
