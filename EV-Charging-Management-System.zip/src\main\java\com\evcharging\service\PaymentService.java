package com.evcharging.service;

import com.evcharging.dto.PaymentRequestDto;
import com.evcharging.dto.PaymentResponseDto;
import com.evcharging.exception.PaymentFailedException;
import com.evcharging.exception.ResourceNotFoundException;
import com.evcharging.model.Invoice;
import com.evcharging.model.PaymentType;
import com.evcharging.repository.InvoiceRepository;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * PaymentService coordinates polymorphic payment dispatching.
 * Injects all PaymentProcessor implementations and maps them dynamically.
 */
@Service
public class PaymentService {

    private final InvoiceRepository invoiceRepository;
    private final Map<PaymentType, PaymentProcessor> processorMap = new HashMap<>();

    public PaymentService(InvoiceRepository invoiceRepository, List<PaymentProcessor> processors) {
        this.invoiceRepository = invoiceRepository;
        for (PaymentProcessor processor : processors) {
            processorMap.put(processor.getSupportedPaymentType(), processor);
        }
    }

    public PaymentResponseDto processPayment(PaymentRequestDto request) {
        Invoice invoice = invoiceRepository.findById(request.getInvoiceId())
                .orElseThrow(() -> new ResourceNotFoundException("Invoice not found with ID: " + request.getInvoiceId()));

        if ("PAID".equalsIgnoreCase(invoice.getPaymentStatus())) {
            throw new PaymentFailedException("Invoice #" + invoice.getInvoiceNumber() + " has already been settled.");
        }

        PaymentProcessor processor = processorMap.get(request.getPaymentType());
        if (processor == null) {
            throw new PaymentFailedException("No payment gateway implementation found for method: " + request.getPaymentType());
        }

        return processor.processPayment(invoice, request);
    }

    public Map<String, Object> calculateEstimateWithMethod(Long invoiceId, PaymentType paymentType) {
        Invoice invoice = invoiceRepository.findById(invoiceId)
                .orElseThrow(() -> new ResourceNotFoundException("Invoice not found with ID: " + invoiceId));

        PaymentProcessor processor = processorMap.get(paymentType);
        if (processor == null) {
            throw new PaymentFailedException("Unsupported payment type: " + paymentType);
        }

        BigDecimal fee = processor.calculateConvenienceFee(invoice.getTotalAmount());
        BigDecimal total = invoice.getTotalAmount().add(fee);
        BigDecimal cashback = processor.calculateCashBackBonus(invoice.getTotalAmount());

        Map<String, Object> result = new HashMap<>();
        result.put("invoiceId", invoice.getId());
        result.put("baseTotal", invoice.getTotalAmount());
        result.put("paymentMethod", processor.getGatewayDisplayName());
        result.put("convenienceFee", fee);
        result.put("estimatedCashback", cashback);
        result.put("payableAmount", total);
        return result;
    }
}
