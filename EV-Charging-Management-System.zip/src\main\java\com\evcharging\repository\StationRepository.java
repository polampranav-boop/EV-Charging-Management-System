package com.evcharging.repository;

import com.evcharging.model.Station;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface StationRepository extends JpaRepository<Station, Long> {

    List<Station> findByAreaIgnoreCase(String area);

    @Query("SELECT s FROM Station s WHERE " +
           "LOWER(s.name) LIKE LOWER(CONCAT('%', :query, '%')) OR " +
           "LOWER(s.area) LIKE LOWER(CONCAT('%', :query, '%')) OR " +
           "LOWER(s.city) LIKE LOWER(CONCAT('%', :query, '%')) OR " +
           "LOWER(COALESCE(s.state, '')) LIKE LOWER(CONCAT('%', :query, '%')) OR " +
           "LOWER(s.address) LIKE LOWER(CONCAT('%', :query, '%'))")
    List<Station> searchStations(@Param("query") String query);

    @Query("SELECT DISTINCT s.area FROM Station s ORDER BY s.area ASC")
    List<String> findDistinctAreas();

    @Query("SELECT DISTINCT s.city FROM Station s ORDER BY s.city ASC")
    List<String> findDistinctCities();
}
