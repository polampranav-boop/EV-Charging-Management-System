package com.evcharging.service;

import com.evcharging.dto.ChargerRequestDto;
import com.evcharging.dto.StationRequestDto;
import com.evcharging.exception.ResourceNotFoundException;
import com.evcharging.model.Charger;
import com.evcharging.model.ChargerStatus;
import com.evcharging.model.ConnectorType;
import com.evcharging.model.Station;
import com.evcharging.repository.ChargerRepository;
import com.evcharging.repository.StationRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class StationServiceImpl implements StationService {

    private final StationRepository stationRepository;
    private final ChargerRepository chargerRepository;

    public StationServiceImpl(StationRepository stationRepository, ChargerRepository chargerRepository) {
        this.stationRepository = stationRepository;
        this.chargerRepository = chargerRepository;
    }

    @Override
    @Transactional(readOnly = true)
    public List<Station> getAllStations() {
        return stationRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Station getStationById(Long id) {
        return stationRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Charging station not found with ID: " + id));
    }

    @Override
    @Transactional(readOnly = true)
    public List<Station> searchAndFilterStations(String query, String area, ConnectorType connectorType,
                                                Double minPower, Boolean availableOnly) {
        List<Station> stations;
        if (query != null && !query.trim().isEmpty()) {
            stations = stationRepository.searchStations(query.trim());
        } else if (area != null && !area.trim().isEmpty() && !"ALL".equalsIgnoreCase(area)) {
            stations = stationRepository.findByAreaIgnoreCase(area.trim());
        } else {
            stations = stationRepository.findAll();
        }

        // Apply Java Stream filters (Collections & Streams)
        return stations.stream()
                .filter(station -> {
                    // Filter by Area if both query and area are specified
                    if (area != null && !area.trim().isEmpty() && !"ALL".equalsIgnoreCase(area)) {
                        if (!station.getArea().equalsIgnoreCase(area.trim())) {
                            return false;
                        }
                    }

                    // Filter by Connector Type
                    if (connectorType != null) {
                        boolean hasConnector = station.getChargers().stream()
                                .anyMatch(c -> c.getConnectorType() == connectorType);
                        if (!hasConnector) return false;
                    }

                    // Filter by Minimum Power kW
                    if (minPower != null && minPower > 0) {
                        boolean hasPower = station.getChargers().stream()
                                .anyMatch(c -> c.getPowerRatingKw() >= minPower);
                        if (!hasPower) return false;
                    }

                    // Filter by Available Chargers
                    if (Boolean.TRUE.equals(availableOnly)) {
                        boolean hasAvailable = station.getChargers().stream()
                                .anyMatch(c -> c.getStatus() == ChargerStatus.AVAILABLE);
                        if (!hasAvailable) return false;
                    }

                    return true;
                })
                .collect(Collectors.toList());
    }

    @Override
    public Station createStation(StationRequestDto request) {
        Station station = new Station(
                request.getName(),
                request.getAddress(),
                request.getArea(),
                request.getCity(),
                request.getLatitude(),
                request.getLongitude(),
                request.getOperatingHours(),
                request.getContactPhone(),
                request.getAmenities()
        );
        return stationRepository.save(station);
    }

    @Override
    public Station updateStation(Long id, StationRequestDto request) {
        Station station = getStationById(id);
        station.setName(request.getName());
        station.setAddress(request.getAddress());
        station.setArea(request.getArea());
        station.setCity(request.getCity());
        station.setLatitude(request.getLatitude());
        station.setLongitude(request.getLongitude());
        station.setOperatingHours(request.getOperatingHours());
        station.setContactPhone(request.getContactPhone());
        station.setAmenities(request.getAmenities());
        return stationRepository.save(station);
    }

    @Override
    public void deleteStation(Long id) {
        Station station = getStationById(id);
        stationRepository.delete(station);
    }

    @Override
    public Charger addChargerToStation(ChargerRequestDto request) {
        Station station = getStationById(request.getStationId());
        Charger charger = new Charger(
                request.getIdentifier(),
                request.getConnectorType(),
                request.getPowerRatingKw(),
                request.getRatePerKwh(),
                request.getStatus() != null ? request.getStatus() : ChargerStatus.AVAILABLE,
                station
        );
        station.addCharger(charger);
        return chargerRepository.save(charger);
    }

    @Override
    public Charger updateChargerStatus(Long chargerId, ChargerStatus status) {
        Charger charger = chargerRepository.findById(chargerId)
                .orElseThrow(() -> new ResourceNotFoundException("Charger not found with ID: " + chargerId));
        charger.setStatus(status);
        return chargerRepository.save(charger);
    }

    @Override
    public void deleteCharger(Long chargerId) {
        Charger charger = chargerRepository.findById(chargerId)
                .orElseThrow(() -> new ResourceNotFoundException("Charger not found with ID: " + chargerId));
        Station station = charger.getStation();
        if (station != null) {
            station.removeCharger(charger);
        }
        chargerRepository.delete(charger);
    }

    @Override
    @Transactional(readOnly = true)
    public List<String> getAvailableAreas() {
        return stationRepository.findDistinctAreas();
    }

    @Override
    @Transactional(readOnly = true)
    public List<String> getAvailableCities() {
        return stationRepository.findDistinctCities();
    }
}
