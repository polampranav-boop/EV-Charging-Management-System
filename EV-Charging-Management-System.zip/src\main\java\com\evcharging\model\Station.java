package com.evcharging.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;

/**
 * Station Entity encapsulates an EV Charging Hub.
 * Contains GPS coordinates for Google Maps integration, address, amenities, and connected chargers.
 */
@Entity
@Table(name = "stations")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Station extends BaseEntity {

    @NotBlank(message = "Station name is required")
    @Column(nullable = false, length = 150)
    private String name;

    @NotBlank(message = "Address is required")
    @Column(nullable = false, length = 255)
    private String address;

    @NotBlank(message = "Area/Locality is required")
    @Column(nullable = false, length = 80)
    private String area;

    @NotBlank(message = "City is required")
    @Column(nullable = false, length = 80)
    private String city;

    @Column(length = 80)
    private String state;

    @NotNull(message = "Latitude is required for Google Maps placement")
    @Column(nullable = false)
    private Double latitude;

    @NotNull(message = "Longitude is required for Google Maps placement")
    @Column(nullable = false)
    private Double longitude;

    @Column(name = "operating_hours", length = 80)
    private String operatingHours;

    @Column(name = "contact_phone", length = 30)
    private String contactPhone;

    @Column(length = 255)
    private String amenities;

    @OneToMany(mappedBy = "station", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    @JsonManagedReference
    private List<Charger> chargers = new ArrayList<>();

    public Station() {
        super();
        this.city = "Hyderabad";
        this.state = "Telangana";
        this.operatingHours = "24 Hours";
    }

    public Station(String name, String address, String area, String city, String state,
                   Double latitude, Double longitude, String operatingHours,
                   String contactPhone, String amenities) {
        super();
        this.name = name;
        this.address = address;
        this.area = area;
        this.city = (city != null && !city.isBlank()) ? city : "Hyderabad";
        this.state = (state != null && !state.isBlank()) ? state : "India";
        this.latitude = latitude;
        this.longitude = longitude;
        this.operatingHours = operatingHours != null ? operatingHours : "24 Hours";
        this.contactPhone = contactPhone;
        this.amenities = amenities;
        this.chargers = new ArrayList<>();
    }

    public Station(String name, String address, String area, String city,
                   Double latitude, Double longitude, String operatingHours,
                   String contactPhone, String amenities) {
        this(name, address, area, city, "India", latitude, longitude, operatingHours, contactPhone, amenities);
    }

    // Helper methods for chargers collection management
    public void addCharger(Charger charger) {
        chargers.add(charger);
        charger.setStation(this);
    }

    public void removeCharger(Charger charger) {
        chargers.remove(charger);
        charger.setStation(null);
    }

    // Computed attributes for quick statistics
    public int getTotalChargers() {
        return chargers != null ? chargers.size() : 0;
    }

    public long getAvailableChargersCount() {
        if (chargers == null) return 0;
        return chargers.stream()
                .filter(c -> c.getStatus() == ChargerStatus.AVAILABLE)
                .count();
    }

    public double getMinRatePerKwh() {
        if (chargers == null || chargers.isEmpty()) return 18.0;
        return chargers.stream()
                .mapToDouble(Charger::getRatePerKwh)
                .min()
                .orElse(18.0);
    }

    public double getMaxPowerKw() {
        if (chargers == null || chargers.isEmpty()) return 50.0;
        return chargers.stream()
                .mapToDouble(Charger::getPowerRatingKw)
                .max()
                .orElse(50.0);
    }

    // Encapsulation: Getters and Setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public String getOperatingHours() {
        return operatingHours;
    }

    public void setOperatingHours(String operatingHours) {
        this.operatingHours = operatingHours;
    }

    public String getContactPhone() {
        return contactPhone;
    }

    public void setContactPhone(String contactPhone) {
        this.contactPhone = contactPhone;
    }

    public String getAmenities() {
        return amenities;
    }

    public void setAmenities(String amenities) {
        this.amenities = amenities;
    }

    public List<Charger> getChargers() {
        return chargers;
    }

    public void setChargers(List<Charger> chargers) {
        this.chargers = chargers;
    }
}
