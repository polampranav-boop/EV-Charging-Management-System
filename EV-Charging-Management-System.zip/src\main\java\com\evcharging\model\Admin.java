package com.evcharging.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

/**
 * OOP Inheritance Subclass: Admin
 * Inherits common identity properties from User.
 * Adds administrative clearance and station governance capabilities.
 */
@Entity
@Table(name = "admins")
public class Admin extends User {

    @Column(name = "department", length = 80)
    private String department;

    @Column(name = "employee_code", length = 30)
    private String employeeCode;

    @Column(name = "admin_level", length = 30)
    private String adminLevel;

    public Admin() {
        super();
        this.setRole(UserRole.ADMIN);
    }

    public Admin(String name, String email, String phone, String password,
                 String department, String employeeCode, String adminLevel) {
        super(name, email, phone, password, UserRole.ADMIN);
        this.department = department;
        this.employeeCode = employeeCode;
        this.adminLevel = adminLevel;
    }

    // Polymorphism: Method Overriding
    @Override
    public String getRoleDescription() {
        return "System Administrator (" + (department != null ? department : "Operations") + ") - Full Station & Charger Governance";
    }

    @Override
    public String getDashboardGreeting() {
        return "Admin Portal: Welcome back, " + getName() + " (" + (employeeCode != null ? employeeCode : "ADM") + ")";
    }

    // Encapsulation: Getters and Setters
    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getEmployeeCode() {
        return employeeCode;
    }

    public void setEmployeeCode(String employeeCode) {
        this.employeeCode = employeeCode;
    }

    public String getAdminLevel() {
        return adminLevel;
    }

    public void setAdminLevel(String adminLevel) {
        this.adminLevel = adminLevel;
    }
}
