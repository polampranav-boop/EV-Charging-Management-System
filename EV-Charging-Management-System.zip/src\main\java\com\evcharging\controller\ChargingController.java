package com.evcharging.controller;

import com.evcharging.dto.StartSessionRequestDto;
import com.evcharging.model.ChargingSession;
import com.evcharging.model.Invoice;
import com.evcharging.service.ChargingSimulatorService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/charging")
@CrossOrigin(origins = "*")
public class ChargingController {

    private final ChargingSimulatorService chargingSimulatorService;

    public ChargingController(ChargingSimulatorService chargingSimulatorService) {
        this.chargingSimulatorService = chargingSimulatorService;
    }

    @PostMapping("/start")
    public ResponseEntity<ChargingSession> startSession(@Valid @RequestBody StartSessionRequestDto request) {
        ChargingSession session = chargingSimulatorService.startSession(request);
        return new ResponseEntity<>(session, HttpStatus.CREATED);
    }

    @PostMapping("/{id}/tick")
    public ResponseEntity<ChargingSession> tickSimulation(
            @PathVariable Long id,
            @RequestBody Map<String, Double> progress) {
        Double kwh = progress.get("progressKwh");
        Double battery = progress.get("batteryPercent");
        ChargingSession session = chargingSimulatorService.tickSimulation(id, kwh, battery);
        return ResponseEntity.ok(session);
    }

    @PostMapping("/{id}/stop")
    public ResponseEntity<Invoice> stopSession(@PathVariable Long id) {
        Invoice invoice = chargingSimulatorService.stopSession(id);
        return ResponseEntity.ok(invoice);
    }

    @GetMapping("/{id}")
    public ResponseEntity<ChargingSession> getSession(@PathVariable Long id) {
        return ResponseEntity.ok(chargingSimulatorService.getSessionById(id));
    }

    @GetMapping("/active")
    public ResponseEntity<List<ChargingSession>> getActiveSessions() {
        return ResponseEntity.ok(chargingSimulatorService.getActiveSessions());
    }

    @GetMapping("/driver/{driverId}")
    public ResponseEntity<List<ChargingSession>> getDriverSessions(@PathVariable Long driverId) {
        return ResponseEntity.ok(chargingSimulatorService.getSessionsByDriver(driverId));
    }
}
