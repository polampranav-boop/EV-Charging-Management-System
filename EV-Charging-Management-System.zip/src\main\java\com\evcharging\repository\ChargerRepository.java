package com.evcharging.repository;

import com.evcharging.model.Charger;
import com.evcharging.model.ChargerStatus;
import com.evcharging.model.ConnectorType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ChargerRepository extends JpaRepository<Charger, Long> {
    List<Charger> findByStationId(Long stationId);
    List<Charger> findByStationIdAndStatus(Long stationId, ChargerStatus status);
    List<Charger> findByStatus(ChargerStatus status);
    List<Charger> findByConnectorType(ConnectorType connectorType);
    long countByStatus(ChargerStatus status);
}
