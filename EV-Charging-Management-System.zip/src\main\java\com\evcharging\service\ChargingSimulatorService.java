package com.evcharging.service;

import com.evcharging.dto.StartSessionRequestDto;
import com.evcharging.model.ChargingSession;
import com.evcharging.model.Invoice;
import java.util.List;

public interface ChargingSimulatorService {
    ChargingSession startSession(StartSessionRequestDto request);
    ChargingSession tickSimulation(Long sessionId, Double progressKwh, Double batteryPercent);
    Invoice stopSession(Long sessionId);
    ChargingSession getSessionById(Long sessionId);
    List<ChargingSession> getActiveSessions();
    List<ChargingSession> getSessionsByDriver(Long driverId);
}
