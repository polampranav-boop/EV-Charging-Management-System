package com.evcharging.config;

import com.evcharging.model.*;
import com.evcharging.repository.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

/**
 * DataInitializer seeds a comprehensive Pan-India EV charging network across
 * Delhi NCR, Mumbai, Bengaluru, Hyderabad, Chennai, Pune, Kolkata, Ahmedabad,
 * Jaipur, Chandigarh, Kochi, and highway fast corridors.
 */
@Component
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final AdminRepository adminRepository;
    private final EVDriverRepository driverRepository;
    private final StationRepository stationRepository;
    private final ChargerRepository chargerRepository;
    private final BookingRepository bookingRepository;
    private final ChargingSessionRepository sessionRepository;
    private final InvoiceRepository invoiceRepository;

    public DataInitializer(UserRepository userRepository,
                           AdminRepository adminRepository,
                           EVDriverRepository driverRepository,
                           StationRepository stationRepository,
                           ChargerRepository chargerRepository,
                           BookingRepository bookingRepository,
                           ChargingSessionRepository sessionRepository,
                           InvoiceRepository invoiceRepository) {
        this.userRepository = userRepository;
        this.adminRepository = adminRepository;
        this.driverRepository = driverRepository;
        this.stationRepository = stationRepository;
        this.chargerRepository = chargerRepository;
        this.bookingRepository = bookingRepository;
        this.sessionRepository = sessionRepository;
        this.invoiceRepository = invoiceRepository;
    }

    @Override
    public void run(String... args) {
        if (stationRepository.count() >= 25) {
            return; // Already has comprehensive Indian network seeded
        }

        System.out.println("⚡ Seeding Pan-India Smart EV Charging Network...");

        // 1. Seed Initial Users if needed
        EVDriver driver1;
        if (driverRepository.count() == 0) {
            Admin admin = new Admin(
                    "Vikram Sharma",
                    "admin@evcharge.in",
                    "+91 98490 12345",
                    "admin123",
                    "National EV Grid Operations",
                    "ADM-IND-01",
                    "Chief Station Governor"
            );
            adminRepository.save(admin);

            driver1 = new EVDriver(
                    "Rahul Varma",
                    "rahul@evcharge.in",
                    "+91 98765 43210",
                    "rahul123",
                    "Tata Nexon EV Max",
                    "TS 09 EV 4521",
                    40.5,
                    ConnectorType.CCS2,
                    BigDecimal.valueOf(1450.00)
            );
            driverRepository.save(driver1);

            EVDriver driver2 = new EVDriver(
                    "Sneha Reddy",
                    "sneha@evcharge.in",
                    "+91 98123 45678",
                    "sneha123",
                    "MG ZS EV Excite",
                    "TS 07 EV 8890",
                    50.3,
                    ConnectorType.CCS2,
                    BigDecimal.valueOf(980.00)
            );
            driverRepository.save(driver2);
        } else {
            driver1 = driverRepository.findAll().get(0);
        }

        // Clean slate for complete nationwide network
        chargerRepository.deleteAll();
        stationRepository.deleteAll();

        // -------------------------------------------------------------
        // REGION 1: DELHI NCR (National Capital Region)
        // -------------------------------------------------------------
        createHub("Tata Power EZ Charge - Connaught Place",
                "Outer Circle, Block E, Connaught Place, New Delhi, 110001",
                "Connaught Place", "New Delhi", "Delhi NCR",
                28.6315, 77.2167, "24 Hours Open", "+91 98110 01001",
                "24/7 Security, Restrooms, Cafes, Underground Parking",
                List.of(
                    new ChargerSeed("DEL-CP-01", ConnectorType.CCS2, 60.0, 19.50),
                    new ChargerSeed("DEL-CP-02", ConnectorType.CCS2, 120.0, 22.00),
                    new ChargerSeed("DEL-CP-03", ConnectorType.TYPE_2, 22.0, 16.50)
                ));

        createHub("Jio-bp pulse - Cyber Hub Gurugram",
                "DLF Cyber Hub, DLF Phase 2, Gurugram, Haryana, 122002",
                "Cyber Hub", "Gurugram", "Haryana",
                28.4952, 77.0886, "24 Hours Open", "+91 98110 01002",
                "Food Court, Multiplex, Restrooms, Clean Seating Lounge",
                List.of(
                    new ChargerSeed("GGN-CH-01", ConnectorType.CCS2, 150.0, 22.50),
                    new ChargerSeed("GGN-CH-02", ConnectorType.CCS2, 60.0, 19.00),
                    new ChargerSeed("GGN-CH-03", ConnectorType.TYPE_2, 22.0, 15.50)
                ));

        createHub("Statiq Supercharging Hub - Sector 18 Noida",
                "Near Mall of India, Sector 18, Noida, Uttar Pradesh, 201301",
                "Sector 18", "Noida", "Uttar Pradesh",
                28.5672, 77.3210, "06:00 AM - 11:30 PM", "+91 98110 01003",
                "Shopping Mall Access, Valet, Restrooms, Cafe",
                List.of(
                    new ChargerSeed("NOI-18-01", ConnectorType.CCS2, 120.0, 21.00),
                    new ChargerSeed("NOI-18-02", ConnectorType.CHADEMO, 50.0, 18.00),
                    new ChargerSeed("NOI-18-03", ConnectorType.TYPE_2, 22.0, 15.00)
                ));

        createHub("ChargeZone Ultra-Fast - IGI Airport T3",
                "Multi-Level Car Parking, Terminal 3, IGI Airport, New Delhi, 110037",
                "IGI Airport", "New Delhi", "Delhi NCR",
                28.5562, 77.0999, "24 Hours Open", "+91 98110 01004",
                "Airport Terminal Walkway, 24/7 Surveillance, EV Taxi Lane",
                List.of(
                    new ChargerSeed("DEL-T3-01", ConnectorType.CCS2, 180.0, 24.00),
                    new ChargerSeed("DEL-T3-02", ConnectorType.CCS2, 60.0, 20.00),
                    new ChargerSeed("DEL-T3-03", ConnectorType.GB_T, 15.0, 16.00)
                ));

        // -------------------------------------------------------------
        // REGION 2: MUMBAI & MAHARASHTRA
        // -------------------------------------------------------------
        createHub("Tata Power EZ Charge - BKC G Block",
                "Bandra Kurla Complex, G Block, Bandra East, Mumbai, Maharashtra, 400051",
                "Bandra Kurla Complex", "Mumbai", "Maharashtra",
                19.0657, 72.8687, "24 Hours Open", "+91 98200 02001",
                "Commercial District, Restrooms, High-Speed Wi-Fi, Coffee Shop",
                List.of(
                    new ChargerSeed("BOM-BKC-01", ConnectorType.CCS2, 120.0, 22.00),
                    new ChargerSeed("BOM-BKC-02", ConnectorType.CCS2, 60.0, 19.50),
                    new ChargerSeed("BOM-BKC-03", ConnectorType.TYPE_2, 22.0, 16.00)
                ));

        createHub("Fortum Charge & Drive - Nariman Point",
                "Near Express Towers, Barrister Rajni Patel Marg, Nariman Point, Mumbai, 400021",
                "Nariman Point", "Mumbai", "Maharashtra",
                18.9284, 72.8227, "07:00 AM - 11:00 PM", "+91 98200 02002",
                "Sea View Promenade, Clean Restrooms, Security Guard",
                List.of(
                    new ChargerSeed("BOM-NP-01", ConnectorType.CCS2, 60.0, 20.00),
                    new ChargerSeed("BOM-NP-02", ConnectorType.CHADEMO, 50.0, 19.00),
                    new ChargerSeed("BOM-NP-03", ConnectorType.TYPE_2, 22.0, 16.50)
                ));

        createHub("Jio-bp pulse - Inorbit Mall Vashi",
                "Palm Beach Road, Sector 30A, Vashi, Navi Mumbai, Maharashtra, 400705",
                "Vashi", "Navi Mumbai", "Maharashtra",
                19.0664, 72.9986, "10:00 AM - 11:00 PM", "+91 98200 02003",
                "Mall Dining, Covered Parking, Air Pump, Kids Zone",
                List.of(
                    new ChargerSeed("BOM-VSH-01", ConnectorType.CCS2, 60.0, 18.50),
                    new ChargerSeed("BOM-VSH-02", ConnectorType.TYPE_2, 22.0, 15.50)
                ));

        createHub("Shell Recharge - Mumbai-Pune Expressway",
                "Expressway Food Mall, Milestone 62, Khalapur, Maharashtra, 410203",
                "Khalapur / Lonavala", "Mumbai-Pune Expressway", "Maharashtra",
                18.7884, 73.3283, "24 Hours Open", "+91 98200 02004",
                "Highway Food Court, McDonald's, Starbucks, Restrooms, Tire Pressure",
                List.of(
                    new ChargerSeed("EXP-MPE-01", ConnectorType.CCS2, 150.0, 23.50),
                    new ChargerSeed("EXP-MPE-02", ConnectorType.CCS2, 60.0, 20.50),
                    new ChargerSeed("EXP-MPE-03", ConnectorType.TYPE_2, 22.0, 17.00)
                ));

        createHub("Ather Grid & Statiq - Hinjewadi Phase 1",
                "Rajiv Gandhi Infotech Park, Hinjewadi Phase 1, Pune, Maharashtra, 411057",
                "Hinjewadi", "Pune", "Maharashtra",
                18.5913, 73.7389, "24 Hours Open", "+91 98200 02005",
                "Tech Park Campus, 24/7 Security, CCD, Restrooms",
                List.of(
                    new ChargerSeed("PUN-HIN-01", ConnectorType.CCS2, 60.0, 18.50),
                    new ChargerSeed("PUN-HIN-02", ConnectorType.TYPE_2, 22.0, 15.00)
                ));

        // -------------------------------------------------------------
        // REGION 3: BENGALURU & KARNATAKA
        // -------------------------------------------------------------
        createHub("Tata Power EZ Charge - Electronic City",
                "Hosur Road, Electronic City Phase 1, Bengaluru, Karnataka, 560100",
                "Electronic City", "Bengaluru", "Karnataka",
                12.8452, 77.6602, "24 Hours Open", "+91 98450 03001",
                "Elevated Tollway Proximity, Restrooms, Wi-Fi, Food Court",
                List.of(
                    new ChargerSeed("BLR-EC-01", ConnectorType.CCS2, 120.0, 21.00),
                    new ChargerSeed("BLR-EC-02", ConnectorType.CCS2, 60.0, 18.50),
                    new ChargerSeed("BLR-EC-03", ConnectorType.TYPE_2, 22.0, 15.50)
                ));

        createHub("Zeon Charging Hub - Whitefield ITPL",
                "International Tech Park, Whitefield Main Road, Bengaluru, Karnataka, 560066",
                "Whitefield", "Bengaluru", "Karnataka",
                12.9863, 77.7377, "24 Hours Open", "+91 98450 03002",
                "Shopping Concourse, Security, Covered Bay, Cafe",
                List.of(
                    new ChargerSeed("BLR-WTF-01", ConnectorType.CCS2, 60.0, 19.00),
                    new ChargerSeed("BLR-WTF-02", ConnectorType.CHADEMO, 50.0, 18.50),
                    new ChargerSeed("BLR-WTF-03", ConnectorType.TYPE_2, 22.0, 15.50)
                ));

        createHub("Jio-bp pulse - 100 Feet Road Indiranagar",
                "100 Feet Road, Near HAL 2nd Stage, Indiranagar, Bengaluru, Karnataka, 560038",
                "Indiranagar", "Bengaluru", "Karnataka",
                12.9719, 77.6412, "06:00 AM - 11:30 PM", "+91 98450 03003",
                "Prime Retail Belt, Wild Bean Cafe, Clean Restrooms",
                List.of(
                    new ChargerSeed("BLR-IND-01", ConnectorType.CCS2, 60.0, 19.50),
                    new ChargerSeed("BLR-IND-02", ConnectorType.TYPE_2, 22.0, 16.00)
                ));

        createHub("Shell Recharge - Kempegowda Airport Expressway",
                "NH 44, Near Toll Plaza, Devanahalli, Bengaluru, Karnataka, 560300",
                "Airport Highway", "Bengaluru", "Karnataka",
                13.1986, 77.7066, "24 Hours Open", "+91 98450 03004",
                "Airport Corridor, 24/7 Food Plaza, Restrooms, Free Air",
                List.of(
                    new ChargerSeed("BLR-AIR-01", ConnectorType.CCS2, 150.0, 23.00),
                    new ChargerSeed("BLR-AIR-02", ConnectorType.CCS2, 60.0, 20.00),
                    new ChargerSeed("BLR-AIR-03", ConnectorType.TYPE_2, 22.0, 16.50)
                ));

        // -------------------------------------------------------------
        // REGION 4: HYDERABAD & TELANGANA
        // -------------------------------------------------------------
        Station hyd1 = createHub("Tata Power EZ Charge - Cyber Gateway",
                "Cyber Gateway, HITEC City, Madhapur, Hyderabad, Telangana, 500081",
                "Hitec City", "Hyderabad", "Telangana",
                17.4474, 78.3762, "24 Hours Open", "+91 98491 10001",
                "Coffee Shop, Free High-Speed Wi-Fi, Restrooms, Security Guard, EV Lounge",
                List.of(
                    new ChargerSeed("TG-HITEC-01", ConnectorType.CCS2, 60.0, 18.50),
                    new ChargerSeed("TG-HITEC-02", ConnectorType.CCS2, 120.0, 21.00),
                    new ChargerSeed("TG-HITEC-03", ConnectorType.TYPE_2, 22.0, 16.00),
                    new ChargerSeed("TG-HITEC-04", ConnectorType.GB_T, 15.0, 15.50)
                ));

        createHub("Fortum Charge & Drive - Financial District",
                "Near Waverock SEZ, Nanakramguda, Gachibowli, Hyderabad, Telangana, 500032",
                "Gachibowli", "Hyderabad", "Telangana",
                17.4156, 78.3427, "24 Hours Open", "+91 98491 10002",
                "24/7 Convenience Mart, Cafe Coffee Day, CCTV Surveillance",
                List.of(
                    new ChargerSeed("FRT-GACH-01", ConnectorType.CCS2, 150.0, 22.50),
                    new ChargerSeed("FRT-GACH-02", ConnectorType.CCS2, 60.0, 19.00),
                    new ChargerSeed("FRT-GACH-03", ConnectorType.CHADEMO, 50.0, 18.50),
                    new ChargerSeed("FRT-GACH-04", ConnectorType.TYPE_2, 22.0, 16.00)
                ));

        createHub("Jio-bp pulse - Jubilee Hills Hub",
                "Road No. 36, Near Peddamma Temple Metro Station, Jubilee Hills, Hyderabad, 500033",
                "Jubilee Hills", "Hyderabad", "Telangana",
                17.4319, 78.4073, "06:00 AM - 11:30 PM", "+91 98491 10003",
                "Wild Bean Cafe, Restrooms, Air Pump, Touchless Car Wash",
                List.of(
                    new ChargerSeed("JIO-JUB-01", ConnectorType.CCS2, 60.0, 19.50),
                    new ChargerSeed("JIO-JUB-02", ConnectorType.CCS2, 30.0, 17.50),
                    new ChargerSeed("JIO-JUB-03", ConnectorType.TYPE_2, 22.0, 15.50)
                ));

        createHub("Shell Recharge - Inorbit Mall Hub",
                "Basement Parking P2, Inorbit Mall, Mindspace, Madhapur, Hyderabad, 500081",
                "Madhapur", "Hyderabad", "Telangana",
                17.4338, 78.3867, "10:00 AM - 11:00 PM", "+91 98491 10004",
                "Shopping Mall Access, Food Court, Multiplex, Covered Valet Parking",
                List.of(
                    new ChargerSeed("SHL-MAD-01", ConnectorType.CCS2, 120.0, 21.50),
                    new ChargerSeed("SHL-MAD-02", ConnectorType.CCS2, 60.0, 18.50),
                    new ChargerSeed("SHL-MAD-03", ConnectorType.TYPE_2, 22.0, 16.50)
                ));

        createHub("Ather Grid & Statiq Hub - Banjara Hills",
                "Road No. 12, Opposite MLA Colony, Banjara Hills, Hyderabad, 500034",
                "Banjara Hills", "Hyderabad", "Telangana",
                17.4123, 78.4358, "24 Hours Open", "+91 98491 10005",
                "Starbucks Nearby, Clean Restrooms, Shaded Canopy",
                List.of(
                    new ChargerSeed("STQ-BANJ-01", ConnectorType.CCS2, 50.0, 17.50),
                    new ChargerSeed("STQ-BANJ-02", ConnectorType.TYPE_2, 22.0, 15.00)
                ));

        createHub("Zeon Charging - Begumpet Airport Plaza",
                "Prakash Nagar Main Road, Begumpet, Hyderabad, Telangana, 500016",
                "Begumpet", "Hyderabad", "Telangana",
                17.4435, 78.4682, "24 Hours Open", "+91 98491 10006",
                "Metro Connectivity, 24/7 ATM, Driver Rest Cabin",
                List.of(
                    new ChargerSeed("ZEON-BEG-01", ConnectorType.CCS2, 50.0, 18.00),
                    new ChargerSeed("ZEON-BEG-02", ConnectorType.TYPE_2, 22.0, 15.00)
                ));

        createHub("Kazam Supercharger Hub - Secunderabad",
                "Station Road, Near Regimental Bazaar, Secunderabad, Telangana, 500003",
                "Secunderabad", "Hyderabad", "Telangana",
                17.4399, 78.5017, "24 Hours Open", "+91 98491 10007",
                "Railway Station Proximity, 24/7 Security, Refreshment Kiosks",
                List.of(
                    new ChargerSeed("KAZ-SEC-01", ConnectorType.CCS2, 60.0, 17.00),
                    new ChargerSeed("KAZ-SEC-02", ConnectorType.TYPE_2, 22.0, 14.50)
                ));

        createHub("ChargeZone Metro Hub - Miyapur",
                "Miyapur Metro Station Parking, NH 65, Miyapur, Hyderabad, 500049",
                "Miyapur", "Hyderabad", "Telangana",
                17.4968, 78.3614, "05:30 AM - 11:30 PM", "+91 98491 10008",
                "Direct Metro Walkway, Multilevel Parking, Vending Machine",
                List.of(
                    new ChargerSeed("CZ-MIY-01", ConnectorType.CCS2, 60.0, 17.50),
                    new ChargerSeed("CZ-MIY-02", ConnectorType.TYPE_2, 22.0, 15.00)
                ));

        // -------------------------------------------------------------
        // REGION 5: CHENNAI & TAMIL NADU
        // -------------------------------------------------------------
        createHub("Zeon Fast Charging - OMR IT Expressway",
                "Rajiv Gandhi Salai, Sholinganallur, OMR, Chennai, Tamil Nadu, 600119",
                "OMR", "Chennai", "Tamil Nadu",
                12.9010, 80.2279, "24 Hours Open", "+91 98400 04001",
                "IT Corridor, Restrooms, Coffee Day, 24/7 Guard",
                List.of(
                    new ChargerSeed("MAA-OMR-01", ConnectorType.CCS2, 120.0, 21.00),
                    new ChargerSeed("MAA-OMR-02", ConnectorType.CCS2, 50.0, 18.00),
                    new ChargerSeed("MAA-OMR-03", ConnectorType.TYPE_2, 22.0, 15.00)
                ));

        createHub("Tata Power EZ Charge - Guindy Industrial Estate",
                "SIDCO Industrial Estate, Guindy, Chennai, Tamil Nadu, 600032",
                "Guindy", "Chennai", "Tamil Nadu",
                13.0067, 80.2023, "24 Hours Open", "+91 98400 04002",
                "Metro Proximity, Restrooms, High Speed Charging",
                List.of(
                    new ChargerSeed("MAA-GND-01", ConnectorType.CCS2, 60.0, 18.50),
                    new ChargerSeed("MAA-GND-02", ConnectorType.TYPE_2, 22.0, 15.50)
                ));

        // -------------------------------------------------------------
        // REGION 6: KOLKATA & WEST BENGAL
        // -------------------------------------------------------------
        createHub("Tata Power EZ Charge - Salt Lake Sector V",
                "Ring Road, Sector V, Bidhannagar, Kolkata, West Bengal, 700091",
                "Salt Lake", "Kolkata", "West Bengal",
                22.5804, 88.4378, "24 Hours Open", "+91 98300 05001",
                "IT Hub, Subway, CCD, Restrooms, Security",
                List.of(
                    new ChargerSeed("CCU-SL-01", ConnectorType.CCS2, 60.0, 18.50),
                    new ChargerSeed("CCU-SL-02", ConnectorType.TYPE_2, 22.0, 15.50),
                    new ChargerSeed("CCU-SL-03", ConnectorType.GB_T, 15.0, 14.50)
                ));

        // -------------------------------------------------------------
        // REGION 7: AHMEDABAD & GUJARAT
        // -------------------------------------------------------------
        createHub("Statiq Superhub - SG Highway",
                "Near Iscon Cross Roads, SG Highway, Ahmedabad, Gujarat, 380015",
                "SG Highway", "Ahmedabad", "Gujarat",
                23.0305, 72.5074, "24 Hours Open", "+91 98250 06001",
                "Commercial Boulevard, 24/7 Security, Restrooms, Snacks",
                List.of(
                    new ChargerSeed("AMD-SGH-01", ConnectorType.CCS2, 120.0, 20.00),
                    new ChargerSeed("AMD-SGH-02", ConnectorType.CCS2, 60.0, 17.50),
                    new ChargerSeed("AMD-SGH-03", ConnectorType.TYPE_2, 22.0, 15.00)
                ));

        // -------------------------------------------------------------
        // REGION 8: JAIPUR & RAJASTHAN
        // -------------------------------------------------------------
        createHub("Jio-bp pulse - MI Road & Civil Lines",
                "Mirza Ismail Road, Near Ganpati Plaza, Jaipur, Rajasthan, 302001",
                "MI Road", "Jaipur", "Rajasthan",
                26.9157, 75.8015, "06:00 AM - 11:30 PM", "+91 98290 07001",
                "Heritage Belt, Wild Bean Cafe, Restrooms",
                List.of(
                    new ChargerSeed("JAI-MIR-01", ConnectorType.CCS2, 60.0, 18.00),
                    new ChargerSeed("JAI-MIR-02", ConnectorType.TYPE_2, 22.0, 15.00)
                ));

        // -------------------------------------------------------------
        // REGION 9: CHANDIGARH & PUNJAB/HARYANA
        // -------------------------------------------------------------
        createHub("Tata Power EZ Charge - Sector 17 Plaza",
                "City Centre, Sector 17, Chandigarh, 160017",
                "Sector 17", "Chandigarh", "Punjab / Haryana",
                30.7398, 76.7827, "24 Hours Open", "+91 98140 08001",
                "Pedestrian Plaza, Cafes, Ample Parking, Restrooms",
                List.of(
                    new ChargerSeed("IXC-17-01", ConnectorType.CCS2, 60.0, 18.00),
                    new ChargerSeed("IXC-17-02", ConnectorType.TYPE_2, 22.0, 15.00)
                ));

        // -------------------------------------------------------------
        // REGION 10: KOCHI & KERALA
        // -------------------------------------------------------------
        createHub("Zeon Charging - Marine Drive",
                "Shanmugham Road, Marine Drive Promenade, Kochi, Kerala, 682031",
                "Marine Drive", "Kochi", "Kerala",
                9.9816, 76.2763, "24 Hours Open", "+91 98470 09001",
                "Backwaters Walkway, Restrooms, Security, Coffee Counter",
                List.of(
                    new ChargerSeed("COK-MD-01", ConnectorType.CCS2, 60.0, 18.50),
                    new ChargerSeed("COK-MD-02", ConnectorType.TYPE_2, 22.0, 15.00)
                ));

        // -------------------------------------------------------------
        // REGION 11: LUCKNOW & CENTRAL UP
        // -------------------------------------------------------------
        createHub("Tata Power EZ Charge - Gomti Nagar Riverside",
                "Riverside Mall, Vipin Khand, Gomti Nagar, Lucknow, Uttar Pradesh, 226010",
                "Gomti Nagar", "Lucknow", "Uttar Pradesh",
                26.8500, 80.9900, "24 Hours Open", "+91 98390 10001",
                "Riverside Walkway, Shopping Mall, Restrooms, 24/7 Guard",
                List.of(
                    new ChargerSeed("LKO-GN-01", ConnectorType.CCS2, 60.0, 18.00),
                    new ChargerSeed("LKO-GN-02", ConnectorType.TYPE_2, 22.0, 15.00)
                ));

        // -------------------------------------------------------------
        // REGION 12: GOA (Coastal Tourism Corridor)
        // -------------------------------------------------------------
        createHub("Jio-bp pulse - Panaji Miramar Waterfront",
                "Miramar Beach Road, Panaji, Goa, 403001",
                "Panaji", "Goa", "Goa",
                15.4850, 73.8150, "24 Hours Open", "+91 98220 11001",
                "Beach Proximity, Wild Bean Cafe, Restrooms, EV Parking Bay",
                List.of(
                    new ChargerSeed("GOA-PAN-01", ConnectorType.CCS2, 60.0, 19.00),
                    new ChargerSeed("GOA-PAN-02", ConnectorType.TYPE_2, 22.0, 16.00)
                ));

        // -------------------------------------------------------------
        // REGION 13: BHOPAL & MADHYA PRADESH
        // -------------------------------------------------------------
        createHub("ChargeZone Hub - MP Nagar Zone 1",
                "Maharana Pratap Nagar, Zone 1, Bhopal, Madhya Pradesh, 462011",
                "MP Nagar", "Bhopal", "Madhya Pradesh",
                23.2330, 77.4340, "06:00 AM - 11:00 PM", "+91 98260 12001",
                "Commercial Hub, Fast Food, Restrooms, Security",
                List.of(
                    new ChargerSeed("BHO-MP-01", ConnectorType.CCS2, 60.0, 17.50),
                    new ChargerSeed("BHO-MP-02", ConnectorType.TYPE_2, 22.0, 14.50)
                ));

        // Seed sample booking and session for initial stats
        Charger sampleCharger = hyd1.getChargers().get(0);
        Booking bk1 = new Booking(
                "BK-20261014-0941A",
                driver1,
                hyd1,
                sampleCharger,
                LocalDateTime.now().minusHours(4),
                LocalDateTime.now().minusHours(3),
                60,
                28.5,
                BigDecimal.valueOf(622.04)
        );
        bk1.setStatus(BookingStatus.COMPLETED);
        bookingRepository.save(bk1);

        ChargingSession sess1 = new ChargingSession(
                "SES-261014-A12B",
                bk1,
                driver1,
                sampleCharger,
                hyd1,
                18.0,
                85.0
        );
        sess1.setStartTime(LocalDateTime.now().minusHours(4));
        sess1.setEndTime(LocalDateTime.now().minusHours(3));
        sess1.setUnitsConsumedKwh(28.5);
        sess1.setCurrentBatteryPercent(85.0);
        sess1.setSessionStatus(SessionStatus.COMPLETED);
        sessionRepository.save(sess1);

        Invoice inv1 = new Invoice("INV-20261014-8801", sess1, driver1, 28.5, 18.50);
        inv1.setPaymentStatus("PAID");
        inv1.setPaymentMethod(PaymentType.UPI);
        inv1.setPaymentTransactionId("UPI-20261014143000-A99X");
        invoiceRepository.save(inv1);
        sess1.setInvoice(inv1);
        sessionRepository.save(sess1);

        System.out.println("✅ Pan-India network loaded successfully with " + stationRepository.count() + " stations and " + chargerRepository.count() + " chargers!");
    }

    private Station createHub(String name, String address, String area, String city, String state,
                              Double lat, Double lng, String hours, String phone, String amenities,
                              List<ChargerSeed> chargers) {
        Station st = new Station(name, address, area, city, state, lat, lng, hours, phone, amenities);
        stationRepository.save(st);

        for (ChargerSeed cs : chargers) {
            Charger c = new Charger(cs.identifier, cs.type, cs.power, cs.rate, ChargerStatus.AVAILABLE, st);
            st.addCharger(c);
            chargerRepository.save(c);
        }
        return st;
    }

    private static class ChargerSeed {
        String identifier;
        ConnectorType type;
        Double power;
        Double rate;

        ChargerSeed(String identifier, ConnectorType type, Double power, Double rate) {
            this.identifier = identifier;
            this.type = type;
            this.power = power;
            this.rate = rate;
        }
    }
}
