package com.evcharging.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Booking Entity manages reserved charging slots by EV drivers.
 */
@Entity
@Table(name = "bookings")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Booking extends BaseEntity {

    @Column(name = "booking_reference", nullable = false, unique = true, length = 40)
    private String bookingReference;

    @NotNull(message = "Driver is required")
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "driver_id", nullable = false)
    private EVDriver driver;

    @NotNull(message = "Station is required")
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "station_id", nullable = false)
    private Station station;

    @NotNull(message = "Charger is required")
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "charger_id", nullable = false)
    private Charger charger;

    @NotNull(message = "Start time is required")
    @Column(name = "start_time", nullable = false)
    private LocalDateTime startTime;

    @NotNull(message = "End time is required")
    @Column(name = "end_time", nullable = false)
    private LocalDateTime endTime;

    @Column(name = "duration_minutes")
    private Integer durationMinutes;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    private BookingStatus status;

    @Column(name = "estimated_kwh")
    private Double estimatedKwh;

    @Column(name = "estimated_cost", precision = 10, scale = 2)
    private BigDecimal estimatedCost;

    @Column(name = "cancellation_reason")
    private String cancellationReason;

    public Booking() {
        super();
        this.status = BookingStatus.CONFIRMED;
    }

    public Booking(String bookingReference, EVDriver driver, Station station, Charger charger,
                   LocalDateTime startTime, LocalDateTime endTime, Integer durationMinutes,
                   Double estimatedKwh, BigDecimal estimatedCost) {
        super();
        this.bookingReference = bookingReference;
        this.driver = driver;
        this.station = station;
        this.charger = charger;
        this.startTime = startTime;
        this.endTime = endTime;
        this.durationMinutes = durationMinutes;
        this.estimatedKwh = estimatedKwh;
        this.estimatedCost = estimatedCost;
        this.status = BookingStatus.CONFIRMED;
    }

    public boolean canCancel() {
        return this.status == BookingStatus.CONFIRMED;
    }

    public void cancel(String reason) {
        if (!canCancel()) {
            throw new IllegalStateException("Cannot cancel a booking with status: " + this.status);
        }
        this.status = BookingStatus.CANCELLED;
        this.cancellationReason = (reason != null && !reason.isBlank()) ? reason : "Cancelled by User";
    }

    // Encapsulation: Getters and Setters
    public String getBookingReference() {
        return bookingReference;
    }

    public void setBookingReference(String bookingReference) {
        this.bookingReference = bookingReference;
    }

    public EVDriver getDriver() {
        return driver;
    }

    public void setDriver(EVDriver driver) {
        this.driver = driver;
    }

    public Station getStation() {
        return station;
    }

    public void setStation(Station station) {
        this.station = station;
    }

    public Charger getCharger() {
        return charger;
    }

    public void setCharger(Charger charger) {
        this.charger = charger;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }

    public Integer getDurationMinutes() {
        return durationMinutes;
    }

    public void setDurationMinutes(Integer durationMinutes) {
        this.durationMinutes = durationMinutes;
    }

    public BookingStatus getStatus() {
        return status;
    }

    public void setStatus(BookingStatus status) {
        this.status = status;
    }

    public Double getEstimatedKwh() {
        return estimatedKwh;
    }

    public void setEstimatedKwh(Double estimatedKwh) {
        this.estimatedKwh = estimatedKwh;
    }

    public BigDecimal getEstimatedCost() {
        return estimatedCost;
    }

    public void setEstimatedCost(BigDecimal estimatedCost) {
        this.estimatedCost = estimatedCost;
    }

    public String getCancellationReason() {
        return cancellationReason;
    }

    public void setCancellationReason(String cancellationReason) {
        this.cancellationReason = cancellationReason;
    }
}
