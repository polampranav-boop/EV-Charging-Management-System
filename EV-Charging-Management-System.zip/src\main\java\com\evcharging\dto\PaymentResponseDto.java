package com.evcharging.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class PaymentResponseDto {

    private boolean success;
    private String transactionReference;
    private String paymentMethod;
    private BigDecimal amountPaid;
    private BigDecimal convenienceFee;
    private BigDecimal cashBackEarned;
    private String message;
    private LocalDateTime timestamp;

    public PaymentResponseDto() {
        this.timestamp = LocalDateTime.now();
    }

    public PaymentResponseDto(boolean success, String transactionReference, String paymentMethod,
                              BigDecimal amountPaid, BigDecimal convenienceFee, BigDecimal cashBackEarned,
                              String message) {
        this.success = success;
        this.transactionReference = transactionReference;
        this.paymentMethod = paymentMethod;
        this.amountPaid = amountPaid;
        this.convenienceFee = convenienceFee;
        this.cashBackEarned = cashBackEarned;
        this.message = message;
        this.timestamp = LocalDateTime.now();
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getTransactionReference() {
        return transactionReference;
    }

    public void setTransactionReference(String transactionReference) {
        this.transactionReference = transactionReference;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public BigDecimal getAmountPaid() {
        return amountPaid;
    }

    public void setAmountPaid(BigDecimal amountPaid) {
        this.amountPaid = amountPaid;
    }

    public BigDecimal getConvenienceFee() {
        return convenienceFee;
    }

    public void setConvenienceFee(BigDecimal convenienceFee) {
        this.convenienceFee = convenienceFee;
    }

    public BigDecimal getCashBackEarned() {
        return cashBackEarned;
    }

    public void setCashBackEarned(BigDecimal cashBackEarned) {
        this.cashBackEarned = cashBackEarned;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }
}
