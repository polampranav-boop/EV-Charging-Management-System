package com.evcharging.model;

public enum PaymentType {
    UPI,
    CREDIT_CARD,
    EV_WALLET
}
