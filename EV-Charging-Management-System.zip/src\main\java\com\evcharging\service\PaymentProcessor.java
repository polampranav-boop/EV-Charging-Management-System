package com.evcharging.service;

import com.evcharging.dto.PaymentRequestDto;
import com.evcharging.dto.PaymentResponseDto;
import com.evcharging.model.Invoice;
import com.evcharging.model.PaymentType;
import java.math.BigDecimal;

/**
 * OOP Abstraction: PaymentProcessor Interface.
 * Defines the contract that all concrete payment implementations must fulfill.
 */
public interface PaymentProcessor {

    PaymentType getSupportedPaymentType();

    String getGatewayDisplayName();

    BigDecimal calculateConvenienceFee(BigDecimal billAmount);

    BigDecimal calculateCashBackBonus(BigDecimal billAmount);

    PaymentResponseDto processPayment(Invoice invoice, PaymentRequestDto request);
}
