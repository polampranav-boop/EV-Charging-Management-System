package com.evcharging.service;

import com.evcharging.dto.ChargerRequestDto;
import com.evcharging.dto.StationRequestDto;
import com.evcharging.model.Charger;
import com.evcharging.model.ChargerStatus;
import com.evcharging.model.ConnectorType;
import com.evcharging.model.Station;
import java.util.List;

public interface StationService {
    List<Station> getAllStations();
    Station getStationById(Long id);
    List<Station> searchAndFilterStations(String query, String area, ConnectorType connectorType, Double minPower, Boolean availableOnly);
    Station createStation(StationRequestDto request);
    Station updateStation(Long id, StationRequestDto request);
    void deleteStation(Long id);
    Charger addChargerToStation(ChargerRequestDto request);
    Charger updateChargerStatus(Long chargerId, ChargerStatus status);
    void deleteCharger(Long chargerId);
    List<String> getAvailableAreas();
    List<String> getAvailableCities();
}

