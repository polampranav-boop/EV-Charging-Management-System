package com.evcharging.controller;

import com.evcharging.dto.UserRegistrationDto;
import com.evcharging.model.Admin;
import com.evcharging.model.ConnectorType;
import com.evcharging.model.EVDriver;
import com.evcharging.model.User;
import com.evcharging.service.UserService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/users")
@CrossOrigin(origins = "*")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/drivers")
    public ResponseEntity<List<EVDriver>> getDrivers() {
        return ResponseEntity.ok(userService.getAllDrivers());
    }

    @GetMapping("/admins")
    public ResponseEntity<List<Admin>> getAdmins() {
        return ResponseEntity.ok(userService.getAllAdmins());
    }

    @GetMapping("/{id}")
    public ResponseEntity<User> getUserById(@PathVariable Long id) {
        return ResponseEntity.ok(userService.getUserById(id));
    }

    @PostMapping("/register")
    public ResponseEntity<User> register(@Valid @RequestBody UserRegistrationDto dto) {
        User user = userService.registerUser(dto);
        return new ResponseEntity<>(user, HttpStatus.CREATED);
    }

    @PostMapping("/{id}/recharge-wallet")
    public ResponseEntity<EVDriver> rechargeWallet(
            @PathVariable Long id,
            @RequestBody Map<String, BigDecimal> body) {
        BigDecimal amount = body.get("amount");
        return ResponseEntity.ok(userService.rechargeWallet(id, amount));
    }

    @PutMapping("/{id}/vehicle")
    public ResponseEntity<EVDriver> updateVehicle(
            @PathVariable Long id,
            @RequestBody Map<String, Object> body) {
        String vehicleModel = (String) body.get("vehicleModel");
        String registrationNumber = (String) body.get("vehicleRegistrationNumber");
        Double batteryCapacity = body.get("batteryCapacityKwh") != null ? Double.valueOf(body.get("batteryCapacityKwh").toString()) : null;
        ConnectorType connectorType = body.get("preferredConnectorType") != null ? ConnectorType.valueOf(body.get("preferredConnectorType").toString()) : null;

        return ResponseEntity.ok(userService.updateDriverVehicle(id, vehicleModel, registrationNumber, batteryCapacity, connectorType));
    }

    @PostMapping("/login")
    public ResponseEntity<EVDriver> quickLogin(@RequestBody Map<String, String> body) {
        String name = body.get("name");
        String email = body.get("email");
        String phone = body.get("phone");
        String vehicleModel = body.get("vehicleModel");
        String registrationNumber = body.get("vehicleRegistrationNumber");

        EVDriver driver = userService.loginOrRegisterDriver(name, email, phone, vehicleModel, registrationNumber);
        return ResponseEntity.ok(driver);
    }
}
