package com.evcharging.service;

import com.evcharging.dto.DashboardStatsDto;
import com.evcharging.model.Charger;
import com.evcharging.model.ChargerStatus;
import com.evcharging.model.SessionStatus;
import com.evcharging.model.Station;
import com.evcharging.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@Transactional(readOnly = true)
public class AnalyticsService {

    private final StationRepository stationRepository;
    private final ChargerRepository chargerRepository;
    private final BookingRepository bookingRepository;
    private final ChargingSessionRepository sessionRepository;
    private final InvoiceRepository invoiceRepository;

    public AnalyticsService(StationRepository stationRepository,
                            ChargerRepository chargerRepository,
                            BookingRepository bookingRepository,
                            ChargingSessionRepository sessionRepository,
                            InvoiceRepository invoiceRepository) {
        this.stationRepository = stationRepository;
        this.chargerRepository = chargerRepository;
        this.bookingRepository = bookingRepository;
        this.sessionRepository = sessionRepository;
        this.invoiceRepository = invoiceRepository;
    }

    public DashboardStatsDto getDashboardStats() {
        DashboardStatsDto dto = new DashboardStatsDto();

        dto.setTotalStations(stationRepository.count());
        dto.setTotalChargers(chargerRepository.count());
        dto.setAvailableChargers(chargerRepository.countByStatus(ChargerStatus.AVAILABLE));
        dto.setOccupiedChargers(chargerRepository.countByStatus(ChargerStatus.OCCUPIED));
        dto.setMaintenanceChargers(chargerRepository.countByStatus(ChargerStatus.MAINTENANCE)
                + chargerRepository.countByStatus(ChargerStatus.OUT_OF_SERVICE));

        dto.setTotalBookings(bookingRepository.count());
        dto.setActiveChargingSessions(sessionRepository.countBySessionStatus(SessionStatus.ACTIVE));

        Double totalKwh = invoiceRepository.calculateTotalEnergyConsumed();
        dto.setTotalEnergyDeliveredKwh(totalKwh != null ? Math.round(totalKwh * 10.0) / 10.0 : 0.0);

        BigDecimal totalRevenue = invoiceRepository.calculateTotalRevenue();
        dto.setTotalRevenue(totalRevenue != null ? totalRevenue : BigDecimal.ZERO);

        // Java Streams Collections grouping
        List<Charger> allChargers = chargerRepository.findAll();
        Map<String, Long> connectorMap = allChargers.stream()
                .collect(Collectors.groupingBy(c -> c.getConnectorType().name(), Collectors.counting()));
        dto.setChargersByConnector(connectorMap);

        List<Station> allStations = stationRepository.findAll();
        Map<String, Long> areaMap = allStations.stream()
                .collect(Collectors.groupingBy(Station::getArea, Collectors.counting()));
        dto.setStationsByArea(areaMap);

        return dto;
    }
}
