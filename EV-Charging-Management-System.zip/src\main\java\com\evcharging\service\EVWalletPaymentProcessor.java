package com.evcharging.service;

import com.evcharging.dto.PaymentRequestDto;
import com.evcharging.exception.PaymentFailedException;
import com.evcharging.model.EVDriver;
import com.evcharging.model.Invoice;
import com.evcharging.model.PaymentType;
import com.evcharging.repository.EVDriverRepository;
import com.evcharging.repository.InvoiceRepository;
import com.evcharging.repository.PaymentRecordRepository;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * OOP Polymorphism: EV Wallet Payment Implementation.
 * Overrides payment processing by debiting the driver's internal pre-funded EV balance
 * and crediting 5% sustainable green rewards back into the wallet.
 */
@Service
public class EVWalletPaymentProcessor extends AbstractPaymentProcessor {

    private final EVDriverRepository driverRepository;

    public EVWalletPaymentProcessor(InvoiceRepository invoiceRepository,
                                   PaymentRecordRepository paymentRecordRepository,
                                   EVDriverRepository driverRepository) {
        super(invoiceRepository, paymentRecordRepository);
        this.driverRepository = driverRepository;
    }

    @Override
    public PaymentType getSupportedPaymentType() {
        return PaymentType.EV_WALLET;
    }

    @Override
    public String getGatewayDisplayName() {
        return "EV Network Driver Wallet (Instant Checkout)";
    }

    @Override
    public BigDecimal calculateConvenienceFee(BigDecimal billAmount) {
        return BigDecimal.ZERO;
    }

    @Override
    public BigDecimal calculateCashBackBonus(BigDecimal billAmount) {
        // 5% Eco-Reward cashback credited to wallet
        return billAmount.multiply(BigDecimal.valueOf(0.05)).setScale(2, RoundingMode.HALF_UP);
    }

    @Override
    protected String executeGatewayAuthorization(Invoice invoice, PaymentRequestDto request, BigDecimal amount) {
        EVDriver driver = invoice.getDriver();
        if (driver == null) {
            throw new PaymentFailedException("EV Driver profile not attached to invoice.");
        }
        if (!driver.canDeductWallet(amount)) {
            throw new PaymentFailedException("Insufficient EV Wallet balance. Required: ₹" + amount +
                    ", Current Balance: ₹" + driver.getWalletBalance() + ". Please recharge your wallet or choose UPI/Card.");
        }

        // Deduct from wallet balance
        driver.deductWallet(amount);
        driverRepository.save(driver);

        return generateTransactionReference("WAL");
    }

    @Override
    protected void onPaymentSuccess(Invoice invoice, BigDecimal cashback) {
        // Credit the 5% cashback reward into the driver's wallet
        if (cashback != null && cashback.compareTo(BigDecimal.ZERO) > 0) {
            EVDriver driver = invoice.getDriver();
            driver.creditWallet(cashback);
            driverRepository.save(driver);
        }
    }
}
