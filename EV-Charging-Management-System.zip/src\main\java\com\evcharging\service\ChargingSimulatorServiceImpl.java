package com.evcharging.service;

import com.evcharging.dto.StartSessionRequestDto;
import com.evcharging.exception.InvalidBookingException;
import com.evcharging.exception.ResourceNotFoundException;
import com.evcharging.exception.SlotUnavailableException;
import com.evcharging.model.*;
import com.evcharging.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.UUID;

@Service
@Transactional
public class ChargingSimulatorServiceImpl implements ChargingSimulatorService {

    private final ChargingSessionRepository sessionRepository;
    private final BookingRepository bookingRepository;
    private final EVDriverRepository driverRepository;
    private final ChargerRepository chargerRepository;
    private final InvoiceRepository invoiceRepository;

    public ChargingSimulatorServiceImpl(ChargingSessionRepository sessionRepository,
                                        BookingRepository bookingRepository,
                                        EVDriverRepository driverRepository,
                                        ChargerRepository chargerRepository,
                                        InvoiceRepository invoiceRepository) {
        this.sessionRepository = sessionRepository;
        this.bookingRepository = bookingRepository;
        this.driverRepository = driverRepository;
        this.chargerRepository = chargerRepository;
        this.invoiceRepository = invoiceRepository;
    }

    @Override
    public ChargingSession startSession(StartSessionRequestDto request) {
        EVDriver driver = driverRepository.findById(request.getDriverId())
                .orElseThrow(() -> new ResourceNotFoundException("Driver not found with ID: " + request.getDriverId()));

        Charger charger = chargerRepository.findById(request.getChargerId())
                .orElseThrow(() -> new ResourceNotFoundException("Charger not found with ID: " + request.getChargerId()));

        Booking booking = null;
        if (request.getBookingId() != null) {
            booking = bookingRepository.findById(request.getBookingId())
                    .orElseThrow(() -> new ResourceNotFoundException("Booking not found with ID: " + request.getBookingId()));

            if (booking.getStatus() == BookingStatus.CANCELLED || booking.getStatus() == BookingStatus.COMPLETED) {
                throw new InvalidBookingException("Cannot start session for booking with status: " + booking.getStatus());
            }
            booking.setStatus(BookingStatus.ACTIVE);
            bookingRepository.save(booking);
        } else {
            // Walk-in check: verify charger is available
            if (charger.getStatus() != ChargerStatus.AVAILABLE) {
                throw new SlotUnavailableException("Charger " + charger.getIdentifier() + " is currently " + charger.getStatus());
            }
        }

        // Lock charger to occupied
        charger.setStatus(ChargerStatus.OCCUPIED);
        chargerRepository.save(charger);

        String sessionRef = "SES-" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyMMdd"))
                + "-" + UUID.randomUUID().toString().substring(0, 5).toUpperCase();

        Double initialBattery = request.getCurrentBatteryPercent() != null ? request.getCurrentBatteryPercent() : 22.0;
        Double targetBattery = request.getTargetBatteryPercent() != null ? request.getTargetBatteryPercent() : 85.0;

        ChargingSession session = new ChargingSession(
                sessionRef,
                booking,
                driver,
                charger,
                charger.getStation(),
                initialBattery,
                targetBattery
        );

        return sessionRepository.save(session);
    }

    @Override
    public ChargingSession tickSimulation(Long sessionId, Double progressKwh, Double batteryPercent) {
        ChargingSession session = getSessionById(sessionId);
        if (session.getSessionStatus() != SessionStatus.ACTIVE) {
            return session;
        }

        if (progressKwh != null && progressKwh > 0) {
            session.setUnitsConsumedKwh(Math.round(progressKwh * 100.0) / 100.0);
        }
        if (batteryPercent != null) {
            session.setCurrentBatteryPercent(Math.min(100.0, Math.round(batteryPercent * 10.0) / 10.0));
        }

        // If reached target battery, can auto-complete
        if (session.getCurrentBatteryPercent() >= session.getTargetBatteryPercent()) {
            session.setCurrentBatteryPercent(session.getTargetBatteryPercent());
        }

        return sessionRepository.save(session);
    }

    @Override
    public Invoice stopSession(Long sessionId) {
        ChargingSession session = getSessionById(sessionId);
        if (session.getSessionStatus() == SessionStatus.COMPLETED) {
            return session.getInvoice();
        }

        session.setEndTime(LocalDateTime.now());
        session.setSessionStatus(SessionStatus.COMPLETED);

        // Ensure at least minimal units consumed if session stopped quickly
        if (session.getUnitsConsumedKwh() == null || session.getUnitsConsumedKwh() < 0.1) {
            session.setUnitsConsumedKwh(2.5); // Default realistic minimum test session units
        }

        // Free charger status
        Charger charger = session.getCharger();
        charger.setStatus(ChargerStatus.AVAILABLE);
        chargerRepository.save(charger);

        // Complete linked booking if any
        if (session.getBooking() != null) {
            Booking booking = session.getBooking();
            booking.setStatus(BookingStatus.COMPLETED);
            bookingRepository.save(booking);
        }

        // Automatically calculate charging bill based on kWh consumed (Requirements 6 & 7)
        String invRef = "INV-" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"))
                + "-" + UUID.randomUUID().toString().substring(0, 4).toUpperCase();

        Invoice invoice = new Invoice(
                invRef,
                session,
                session.getDriver(),
                session.getUnitsConsumedKwh(),
                session.getChargingRatePerKwh()
        );

        Invoice savedInvoice = invoiceRepository.save(invoice);
        session.setInvoice(savedInvoice);
        sessionRepository.save(session);

        return savedInvoice;
    }

    @Override
    @Transactional(readOnly = true)
    public ChargingSession getSessionById(Long sessionId) {
        return sessionRepository.findById(sessionId)
                .orElseThrow(() -> new ResourceNotFoundException("Charging session not found with ID: " + sessionId));
    }

    @Override
    @Transactional(readOnly = true)
    public List<ChargingSession> getActiveSessions() {
        return sessionRepository.findBySessionStatus(SessionStatus.ACTIVE);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ChargingSession> getSessionsByDriver(Long driverId) {
        return sessionRepository.findByDriverIdOrderByStartTimeDesc(driverId);
    }
}
