package com.evcharging.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * PaymentRecord encapsulates audit logs of financial transactions executed through polymorphic gateways.
 */
@Entity
@Table(name = "payment_records")
public class PaymentRecord extends BaseEntity {

    @Column(name = "transaction_reference", nullable = false, unique = true, length = 60)
    private String transactionReference;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "invoice_id", nullable = false)
    private Invoice invoice;

    @Enumerated(EnumType.STRING)
    @Column(name = "payment_type", nullable = false, length = 30)
    private PaymentType paymentType;

    @Column(precision = 10, scale = 2, nullable = false)
    private BigDecimal amountPaid;

    @Column(name = "fee_applied", precision = 10, scale = 2)
    private BigDecimal feeApplied;

    @Column(name = "gateway_status", nullable = false, length = 30)
    private String gatewayStatus;

    @Column(name = "payment_timestamp", nullable = false)
    private LocalDateTime paymentTimestamp;

    @Column(name = "remarks", length = 255)
    private String remarks;

    public PaymentRecord() {
        super();
        this.paymentTimestamp = LocalDateTime.now();
    }

    public PaymentRecord(String transactionReference, Invoice invoice, PaymentType paymentType,
                         BigDecimal amountPaid, BigDecimal feeApplied, String gatewayStatus, String remarks) {
        super();
        this.transactionReference = transactionReference;
        this.invoice = invoice;
        this.paymentType = paymentType;
        this.amountPaid = amountPaid;
        this.feeApplied = feeApplied != null ? feeApplied : BigDecimal.ZERO;
        this.gatewayStatus = gatewayStatus;
        this.paymentTimestamp = LocalDateTime.now();
        this.remarks = remarks;
    }

    // Encapsulation: Getters and Setters
    public String getTransactionReference() {
        return transactionReference;
    }

    public void setTransactionReference(String transactionReference) {
        this.transactionReference = transactionReference;
    }

    public Invoice getInvoice() {
        return invoice;
    }

    public void setInvoice(Invoice invoice) {
        this.invoice = invoice;
    }

    public PaymentType getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(PaymentType paymentType) {
        this.paymentType = paymentType;
    }

    public BigDecimal getAmountPaid() {
        return amountPaid;
    }

    public void setAmountPaid(BigDecimal amountPaid) {
        this.amountPaid = amountPaid;
    }

    public BigDecimal getFeeApplied() {
        return feeApplied;
    }

    public void setFeeApplied(BigDecimal feeApplied) {
        this.feeApplied = feeApplied;
    }

    public String getGatewayStatus() {
        return gatewayStatus;
    }

    public void setGatewayStatus(String gatewayStatus) {
        this.gatewayStatus = gatewayStatus;
    }

    public LocalDateTime getPaymentTimestamp() {
        return paymentTimestamp;
    }

    public void setPaymentTimestamp(LocalDateTime paymentTimestamp) {
        this.paymentTimestamp = paymentTimestamp;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
}
