package com.evcharging.model;

public enum SessionStatus {
    ACTIVE,
    PAUSED,
    COMPLETED,
    STOPPED
}
