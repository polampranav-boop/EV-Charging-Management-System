package com.evcharging.repository;

import com.evcharging.model.ChargingSession;
import com.evcharging.model.SessionStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface ChargingSessionRepository extends JpaRepository<ChargingSession, Long> {
    Optional<ChargingSession> findBySessionReference(String sessionReference);
    List<ChargingSession> findByDriverIdOrderByStartTimeDesc(Long driverId);
    List<ChargingSession> findBySessionStatus(SessionStatus sessionStatus);
    long countBySessionStatus(SessionStatus sessionStatus);
}
