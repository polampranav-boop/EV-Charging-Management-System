package com.evcharging.dto;

import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDateTime;

public class BookingRequestDto {

    @NotNull(message = "Driver ID is required")
    private Long driverId;

    @NotNull(message = "Charger ID is required")
    private Long chargerId;

    @NotNull(message = "Start time is required")
    @Future(message = "Booking slot must be in the future")
    private LocalDateTime startTime;

    @NotNull(message = "Duration in minutes is required")
    private Integer durationMinutes;

    private Double targetBatteryKwh;

    public BookingRequestDto() {}

    public BookingRequestDto(Long driverId, Long chargerId, LocalDateTime startTime, Integer durationMinutes, Double targetBatteryKwh) {
        this.driverId = driverId;
        this.chargerId = chargerId;
        this.startTime = startTime;
        this.durationMinutes = durationMinutes;
        this.targetBatteryKwh = targetBatteryKwh;
    }

    public Long getDriverId() {
        return driverId;
    }

    public void setDriverId(Long driverId) {
        this.driverId = driverId;
    }

    public Long getChargerId() {
        return chargerId;
    }

    public void setChargerId(Long chargerId) {
        this.chargerId = chargerId;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public Integer getDurationMinutes() {
        return durationMinutes;
    }

    public void setDurationMinutes(Integer durationMinutes) {
        this.durationMinutes = durationMinutes;
    }

    public Double getTargetBatteryKwh() {
        return targetBatteryKwh;
    }

    public void setTargetBatteryKwh(Double targetBatteryKwh) {
        this.targetBatteryKwh = targetBatteryKwh;
    }
}
