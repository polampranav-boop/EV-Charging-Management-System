package com.evcharging.model;

public enum BookingStatus {
    CONFIRMED,
    ACTIVE,
    COMPLETED,
    CANCELLED
}
