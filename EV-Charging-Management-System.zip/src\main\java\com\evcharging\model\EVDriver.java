package com.evcharging.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * OOP Inheritance Subclass: EVDriver
 * Represents an Electric Vehicle owner registered in the charging network.
 */
@Entity
@Table(name = "ev_drivers")
public class EVDriver extends User {

    @Column(name = "vehicle_model", length = 80)
    private String vehicleModel;

    @Column(name = "vehicle_registration_number", length = 30)
    private String vehicleRegistrationNumber;

    @Column(name = "battery_capacity_kwh")
    private Double batteryCapacityKwh;

    @Enumerated(EnumType.STRING)
    @Column(name = "preferred_connector_type")
    private ConnectorType preferredConnectorType;

    @Column(name = "wallet_balance", precision = 10, scale = 2)
    private BigDecimal walletBalance;

    public EVDriver() {
        super();
        this.setRole(UserRole.EV_DRIVER);
        this.walletBalance = BigDecimal.valueOf(500.00); // Default promotional sign-up balance
    }

    public EVDriver(String name, String email, String phone, String password,
                    String vehicleModel, String vehicleRegistrationNumber,
                    Double batteryCapacityKwh, ConnectorType preferredConnectorType,
                    BigDecimal initialWalletBalance) {
        super(name, email, phone, password, UserRole.EV_DRIVER);
        this.vehicleModel = vehicleModel;
        this.vehicleRegistrationNumber = vehicleRegistrationNumber;
        this.batteryCapacityKwh = batteryCapacityKwh != null ? batteryCapacityKwh : 40.0;
        this.preferredConnectorType = preferredConnectorType != null ? preferredConnectorType : ConnectorType.CCS2;
        this.walletBalance = initialWalletBalance != null ? initialWalletBalance : BigDecimal.valueOf(500.00);
    }

    // Polymorphic method implementations
    @Override
    public String getRoleDescription() {
        return "EV Driver - " + (vehicleModel != null ? vehicleModel : "Electric Vehicle")
                + " [" + (vehicleRegistrationNumber != null ? vehicleRegistrationNumber : "Unregistered") + "]";
    }

    @Override
    public String getDashboardGreeting() {
        return "Hi, " + getName() + "! Ready to charge your " + (vehicleModel != null ? vehicleModel : "EV") + "?";
    }

    // Domain business methods (Encapsulation)
    public boolean canDeductWallet(BigDecimal amount) {
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            return false;
        }
        return this.walletBalance.compareTo(amount) >= 0;
    }

    public void deductWallet(BigDecimal amount) {
        if (!canDeductWallet(amount)) {
            throw new IllegalArgumentException("Insufficient wallet balance: Available ₹" + this.walletBalance + ", required ₹" + amount);
        }
        this.walletBalance = this.walletBalance.subtract(amount).setScale(2, RoundingMode.HALF_UP);
    }

    public void creditWallet(BigDecimal amount) {
        if (amount != null && amount.compareTo(BigDecimal.ZERO) > 0) {
            this.walletBalance = this.walletBalance.add(amount).setScale(2, RoundingMode.HALF_UP);
        }
    }

    // Encapsulation: Getters and Setters
    public String getVehicleModel() {
        return vehicleModel;
    }

    public void setVehicleModel(String vehicleModel) {
        this.vehicleModel = vehicleModel;
    }

    public String getVehicleRegistrationNumber() {
        return vehicleRegistrationNumber;
    }

    public void setVehicleRegistrationNumber(String vehicleRegistrationNumber) {
        this.vehicleRegistrationNumber = vehicleRegistrationNumber;
    }

    public Double getBatteryCapacityKwh() {
        return batteryCapacityKwh;
    }

    public void setBatteryCapacityKwh(Double batteryCapacityKwh) {
        this.batteryCapacityKwh = batteryCapacityKwh;
    }

    public ConnectorType getPreferredConnectorType() {
        return preferredConnectorType;
    }

    public void setPreferredConnectorType(ConnectorType preferredConnectorType) {
        this.preferredConnectorType = preferredConnectorType;
    }

    public BigDecimal getWalletBalance() {
        return walletBalance;
    }

    public void setWalletBalance(BigDecimal walletBalance) {
        this.walletBalance = walletBalance;
    }
}
