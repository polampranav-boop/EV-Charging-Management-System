package com.evcharging.controller;

import com.evcharging.dto.ChargerRequestDto;
import com.evcharging.dto.StationRequestDto;
import com.evcharging.model.Charger;
import com.evcharging.model.ChargerStatus;
import com.evcharging.model.ConnectorType;
import com.evcharging.model.Station;
import com.evcharging.service.StationService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/stations")
@CrossOrigin(origins = "*")
public class StationController {

    private final StationService stationService;

    public StationController(StationService stationService) {
        this.stationService = stationService;
    }

    @GetMapping
    public ResponseEntity<List<Station>> getStations(
            @RequestParam(required = false) String query,
            @RequestParam(required = false) String area,
            @RequestParam(required = false) ConnectorType connectorType,
            @RequestParam(required = false) Double minPower,
            @RequestParam(required = false) Boolean availableOnly) {
        List<Station> stations = stationService.searchAndFilterStations(query, area, connectorType, minPower, availableOnly);
        return ResponseEntity.ok(stations);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Station> getStationById(@PathVariable Long id) {
        return ResponseEntity.ok(stationService.getStationById(id));
    }

    @GetMapping("/areas")
    public ResponseEntity<List<String>> getAreas() {
        return ResponseEntity.ok(stationService.getAvailableAreas());
    }

    @GetMapping("/cities")
    public ResponseEntity<List<String>> getCities() {
        return ResponseEntity.ok(stationService.getAvailableCities());
    }

    @PostMapping
    public ResponseEntity<Station> createStation(@Valid @RequestBody StationRequestDto request) {
        Station created = stationService.createStation(request);
        return new ResponseEntity<>(created, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Station> updateStation(@PathVariable Long id, @Valid @RequestBody StationRequestDto request) {
        return ResponseEntity.ok(stationService.updateStation(id, request));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, String>> deleteStation(@PathVariable Long id) {
        stationService.deleteStation(id);
        return ResponseEntity.ok(Map.of("message", "Station #" + id + " successfully deleted"));
    }

    @PostMapping("/chargers")
    public ResponseEntity<Charger> addCharger(@Valid @RequestBody ChargerRequestDto request) {
        Charger charger = stationService.addChargerToStation(request);
        return new ResponseEntity<>(charger, HttpStatus.CREATED);
    }

    @PatchMapping("/chargers/{id}/status")
    public ResponseEntity<Charger> updateChargerStatus(
            @PathVariable Long id,
            @RequestParam ChargerStatus status) {
        Charger updated = stationService.updateChargerStatus(id, status);
        return ResponseEntity.ok(updated);
    }

    @DeleteMapping("/chargers/{id}")
    public ResponseEntity<Map<String, String>> deleteCharger(@PathVariable Long id) {
        stationService.deleteCharger(id);
        return ResponseEntity.ok(Map.of("message", "Charger #" + id + " deleted successfully"));
    }
}
