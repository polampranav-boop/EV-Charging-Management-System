package com.evcharging.dto;

import jakarta.validation.constraints.NotNull;

public class StartSessionRequestDto {

    private Long bookingId;

    @NotNull(message = "Driver ID is required")
    private Long driverId;

    @NotNull(message = "Charger ID is required")
    private Long chargerId;

    private Double currentBatteryPercent;

    private Double targetBatteryPercent;

    public StartSessionRequestDto() {}

    public Long getBookingId() {
        return bookingId;
    }

    public void setBookingId(Long bookingId) {
        this.bookingId = bookingId;
    }

    public Long getDriverId() {
        return driverId;
    }

    public void setDriverId(Long driverId) {
        this.driverId = driverId;
    }

    public Long getChargerId() {
        return chargerId;
    }

    public void setChargerId(Long chargerId) {
        this.chargerId = chargerId;
    }

    public Double getCurrentBatteryPercent() {
        return currentBatteryPercent;
    }

    public void setCurrentBatteryPercent(Double currentBatteryPercent) {
        this.currentBatteryPercent = currentBatteryPercent;
    }

    public Double getTargetBatteryPercent() {
        return targetBatteryPercent;
    }

    public void setTargetBatteryPercent(Double targetBatteryPercent) {
        this.targetBatteryPercent = targetBatteryPercent;
    }
}
