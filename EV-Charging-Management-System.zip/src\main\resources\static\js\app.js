/**
 * VoltPulse EV Charging Management System
 * Frontend Client Orchestration
 */

// Global State
const state = {
    currentUser: null,
    stations: [],
    currentView: "dashboard",
    activeSession: null,
    simulationTimer: null,
    sessionElapsedSeconds: 0,
    googleMap: null,
    googleMarkers: [],
    currentInvoice: null,
    areas: []
};

// ==================== INITIALIZATION ====================
document.addEventListener("DOMContentLoaded", () => {
    initNavigation();
    initLogoutButtons();
    initDriverLoginGate();
    initDedicatedLocationSearch();
    initFilterListeners();
    loadDashboardStats();
    loadStations();
    loadAreas();
    checkGoogleMapsConfig();
    loadDriverBookings();
    loadDriverInvoices();

    // Check URL Hash for deep links
    const hash = window.location.hash.replace("#", "");
    if (hash) {
        switchView(hash);
    }
});

// ==================== NAVIGATION ====================
function initNavigation() {
    document.querySelectorAll(".nav-item").forEach(item => {
        item.addEventListener("click", (e) => {
            e.preventDefault();
            const viewId = item.getAttribute("data-view");
            switchView(viewId);
        });
    });

    // Mobile Sidebar toggle
    const toggleBtn = document.getElementById("mobile-sidebar-toggle");
    const sidebar = document.getElementById("sidebar");
    if (toggleBtn && sidebar) {
        toggleBtn.addEventListener("click", () => {
            sidebar.classList.toggle("mobile-open");
        });
    }
}

function switchView(viewId) {
    state.currentView = viewId;
    window.location.hash = viewId;

    // Update active nav link
    document.querySelectorAll(".nav-item").forEach(item => {
        item.classList.toggle("active", item.getAttribute("data-view") === viewId);
    });

    // Update view sections
    document.querySelectorAll(".content-section").forEach(sec => {
        sec.classList.remove("active");
    });

    const activeSec = document.getElementById(`view-${viewId}`);
    if (activeSec) {
        activeSec.classList.add("active");
    }

    // Update Page Header Title
    const titles = {
        "dashboard": { title: "EV Charging Dashboard", sub: "Real-time telemetry, station availability, and smart grid orchestration" },
        "stations": { title: "Charging Stations Directory", sub: "Find, filter, and reserve high-speed EV dispensers across Hyderabad" },
        "map-view": { title: "Interactive Geospatial Station Map", sub: "Live mapped grid points with operational states and navigation links" },
        "simulator": { title: "Live Charging Telemetry Simulator", sub: "Simulate electric current draw, live battery saturation, and meter billing" },
        "bookings": { title: "Charging Slot Reservations", sub: "Your upcoming reserved charging sessions and historical logs" },
        "driver-profile": { title: "EV Driver Profile & Wallet", sub: "Vehicle technical specifications, RFID access, and pre-funded eco-wallet" },
        "admin-stations": { title: "Station & Charger Governance", sub: "Administrator hub management, dispenser provisioning, and maintenance controls" },
        "admin-bookings": { title: "Network Slot Reservations Audit", sub: "System-wide booking activity across Hyderabad charging stations" },
        "admin-invoices": { title: "Network Revenue & Settlements", sub: "Audited financial invoices and polymorphic payment transactions" },
        "oop-architecture": { title: "OOP Architecture Specifications", sub: "Detailed technical mapping of OOP design principles implemented in Java" }
    };

    if (titles[viewId]) {
        document.getElementById("page-title").textContent = titles[viewId].title;
        document.getElementById("page-subtitle").textContent = titles[viewId].sub;
    }

    // Close mobile sidebar if open
    document.getElementById("sidebar").classList.remove("mobile-open");

    // View specific hooks
    if (viewId === "map-view") {
        renderMap();
    } else if (viewId === "admin-stations") {
        loadAdminStations();
    } else if (viewId === "admin-bookings") {
        loadAdminBookings();
    } else if (viewId === "admin-invoices") {
        loadAdminInvoices();
    }
}

// ==================== PROFILE & AUTHENTICATION ====================
function initLogoutButtons() {
    const topLogout = document.getElementById("topbar-logout-btn");
    if (topLogout) {
        topLogout.addEventListener("click", handleUserLogout);
    }
    const sideLogout = document.getElementById("sidebar-logout-btn");
    if (sideLogout) {
        sideLogout.addEventListener("click", handleUserLogout);
    }
}

function setPersona(user) {
    state.currentUser = user;

    // Update UI Elements
    const nameEl = document.getElementById("current-user-name");
    if (nameEl) nameEl.textContent = user.name;
    const roleBadge = document.getElementById("current-user-role-badge");
    if (roleBadge) roleBadge.textContent = user.role === "ADMIN" ? "Station Admin" : "EV Driver";

    const avatar = document.getElementById("current-user-avatar");
    if (avatar) {
        if (user.role === "ADMIN") {
            avatar.innerHTML = '<i class="fa-solid fa-user-shield"></i>';
            avatar.style.background = "linear-gradient(135deg, #f59e0b, #d97706)";
        } else {
            avatar.innerHTML = '<i class="fa-solid fa-user-astronaut"></i>';
            avatar.style.background = "linear-gradient(135deg, #3b82f6, #06b6d4)";
        }
    }

    // Toggle Role-Specific Navigation items
    const isDriver = user.role === "EV_DRIVER";
    document.querySelectorAll(".driver-only").forEach(el => {
        el.style.display = isDriver ? "" : "none";
    });
    document.querySelectorAll(".admin-only").forEach(el => {
        el.style.display = isDriver ? "none" : "";
    });

    if (isDriver) {
        updateWalletDisplay(user.walletBalance);
        updateProfileDisplay(user);
        loadDriverBookings();
        loadDriverInvoices();
    }

    // If currently on admin page as driver, return to dashboard
    if (isDriver && state.currentView.startsWith("admin-")) {
        switchView("dashboard");
    } else if (!isDriver && (state.currentView === "bookings" || state.currentView === "driver-profile")) {
        switchView("admin-stations");
    }
}

function updateWalletDisplay(amount) {
    const formatted = `₹${parseFloat(amount || 0).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    const topPill = document.getElementById("topbar-wallet-amount");
    if (topPill) topPill.textContent = formatted;

    const profPill = document.getElementById("prof-wallet-balance");
    if (profPill) profPill.textContent = formatted;

    const payWalletAvail = document.getElementById("pay-wallet-avail");
    if (payWalletAvail) payWalletAvail.textContent = formatted;
}

function updateProfileDisplay(user) {
    const topName = document.getElementById("topbar-driver-name");
    if (topName) topName.textContent = user.name;

    const topCar = document.getElementById("topbar-driver-car");
    if (topCar) topCar.textContent = user.vehicleModel || "Electric Vehicle";

    const sideName = document.getElementById("current-user-name");
    if (sideName) sideName.textContent = user.name;

    if (document.getElementById("prof-driver-name")) {
        document.getElementById("prof-driver-name").textContent = user.name;
        document.getElementById("prof-driver-email").textContent = user.email;
        document.getElementById("prof-driver-phone").textContent = user.phone;
        document.getElementById("prof-vehicle-model").textContent = user.vehicleModel || "Tata Nexon EV Max";
        document.getElementById("prof-vehicle-reg").textContent = user.vehicleRegistrationNumber || "TS 09 EV 4521";
        document.getElementById("prof-battery-cap").textContent = `${user.batteryCapacityKwh || 40.5} kWh`;
        document.getElementById("prof-connector").textContent = `${user.preferredConnectorType || "CCS2"} (DC Fast)`;

        // Form initial values
        document.getElementById("veh-model-input").value = user.vehicleModel || "Tata Nexon EV Max";
        document.getElementById("veh-reg-input").value = user.vehicleRegistrationNumber || "TS 09 EV 4521";
        document.getElementById("veh-kwh-input").value = user.batteryCapacityKwh || 40.5;
        document.getElementById("veh-conn-input").value = user.preferredConnectorType || "CCS2";

        // Simulator vehicle header
        const simVeh = document.getElementById("sim-vehicle-title");
        if (simVeh) simVeh.textContent = `${user.vehicleModel} [${user.vehicleRegistrationNumber}]`;
    }
}

// ==================== DASHBOARD & STATS ====================
async function loadDashboardStats() {
    try {
        const res = await fetch("/api/analytics/dashboard");
        if (!res.ok) throw new Error("Failed to load dashboard metrics");
        const data = await res.json();

        document.getElementById("stat-total-stations").textContent = data.totalStations || 0;
        document.getElementById("stat-available-chargers").textContent = data.availableChargers || 0;
        document.getElementById("stat-total-chargers-sub").textContent = `${data.totalChargers || 0} Total Ports`;
        document.getElementById("stat-energy-kwh").textContent = `${data.totalEnergyDeliveredKwh || 0} kWh`;
        document.getElementById("stat-total-revenue").textContent = `₹${parseFloat(data.totalRevenue || 0).toLocaleString("en-IN", { minimumFractionDigits: 2 })}`;

        const navCount = document.getElementById("nav-station-count");
        if (navCount) navCount.textContent = data.totalStations || 8;
    } catch (err) {
        console.error("Dashboard stats error:", err);
    }
}

// ==================== STATIONS DIRECTORY ====================
async function loadStations() {
    try {
        const res = await fetch("/api/stations");
        if (!res.ok) throw new Error("Failed to fetch stations");
        state.stations = await res.json();

        renderDashboardFeaturedStations(state.stations);
        renderStationsGrid(state.stations);
        populateSimulatorStations(state.stations);
        renderRadarPins(state.stations);
        updateLocationSearchCounter(state.stations);
        if (state.googleMap) {
            initGoogleMapMarkers();
        }

        const navCount = document.getElementById("nav-station-count");
        if (navCount) navCount.textContent = state.stations.length;
        const totalStEl = document.getElementById("stat-total-stations");
        if (totalStEl) totalStEl.textContent = state.stations.length;
    } catch (err) {
        console.error("Error loading stations:", err);
        showToast("Error loading station network data", "error");
    }
}

async function loadAreas() {
    try {
        const res = await fetch("/api/stations/areas");
        if (res.ok) {
            state.areas = await res.json();
            const filterSelect = document.getElementById("filter-area");
            if (filterSelect) {
                filterSelect.innerHTML = '<option value="ALL">All Localities</option>' +
                    state.areas.map(a => `<option value="${a}">${a}</option>`).join("");
            }
        }

        const cityRes = await fetch("/api/stations/cities");
        if (cityRes.ok) {
            const cities = await cityRes.json();
            const citySelect = document.getElementById("filter-city");
            if (citySelect) {
                citySelect.innerHTML = '<option value="ALL">All Cities (India)</option>' +
                    cities.map(c => `<option value="${c}">${c}</option>`).join("");
                citySelect.addEventListener("change", (e) => {
                    const chosen = e.target.value;
                    filterStationsByLocation(chosen === "ALL" ? "" : chosen);
                });
            }
        }
    } catch (err) {
        console.warn("Error loading areas/cities:", err);
    }
}

function initFilterListeners() {
    const searchInput = document.getElementById("station-search-input");
    const clearBtn = document.getElementById("clear-search-btn");
    const areaSelect = document.getElementById("filter-area");
    const connSelect = document.getElementById("filter-connector");
    const powerSelect = document.getElementById("filter-power");
    const availCheck = document.getElementById("filter-available-only");
    const resetBtn = document.getElementById("reset-filters-btn");

    if (searchInput) {
        searchInput.addEventListener("input", () => {
            clearBtn.style.display = searchInput.value ? "block" : "none";
            applyStationFilters();
        });
    }

    if (clearBtn) {
        clearBtn.addEventListener("click", () => {
            searchInput.value = "";
            clearBtn.style.display = "none";
            applyStationFilters();
        });
    }

    [areaSelect, connSelect, powerSelect, availCheck].forEach(elem => {
        if (elem) elem.addEventListener("change", applyStationFilters);
    });

    if (resetBtn) {
        resetBtn.addEventListener("click", () => {
            if (searchInput) searchInput.value = "";
            if (clearBtn) clearBtn.style.display = "none";
            if (areaSelect) areaSelect.value = "ALL";
            if (connSelect) connSelect.value = "ALL";
            if (powerSelect) powerSelect.value = "0";
            if (availCheck) availCheck.checked = false;
            applyStationFilters();
        });
    }

    // Quick area chip buttons on Dashboard
    document.querySelectorAll(".area-chip").forEach(chip => {
        chip.addEventListener("click", () => {
            document.querySelectorAll(".area-chip").forEach(c => c.classList.remove("active"));
            chip.classList.add("active");
            const area = chip.getAttribute("data-area");
            if (areaSelect) {
                areaSelect.value = area;
                switchView("stations");
                applyStationFilters();
            }
        });
    });
}

async function applyStationFilters() {
    const query = document.getElementById("station-search-input")?.value.trim() || "";
    const area = document.getElementById("filter-area")?.value || "ALL";
    const connector = document.getElementById("filter-connector")?.value || "ALL";
    const minPower = document.getElementById("filter-power")?.value || "0";
    const availableOnly = document.getElementById("filter-available-only")?.checked || false;

    const params = new URLSearchParams();
    if (query) params.append("query", query);
    if (area && area !== "ALL") params.append("area", area);
    if (connector && connector !== "ALL") params.append("connectorType", connector);
    if (minPower && minPower !== "0") params.append("minPower", minPower);
    if (availableOnly) params.append("availableOnly", "true");

    try {
        const res = await fetch(`/api/stations?${params.toString()}`);
        if (!res.ok) throw new Error("Search failed");
        const filtered = await res.json();
        renderStationsGrid(filtered);

        const countLabel = document.getElementById("filter-results-count");
        if (countLabel) {
            countLabel.textContent = `Showing ${filtered.length} charging station${filtered.length === 1 ? '' : 's'}`;
        }
    } catch (err) {
        console.error("Filter error:", err);
    }
}

function renderStationsGrid(stations) {
    const grid = document.getElementById("stations-list-grid");
    if (!grid) return;

    if (!stations || stations.length === 0) {
        grid.innerHTML = `
            <div class="empty-state-card" style="grid-column: 1/-1; text-align: center; padding: 48px; background: var(--bg-card); border-radius: var(--radius-md);">
                <i class="fa-solid fa-charging-station" style="font-size: 36px; color: var(--text-muted); margin-bottom: 12px;"></i>
                <h3>No Charging Stations Found</h3>
                <p class="text-muted">No stations match the selected filters. Try broadening your search or resetting filters.</p>
            </div>
        `;
        return;
    }

    grid.innerHTML = stations.map(s => createStationCardHTML(s, false)).join("");
}

function renderDashboardFeaturedStations(stations) {
    const grid = document.getElementById("dashboard-stations-grid");
    if (!grid) return;
    grid.innerHTML = stations.map(s => createStationCardHTML(s, true)).join("");
}

function createStationCardHTML(st, isCompact) {
    const totalChargers = st.chargers ? st.chargers.length : 0;
    const availChargers = st.chargers ? st.chargers.filter(c => c.status === "AVAILABLE").length : 0;
    const isAvailable = availChargers > 0;

    const connectorTags = st.chargers ? Array.from(new Set(st.chargers.map(c => c.connectorType)))
        .map(type => `<span class="connector-pill">${type}</span>`).join("") : "";

    const lowestRate = st.chargers && st.chargers.length > 0 
        ? Math.min(...st.chargers.map(c => c.ratePerKwh)).toFixed(2)
        : "18.00";

    const maxPower = st.chargers && st.chargers.length > 0
        ? Math.max(...st.chargers.map(c => c.powerRatingKw)).toFixed(0)
        : "50";

    return `
        <div class="station-card" id="station-card-${st.id}">
            <div>
                <div class="st-card-header">
                    <div>
                        <h3 class="st-title">${st.name}</h3>
                        <span class="st-area-badge"><i class="fa-solid fa-location-dot"></i> ${st.area}${st.city ? ', ' + st.city : ''}</span>
                        ${st.state ? `<span class="st-area-badge" style="margin-left:4px; opacity:0.85;">${st.state}</span>` : ''}
                    </div>
                    <span class="badge ${isAvailable ? 'badge-available' : 'badge-maintenance'}">
                        ${isAvailable ? `${availChargers}/${totalChargers} Available` : 'Fully Occupied'}
                    </span>
                </div>

                <p class="st-address">${st.address}</p>
                <div class="st-chargers-summary">${connectorTags}</div>

                <div class="st-metrics-row">
                    <div class="st-metric-item">
                        <span>Speed up to: </span>
                        <strong>${maxPower} kW</strong>
                    </div>
                    <div class="st-metric-item">
                        <span>Tariff: </span>
                        <strong class="text-accent">₹${lowestRate}/kWh</strong>
                    </div>
                    <div class="st-metric-item">
                        <span>Hours: </span>
                        <span>${st.operatingHours || '24/7'}</span>
                    </div>
                </div>
            </div>

            <div class="st-card-actions">
                <button class="btn btn-outline btn-sm" onclick="openBookingModal(${st.id})">
                    <i class="fa-solid fa-calendar-check"></i> Book Slot
                </button>
                <button class="btn btn-primary btn-sm" onclick="startSessionFromStation(${st.id})">
                    <i class="fa-solid fa-bolt"></i> Charge Now
                </button>
            </div>
        </div>
    `;
}

// ==================== MAP INTEGRATION ====================
async function checkGoogleMapsConfig() {
    try {
        const res = await fetch("/api/config/maps");
        if (!res.ok) return;
        const config = await res.json();

        if (config.hasValidKey && config.apiKey) {
            loadGoogleMapsScript(config.apiKey);
        } else {
            console.log("Using integrated high-precision Hyderabad vector map (Google Maps key is optional).");
        }
    } catch (err) {
        console.warn("Could not check Google Maps config:", err);
    }
}

function loadGoogleMapsScript(apiKey) {
    if (window.google && window.google.maps) {
        initGoogleMap();
        return;
    }

    const script = document.createElement("script");
    script.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&callback=initGoogleMap`;
    script.async = true;
    script.defer = true;
    window.initGoogleMap = initGoogleMap;
    document.head.appendChild(script);
}

function initGoogleMap() {
    const mapCanvas = document.getElementById("google-map-canvas");
    const vectorCanvas = document.getElementById("vector-map-canvas");
    const banner = document.getElementById("map-banner-message");

    if (mapCanvas && vectorCanvas) {
        mapCanvas.style.display = "block";
        vectorCanvas.style.display = "none";
        if (banner) {
            banner.innerHTML = "<strong>Google Maps Active:</strong> Live satellite and vector map rendered across India using your configured API Key.";
        }

        const indiaCenter = { lat: 21.7679, lng: 78.8718 };
        state.googleMap = new google.maps.Map(mapCanvas, {
            center: indiaCenter,
            zoom: 5,
            mapId: "DEMO_MAP_ID",
            styles: [
                { elementType: "geometry", stylers: [{ color: "#162032" }] },
                { elementType: "labels.text.stroke", stylers: [{ color: "#162032" }] },
                { elementType: "labels.text.fill", stylers: [{ color: "#94a3b8" }] },
                { featureType: "road", elementType: "geometry", stylers: [{ color: "#22324d" }] },
                { featureType: "water", elementType: "geometry", stylers: [{ color: "#0b1322" }] }
            ]
        });

        initGoogleMapMarkers();
    }
}

function initGoogleMapMarkers(stationsToRender = state.stations) {
    if (!state.googleMap || !window.google || !window.google.maps) return;

    // Clear previous markers
    if (state.googleMarkers && state.googleMarkers.length > 0) {
        state.googleMarkers.forEach(m => m.setMap(null));
    }
    state.googleMarkers = [];

    stationsToRender.forEach(st => {
        const total = st.chargers ? st.chargers.length : 0;
        const avail = st.chargers ? st.chargers.filter(c => c.status === "AVAILABLE").length : 0;
        const lowestRate = st.chargers && st.chargers.length > 0
            ? Math.min(...st.chargers.map(c => c.ratePerKwh)).toFixed(2)
            : "18.00";

        const marker = new google.maps.Marker({
            position: { lat: st.latitude, lng: st.longitude },
            map: state.googleMap,
            title: st.name
        });

        const infoWindow = new google.maps.InfoWindow({
            content: `
                <div style="color: #111827; padding: 10px; font-family: 'Plus Jakarta Sans', sans-serif; min-width: 200px;">
                    <h4 style="margin: 0 0 4px 0; font-weight: bold; color: #0a0e17;">${st.name}</h4>
                    <p style="margin: 0 0 6px 0; font-size: 12px; color: #4b5563;">${st.address}</p>
                    <div style="margin: 0 0 8px 0; font-size: 12px;">
                        <span style="display:inline-block; padding: 2px 6px; border-radius: 4px; background: ${avail > 0 ? '#dcfce7' : '#fee2e2'}; color: ${avail > 0 ? '#166534' : '#991b1b'}; font-weight: bold;">
                            ${avail > 0 ? `${avail}/${total} Chargers Available` : 'Fully Occupied'}
                        </span>
                        <div style="margin-top: 4px; font-weight: 600;">Tariff: ₹${lowestRate}/kWh</div>
                    </div>
                    <button onclick="openBookingModal(${st.id})" style="background: #00e599; color: #04121a; border: none; padding: 6px 12px; border-radius: 6px; font-weight: bold; cursor: pointer; width: 100%;">
                        Book Charging Slot
                    </button>
                </div>
            `
        });

        marker.addListener("click", () => {
            infoWindow.open(state.googleMap, marker);
        });

        state.googleMarkers.push(marker);
    });
}

function renderMap() {
    if (state.googleMap) {
        google.maps.event.trigger(state.googleMap, "resize");
    } else {
        renderRadarPins(state.stations);
    }
}

function renderRadarPins(stations) {
    const container = document.getElementById("radar-svg-container");
    const miniContainer = document.getElementById("mini-station-pins");
    if (!container && !miniContainer) return;
    if (!stations || stations.length === 0) {
        if (container) container.innerHTML = '<div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);color:#64748b;">No stations mapped in this area</div>';
        if (miniContainer) miniContainer.innerHTML = '';
        return;
    }

    // Adaptive Coordinate Projection across India or focused area
    const lats = stations.map(s => s.latitude);
    const lngs = stations.map(s => s.longitude);
    let minLat = Math.min(...lats);
    let maxLat = Math.max(...lats);
    let minLng = Math.min(...lngs);
    let maxLng = Math.max(...lngs);

    if (maxLat - minLat < 0.1) { minLat -= 0.15; maxLat += 0.15; }
    if (maxLng - minLng < 0.1) { minLng -= 0.15; maxLng += 0.15; }

    const latPad = (maxLat - minLat) * 0.15;
    const lngPad = (maxLng - minLng) * 0.15;
    minLat -= latPad; maxLat += latPad;
    minLng -= lngPad; maxLng += lngPad;

    const pinsHtml = stations.map(st => {
        const xPct = ((st.longitude - minLng) / (maxLng - minLng)) * 100;
        const yPct = 100 - (((st.latitude - minLat) / (maxLat - minLat)) * 100);

        const clampedX = Math.max(8, Math.min(92, xPct));
        const clampedY = Math.max(8, Math.min(92, yPct));

        const avail = st.chargers && st.chargers.some(c => c.status === "AVAILABLE");

        return `
            <div class="radar-pin" style="left: ${clampedX}%; top: ${clampedY}%;" onclick="showMapStationDrawer(${st.id})">
                <div class="pin-beacon ${avail ? '' : 'busy'}">
                    <span class="pin-pulse-ring"></span>
                </div>
                <div class="pin-tooltip">
                    <strong>${st.name}</strong><br>
                    <span style="color: var(--accent-cyan);">${st.area}${st.city ? ', ' + st.city : ''}</span> • ${avail ? 'Available' : 'Busy'}
                </div>
            </div>
        `;
    }).join("");

    if (container) container.innerHTML = pinsHtml;
    if (miniContainer) miniContainer.innerHTML = pinsHtml;
}

function showMapStationDrawer(stationId) {
    const st = state.stations.find(s => s.id === stationId);
    if (!st) return;

    const drawer = document.getElementById("map-station-drawer");
    const content = document.getElementById("map-drawer-content");
    if (!drawer || !content) return;

    const availChargers = st.chargers ? st.chargers.filter(c => c.status === "AVAILABLE").length : 0;
    const totalChargers = st.chargers ? st.chargers.length : 0;

    content.innerHTML = `
        <span class="badge ${availChargers > 0 ? 'badge-available' : 'badge-maintenance'} mb-2">
            ${availChargers}/${totalChargers} Available Ports
        </span>
        <h3 class="mt-2 mb-1">${st.name}</h3>
        <p class="text-muted text-sm mb-3">${st.address}</p>

        <div class="st-metrics-row mb-3">
            <div class="st-metric-item">
                <span>Fastest Port:</span>
                <strong>${st.maxPowerKw || 60} kW</strong>
            </div>
            <div class="st-metric-item">
                <span>Base Tariff:</span>
                <strong class="text-accent">₹${st.minRatePerKwh || 18.50}/kWh</strong>
            </div>
        </div>

        <div class="mb-3">
            <strong class="text-sm d-block mb-1">Available Charging Dispensers:</strong>
            <div style="display: flex; flex-direction: column; gap: 8px;">
                ${st.chargers.map(c => `
                    <div style="background: rgba(255,255,255,0.03); border: 1px solid var(--border-subtle); border-radius: 6px; padding: 8px 12px; display: flex; justify-content: space-between; align-items: center; font-size: 12px;">
                        <div>
                            <strong>${c.identifier}</strong> • ${c.connectorType} (${c.powerRatingKw}kW)
                        </div>
                        <span class="badge ${c.status === 'AVAILABLE' ? 'badge-available' : 'badge-maintenance'}" style="font-size: 10px;">
                            ${c.status}
                        </span>
                    </div>
                `).join("")}
            </div>
        </div>

        <div class="mb-3">
            <strong class="text-sm d-block mb-1">On-Site Amenities:</strong>
            <p class="text-muted text-sm">${st.amenities || "EV Lounge, Restrooms, Free Wi-Fi"}</p>
        </div>

        <div style="display: flex; gap: 10px; margin-top: 20px;">
            <button class="btn btn-outline btn-block btn-sm" onclick="openBookingModal(${st.id})">
                <i class="fa-solid fa-calendar-check"></i> Reserve Slot
            </button>
            <button class="btn btn-primary btn-block btn-sm" onclick="startSessionFromStation(${st.id})">
                <i class="fa-solid fa-bolt"></i> Charge Now
            </button>
        </div>
    `;

    drawer.style.display = "block";
    document.getElementById("close-drawer-btn")?.addEventListener("click", () => {
        drawer.style.display = "none";
    });
}

// ==================== BOOKING MODAL & FLOW ====================
function openBookingModal(stationId) {
    const st = state.stations.find(s => s.id === stationId);
    if (!st) return;

    document.getElementById("book-station-id").value = st.id;
    const brief = document.getElementById("modal-station-brief");
    brief.innerHTML = `
        <h4 style="color:#fff;">${st.name}</h4>
        <p class="text-muted" style="font-size: 12px;">${st.address} • Area: ${st.area}</p>
    `;

    // Populate chargers dropdown
    const chargerSelect = document.getElementById("book-charger-select");
    chargerSelect.innerHTML = st.chargers.map(c => `
        <option value="${c.id}" data-rate="${c.ratePerKwh}" data-power="${c.powerRatingKw}" ${c.status !== 'AVAILABLE' ? 'disabled' : ''}>
            ${c.identifier} - ${c.connectorType} (${c.powerRatingKw}kW) - ₹${c.ratePerKwh}/kWh ${c.status !== 'AVAILABLE' ? `[${c.status}]` : ''}
        </option>
    `).join("");

    // Set default date to today and time to next 30 mins
    const now = new Date();
    document.getElementById("book-date").value = now.toISOString().split("T")[0];
    const nextHour = new Date(now.getTime() + 30 * 60000);
    const hours = String(nextHour.getHours()).padStart(2, "0");
    const mins = String(nextHour.getMinutes()).padStart(2, "0");
    document.getElementById("book-time").value = `${hours}:${mins}`;

    updateBookingCostEstimate();
    openModal("booking-modal");
}

function updateBookingCostEstimate() {
    const chargerSelect = document.getElementById("book-charger-select");
    const selectedOpt = chargerSelect?.selectedOptions[0];
    if (!selectedOpt) return;

    const rate = parseFloat(selectedOpt.getAttribute("data-rate") || "18.5");
    const power = parseFloat(selectedOpt.getAttribute("data-power") || "50");
    const durationMins = parseInt(document.getElementById("book-duration")?.value || "45");
    const targetKwhInput = parseFloat(document.getElementById("book-target-kwh")?.value || "25");

    // Theoretical delivery = power * (duration / 60) * 0.85
    const estimatedKwh = Math.min(targetKwhInput, Math.round(power * (durationMins / 60) * 0.85 * 10) / 10);
    const baseCost = estimatedKwh * rate;
    const gst = baseCost * 0.18;
    const total = baseCost + gst;

    document.getElementById("book-est-kwh").textContent = `${estimatedKwh.toFixed(1)} kWh`;
    document.getElementById("book-est-rate").textContent = `₹${rate.toFixed(2)}/kWh`;
    document.getElementById("book-est-gst").textContent = `₹${gst.toFixed(2)}`;
    document.getElementById("book-est-total").textContent = `₹${total.toFixed(2)}`;
}

async function handleBookingSubmit(e) {
    e.preventDefault();
    if (!state.currentUser || !state.currentUser.id) {
        showToast("Please log in or create a profile to reserve a slot.", "error");
        openLoginModal(true);
        return;
    }

    const btn = document.getElementById("book-submit-btn");
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Reserving...';

    const chargerId = document.getElementById("book-charger-select").value;
    const dateStr = document.getElementById("book-date").value;
    const timeStr = document.getElementById("book-time").value;
    const duration = parseInt(document.getElementById("book-duration").value);
    const targetKwh = parseFloat(document.getElementById("book-target-kwh").value);

    const startTime = `${dateStr}T${timeStr}:00`;

    const payload = {
        driverId: state.currentUser.id,
        chargerId: parseInt(chargerId),
        startTime: startTime,
        durationMinutes: duration,
        targetBatteryKwh: targetKwh
    };

    try {
        const res = await fetch("/api/bookings", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });

        const data = await res.json();
        if (!res.ok) {
            throw new Error(data.message || "Failed to reserve slot");
        }

        closeModal("booking-modal");
        showToast(`Slot reserved successfully! Booking Ref: ${data.bookingReference}`, "success");
        loadDriverBookings();
        loadDashboardStats();
    } catch (err) {
        console.error("Booking error:", err);
        showToast(err.message, "error");
    } finally {
        btn.disabled = false;
        btn.innerHTML = '<i class="fa-solid fa-check"></i> Confirm Reservation';
    }
}

// ==================== DRIVER BOOKINGS & HISTORY ====================
async function loadDriverBookings() {
    const container = document.getElementById("driver-bookings-container");
    if (!container) return;
    if (!state.currentUser || !state.currentUser.id) {
        container.innerHTML = `
            <div style="padding: 48px; text-align: center;">
                <i class="fa-solid fa-arrow-right-to-bracket" style="font-size: 32px; color: var(--text-muted); margin-bottom: 12px;"></i>
                <h4>Profile Logged Out</h4>
                <p class="text-muted">Please log in or create a profile to view your charging reservations.</p>
            </div>
        `;
        return;
    }

    try {
        const res = await fetch(`/api/bookings?driverId=${state.currentUser.id}`);
        if (!res.ok) throw new Error("Failed to load driver bookings");
        const bookings = await res.json();

        if (bookings.length === 0) {
            container.innerHTML = `
                <div style="padding: 48px; text-align: center;">
                    <i class="fa-solid fa-calendar-xmark" style="font-size: 32px; color: var(--text-muted); margin-bottom: 12px;"></i>
                    <h4>No Slot Bookings Yet</h4>
                    <p class="text-muted">You haven't reserved any charging slots. Explore stations and book your preferred time.</p>
                </div>
            `;
            return;
        }

        container.innerHTML = `
            <table class="custom-table">
                <thead>
                    <tr>
                        <th>Reference</th>
                        <th>Station</th>
                        <th>Charger</th>
                        <th>Slot Window</th>
                        <th>Est. Units & Cost</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    ${bookings.map(b => {
                        const start = new Date(b.startTime).toLocaleString("en-IN", { dateStyle: "short", timeStyle: "short" });
                        const end = new Date(b.endTime).toLocaleTimeString("en-IN", { timeStyle: "short" });
                        return `
                            <tr>
                                <td><code style="color: var(--accent-cyan);">${b.bookingReference}</code></td>
                                <td><strong>${b.station.name}</strong><br><small class="text-muted">${b.station.area}</small></td>
                                <td>${b.charger.identifier} (${b.charger.connectorType})</td>
                                <td>${start} - ${end}</td>
                                <td>${b.estimatedKwh || 0} kWh • <strong class="text-accent">₹${b.estimatedCost}</strong></td>
                                <td><span class="badge badge-${b.status.toLowerCase()}">${b.status}</span></td>
                                <td>
                                    ${b.status === "CONFIRMED" ? `
                                        <button class="btn btn-danger btn-sm" onclick="cancelBooking(${b.id})">
                                            Cancel
                                        </button>
                                    ` : b.status === "ACTIVE" ? `
                                        <button class="btn btn-cyan btn-sm" onclick="switchView('simulator')">
                                            View Sim
                                        </button>
                                    ` : `
                                        <span class="text-muted" style="font-size: 12px;">Completed</span>
                                    `}
                                </td>
                            </tr>
                        `;
                    }).join("")}
                </tbody>
            </table>
        `;
    } catch (err) {
        console.error("Error loading driver bookings:", err);
    }
}

async function cancelBooking(bookingId) {
    if (!confirm("Are you sure you want to cancel this charging slot reservation?")) return;

    try {
        const res = await fetch(`/api/bookings/${bookingId}/cancel`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ reason: "Cancelled by EV driver via dashboard" })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.message || "Failed to cancel");

        showToast("Slot reservation cancelled successfully", "info");
        loadDriverBookings();
        loadDashboardStats();
    } catch (err) {
        showToast(err.message, "error");
    }
}

// ==================== LIVE CHARGING SIMULATOR ====================
function populateSimulatorStations(stations) {
    const simStationSelect = document.getElementById("sim-station-select");
    if (!simStationSelect) return;

    simStationSelect.innerHTML = '<option value="">-- Choose Hyderabad Station --</option>' +
        stations.map(s => `<option value="${s.id}">${s.name} (${s.area})</option>`).join("");

    simStationSelect.addEventListener("change", (e) => {
        const stId = parseInt(e.target.value);
        const chargerSelect = document.getElementById("sim-charger-select");
        if (!stId) {
            chargerSelect.disabled = true;
            chargerSelect.innerHTML = '<option value="">-- Choose Charger First --</option>';
            return;
        }

        const selectedSt = state.stations.find(s => s.id === stId);
        if (selectedSt && selectedSt.chargers) {
            chargerSelect.disabled = false;
            chargerSelect.innerHTML = selectedSt.chargers.map(c => `
                <option value="${c.id}" data-rate="${c.ratePerKwh}" data-power="${c.powerRatingKw}">
                    ${c.identifier} - ${c.connectorType} (${c.powerRatingKw}kW) - ₹${c.ratePerKwh}/kWh
                </option>
            `).join("");
        }
    });

    document.getElementById("sim-start-btn")?.addEventListener("click", startSimulatorSession);
    document.getElementById("sim-tick-btn")?.addEventListener("click", tickSimulatorSession);
    document.getElementById("sim-stop-btn")?.addEventListener("click", stopSimulatorSession);
}

function startSessionFromStation(stationId) {
    switchView("simulator");
    const stSelect = document.getElementById("sim-station-select");
    if (stSelect) {
        stSelect.value = stationId;
        stSelect.dispatchEvent(new Event("change"));
    }
}

async function startSimulatorSession() {
    if (!state.currentUser || !state.currentUser.id) {
        showToast("Please log in or create a profile to start a charging session.", "error");
        openLoginModal(true);
        return;
    }

    const stationId = document.getElementById("sim-station-select").value;
    const chargerId = document.getElementById("sim-charger-select").value;
    const initBattery = parseFloat(document.getElementById("sim-init-battery").value || "20");
    const targetBattery = parseFloat(document.getElementById("sim-target-battery").value || "85");

    if (!stationId || !chargerId) {
        showToast("Please choose a charging station and charger gun first", "error");
        return;
    }

    const payload = {
        driverId: state.currentUser.id,
        chargerId: parseInt(chargerId),
        currentBatteryPercent: initBattery,
        targetBatteryPercent: targetBattery
    };

    try {
        const res = await fetch("/api/charging/start", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });

        const session = await res.json();
        if (!res.ok) throw new Error(session.message || "Could not start charging session");

        state.activeSession = session;
        state.sessionElapsedSeconds = 0;
        showToast(`Charging initiated on ${session.charger.identifier}!`, "success");

        enterActiveSimulatorMode(session);
        startSimulationClock();
        loadDashboardStats();
    } catch (err) {
        showToast(err.message, "error");
    }
}

function enterActiveSimulatorMode(session) {
    document.getElementById("sim-setup-container").style.display = "none";
    document.getElementById("sim-active-controls").style.display = "block";

    const pill = document.getElementById("sim-status-pill");
    pill.textContent = "CHARGING LIVE";
    pill.className = "badge badge-success badge-pulse";

    const dashPill = document.getElementById("sim-live-badge");
    if (dashPill) {
        dashPill.textContent = "CHARGING LIVE";
        dashPill.className = "badge badge-success badge-pulse";
    }

    // Update session meta
    document.getElementById("sim-live-ref").textContent = session.sessionReference;
    document.getElementById("sim-live-station").textContent = session.station.name;
    document.getElementById("sim-live-charger").textContent = `${session.charger.identifier} (${session.charger.connectorType})`;
    document.getElementById("sim-live-rate").textContent = `₹${session.chargingRatePerKwh.toFixed(2)} / kWh`;

    // Indicators
    const topbarPill = document.getElementById("active-session-banner-btn");
    if (topbarPill) {
        topbarPill.style.display = "flex";
        document.getElementById("topbar-battery-pct").textContent = `${session.currentBatteryPercent}%`;
    }
    const dot = document.getElementById("live-session-indicator");
    if (dot) dot.style.display = "block";

    updateTelemetryDisplays(session);
}

function updateTelemetryDisplays(session) {
    const pct = Math.min(100, Math.round(session.currentBatteryPercent || 20));
    const kwh = parseFloat(session.unitsConsumedKwh || 0);
    const power = parseFloat(session.activePowerKw || session.charger?.powerRatingKw || 50);
    const rate = parseFloat(session.chargingRatePerKwh || 18.5);
    const liveCost = (kwh * rate * 1.18); // with GST

    // Big Battery
    const liquid = document.getElementById("sim-battery-liquid");
    if (liquid) liquid.style.width = `${pct}%`;

    const pctText = document.getElementById("sim-battery-percent-text");
    if (pctText) pctText.textContent = `${pct}%`;

    const statusText = document.getElementById("sim-battery-status-text");
    if (statusText) statusText.textContent = `Fast Charging • Target: ${session.targetBatteryPercent}%`;

    // Gauges
    document.getElementById("sim-disp-power").innerHTML = `${power.toFixed(1)} <small>kW</small>`;
    document.getElementById("sim-disp-kwh").innerHTML = `${kwh.toFixed(2)} <small>kWh</small>`;
    document.getElementById("sim-disp-cost").textContent = `₹${liveCost.toFixed(2)}`;

    // Dashboard Telemetry Box widgets
    const dashGauge = document.getElementById("dash-battery-gauge");
    if (dashGauge) {
        dashGauge.style.background = `conic-gradient(var(--accent-emerald) 0deg ${pct * 3.6}deg, rgba(255,255,255,0.08) ${pct * 3.6}deg 360deg)`;
    }
    const dashPct = document.getElementById("dash-gauge-pct");
    if (dashPct) dashPct.textContent = `${pct}%`;
    const dashSub = document.getElementById("dash-gauge-sub");
    if (dashSub) dashSub.textContent = `Dispensing @ ${power}kW`;

    const dPower = document.getElementById("dash-live-power");
    if (dPower) dPower.textContent = `${power.toFixed(1)} kW`;
    const dKwh = document.getElementById("dash-live-kwh");
    if (dKwh) dKwh.textContent = kwh.toFixed(2);
    const dCost = document.getElementById("dash-live-cost");
    if (dCost) dCost.textContent = `₹${liveCost.toFixed(2)}`;

    const topPct = document.getElementById("topbar-battery-pct");
    if (topPct) topPct.textContent = `${pct}%`;
}

function startSimulationClock() {
    if (state.simulationTimer) clearInterval(state.simulationTimer);

    state.simulationTimer = setInterval(() => {
        state.sessionElapsedSeconds += 1;
        const mins = String(Math.floor(state.sessionElapsedSeconds / 60)).padStart(2, "0");
        const secs = String(state.sessionElapsedSeconds % 60).padStart(2, "0");
        const dispTime = document.getElementById("sim-disp-time");
        if (dispTime) dispTime.textContent = `${mins}:${secs}`;

        // Auto-increment small realistic progress every 5 seconds
        if (state.sessionElapsedSeconds % 5 === 0 && state.activeSession) {
            autoIncrementSessionTick();
        }
    }, 1000);
}

async function autoIncrementSessionTick() {
    if (!state.activeSession) return;
    const power = state.activeSession.activePowerKw || 50;
    // Every 5 seconds at power kW adds approx: power * (5 / 3600) kWh
    const addedKwh = (power * (5 / 3600));
    const newKwh = (state.activeSession.unitsConsumedKwh || 0) + addedKwh;

    // Battery capacity is approx 40kWh, so added % = (addedKwh / 40) * 100
    const addedPct = (addedKwh / 40.5) * 100;
    const newPct = Math.min(state.activeSession.targetBatteryPercent, (state.activeSession.currentBatteryPercent || 20) + addedPct);

    state.activeSession.unitsConsumedKwh = newKwh;
    state.activeSession.currentBatteryPercent = newPct;

    updateTelemetryDisplays(state.activeSession);
}

async function tickSimulatorSession() {
    if (!state.activeSession) return;

    // Add +3.5 kWh on button press
    const currentKwh = (state.activeSession.unitsConsumedKwh || 0) + 3.5;
    const currentPct = Math.min(state.activeSession.targetBatteryPercent, (state.activeSession.currentBatteryPercent || 20) + 8.5);

    try {
        const res = await fetch(`/api/charging/${state.activeSession.id}/tick`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ progressKwh: currentKwh, batteryPercent: currentPct })
        });
        const updated = await res.json();
        state.activeSession = updated;
        updateTelemetryDisplays(updated);
        showToast(`Telemetry updated: +3.5 kWh delivered!`, "info");
    } catch (err) {
        console.error("Tick error:", err);
    }
}

async function stopSimulatorSession() {
    if (!state.activeSession) return;
    if (!confirm("Are you sure you want to stop charging and generate your final bill?")) return;

    if (state.simulationTimer) clearInterval(state.simulationTimer);

    try {
        const res = await fetch(`/api/charging/${state.activeSession.id}/stop`, {
            method: "POST"
        });
        const invoice = await res.json();
        if (!res.ok) throw new Error(invoice.message || "Failed to stop session");

        // Clear active state
        state.activeSession = null;
        document.getElementById("sim-setup-container").style.display = "block";
        document.getElementById("sim-active-controls").style.display = "none";

        const pill = document.getElementById("sim-status-pill");
        pill.textContent = "OFFLINE";
        pill.className = "badge";

        const dashPill = document.getElementById("sim-live-badge");
        if (dashPill) {
            dashPill.textContent = "STANDBY";
            dashPill.className = "badge badge-pulse";
        }

        const topbarPill = document.getElementById("active-session-banner-btn");
        if (topbarPill) topbarPill.style.display = "none";
        const dot = document.getElementById("live-session-indicator");
        if (dot) dot.style.display = "none";

        showToast("Charging completed. Opening Tax Invoice & Payment Settlement...", "success");

        // Open Polymorphic Payment Modal
        openPaymentModal(invoice);
        loadDashboardStats();
        loadStations(); // refresh charger availability
    } catch (err) {
        showToast(err.message, "error");
    }
}

// ==================== POLYMORPHIC PAYMENT MODAL & SETTLEMENT ====================
function openPaymentModal(invoice) {
    state.currentInvoice = invoice;

    document.getElementById("pay-inv-number").textContent = invoice.invoiceNumber;
    document.getElementById("pay-inv-date").textContent = new Date(invoice.invoiceDate || Date.now()).toLocaleDateString("en-IN", { dateStyle: "medium" });
    document.getElementById("pay-inv-kwh").textContent = `${invoice.unitsConsumedKwh.toFixed(2)} kWh`;
    document.getElementById("pay-inv-rate").textContent = `₹${invoice.ratePerKwh.toFixed(2)}/kWh`;
    document.getElementById("pay-inv-base").textContent = `₹${parseFloat(invoice.baseAmount).toFixed(2)}`;
    document.getElementById("pay-inv-gst").textContent = `₹${parseFloat(invoice.gstAmount).toFixed(2)}`;
    document.getElementById("pay-inv-total").textContent = `₹${parseFloat(invoice.totalAmount).toFixed(2)}`;

    // Set default payment method to UPI
    handlePaymentMethodChange("UPI");
    openModal("payment-modal");
}

async function handlePaymentMethodChange(method) {
    document.querySelectorAll(".pay-option").forEach(opt => {
        opt.classList.toggle("active", opt.getAttribute("data-type") === method);
    });

    // Toggle fields
    document.getElementById("fields-upi").style.display = method === "UPI" ? "block" : "none";
    document.getElementById("fields-card").style.display = method === "CREDIT_CARD" ? "block" : "none";
    document.getElementById("fields-wallet").style.display = method === "EV_WALLET" ? "block" : "none";

    if (!state.currentInvoice) return;

    // Call estimation API to get method-specific surcharge/discount
    try {
        const res = await fetch(`/api/payments/estimate?invoiceId=${state.currentInvoice.id}&paymentType=${method}`);
        if (!res.ok) return;
        const est = await res.json();

        const feeRow = document.getElementById("pay-fee-row");
        const cashRow = document.getElementById("pay-cashback-row");

        if (parseFloat(est.convenienceFee) > 0) {
            feeRow.style.display = "flex";
            document.getElementById("pay-inv-fee").textContent = `+ ₹${parseFloat(est.convenienceFee).toFixed(2)}`;
        } else {
            feeRow.style.display = "none";
        }

        if (parseFloat(est.estimatedCashback) > 0) {
            cashRow.style.display = "flex";
            document.getElementById("pay-inv-cashback").textContent = `- ₹${parseFloat(est.estimatedCashback).toFixed(2)} (Cashback)`;
        } else {
            cashRow.style.display = "none";
        }

        document.getElementById("pay-inv-total").textContent = `₹${parseFloat(est.payableAmount).toFixed(2)}`;

        // If EV Wallet, verify driver has enough balance
        if (method === "EV_WALLET") {
            const avail = state.currentUser.walletBalance || 0;
            const req = parseFloat(est.payableAmount);
            const warning = document.getElementById("pay-wallet-warning");
            const payBtn = document.getElementById("btn-execute-payment");
            if (avail < req) {
                warning.style.display = "block";
                payBtn.disabled = true;
            } else {
                warning.style.display = "none";
                payBtn.disabled = false;
            }
        } else {
            document.getElementById("btn-execute-payment").disabled = false;
        }
    } catch (err) {
        console.error("Estimate error:", err);
    }
}

async function executePayment() {
    if (!state.currentInvoice) return;

    const btn = document.getElementById("btn-execute-payment");
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Authorizing Gateway...';

    const selectedMethod = document.querySelector('input[name="pay-method"]:checked')?.value || "UPI";

    const payload = {
        invoiceId: state.currentInvoice.id,
        paymentType: selectedMethod,
        upiId: document.getElementById("pay-upi-id")?.value,
        cardNumber: document.getElementById("pay-card-number")?.value,
        cardExpiry: document.getElementById("pay-card-expiry")?.value,
        cardCvv: document.getElementById("pay-card-cvv")?.value,
        cardHolderName: state.currentUser.name
    };

    try {
        const res = await fetch("/api/payments/process", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });

        const data = await res.json();
        if (!res.ok) throw new Error(data.message || "Payment authorization failed");

        closeModal("payment-modal");

        // Open Receipt Modal
        document.getElementById("rcpt-ref").textContent = data.transactionReference;
        document.getElementById("rcpt-method").textContent = data.paymentMethod;
        document.getElementById("rcpt-amount").textContent = `₹${parseFloat(data.amountPaid).toFixed(2)}`;
        document.getElementById("rcpt-message").textContent = data.message;

        const cashRow = document.getElementById("rcpt-cashback-row");
        if (parseFloat(data.cashBackEarned) > 0) {
            cashRow.style.display = "flex";
            document.getElementById("rcpt-cashback").textContent = `₹${parseFloat(data.cashBackEarned).toFixed(2)}`;
        } else {
            cashRow.style.display = "none";
        }

        openModal("receipt-modal");

        // If paid with wallet, deduct from local state
        if (selectedMethod === "EV_WALLET") {
            state.currentUser.walletBalance -= parseFloat(data.amountPaid);
            if (parseFloat(data.cashBackEarned) > 0) {
                state.currentUser.walletBalance += parseFloat(data.cashBackEarned);
            }
            updateWalletDisplay(state.currentUser.walletBalance);
        }

        loadDriverInvoices();
        loadDashboardStats();
    } catch (err) {
        showToast(err.message, "error");
    } finally {
        btn.disabled = false;
        btn.innerHTML = '<i class="fa-solid fa-lock"></i> Authorize &amp; Pay';
    }
}

// ==================== INVOICES & WALLET MANAGEMENT ====================
async function loadDriverInvoices() {
    const list = document.getElementById("driver-invoices-list");
    if (!list) return;
    if (!state.currentUser || !state.currentUser.id) {
        list.innerHTML = '<p class="text-muted text-sm">Please log in to view historical invoices.</p>';
        return;
    }

    try {
        const res = await fetch(`/api/payments/invoices/driver/${state.currentUser.id}`);
        if (!res.ok) return;
        const invoices = await res.json();

        if (invoices.length === 0) {
            list.innerHTML = '<p class="text-muted text-sm">No historical invoices recorded yet.</p>';
            return;
        }

        list.innerHTML = invoices.map(inv => `
            <div style="background: rgba(255,255,255,0.02); border: 1px solid var(--border-subtle); border-radius: var(--radius-sm); padding: 12px; margin-bottom: 8px; display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <strong style="font-family: var(--font-mono); color: var(--accent-cyan);">${inv.invoiceNumber}</strong>
                    <div style="font-size: 11px; color: var(--text-muted);">${new Date(inv.invoiceDate || Date.now()).toLocaleDateString("en-IN")} • ${inv.unitsConsumedKwh} kWh</div>
                </div>
                <div style="text-align: right;">
                    <strong class="text-accent">₹${parseFloat(inv.totalAmount).toFixed(2)}</strong>
                    <div><span class="badge ${inv.paymentStatus === 'PAID' ? 'badge-available' : 'badge-danger'}" style="font-size: 9px;">${inv.paymentStatus}</span></div>
                </div>
            </div>
        `).join("");
    } catch (err) {
        console.error("Error loading driver invoices:", err);
    }
}

function openRechargeModal() {
    if (!state.currentUser) {
        showToast("Please log in or create a profile to recharge wallet.", "error");
        openLoginModal(true);
        return;
    }
    openModal("recharge-modal");
}

function quickRecharge(amount) {
    if (!state.currentUser) {
        showToast("Please log in or create a profile to recharge wallet.", "error");
        openLoginModal(true);
        return;
    }
    document.getElementById("recharge-amount-input").value = amount;
    executeWalletRecharge();
}

async function executeWalletRecharge() {
    if (!state.currentUser || !state.currentUser.id) {
        showToast("Please log in or create a profile to recharge your wallet.", "error");
        openLoginModal(true);
        return;
    }

    const amount = parseFloat(document.getElementById("recharge-amount-input")?.value || "1000");
    if (amount <= 0) {
        showToast("Please enter a valid top-up amount", "error");
        return;
    }

    try {
        const res = await fetch(`/api/users/${state.currentUser.id}/recharge-wallet`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ amount: amount })
        });
        const driver = await res.json();
        if (!res.ok) throw new Error(driver.message || "Recharge failed");

        state.currentUser.walletBalance = driver.walletBalance;
        updateWalletDisplay(driver.walletBalance);
        closeModal("recharge-modal");
        showToast(`Successfully added ₹${amount.toFixed(2)} to your EV Driver Wallet!`, "success");
    } catch (err) {
        showToast(err.message, "error");
    }
}

async function handleVehicleUpdate(e) {
    e.preventDefault();
    if (!state.currentUser || !state.currentUser.id) {
        showToast("Please log in or create a profile to update vehicle.", "error");
        openLoginModal(true);
        return;
    }
    const model = document.getElementById("veh-model-input").value;
    const reg = document.getElementById("veh-reg-input").value;
    const kwh = parseFloat(document.getElementById("veh-kwh-input").value);
    const conn = document.getElementById("veh-conn-input").value;

    try {
        const res = await fetch(`/api/users/${state.currentUser.id}/vehicle`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                vehicleModel: model,
                vehicleRegistrationNumber: reg,
                batteryCapacityKwh: kwh,
                preferredConnectorType: conn
            })
        });
        const updated = await res.json();
        if (!res.ok) throw new Error(updated.message || "Update failed");

        state.currentUser.vehicleModel = updated.vehicleModel;
        state.currentUser.vehicleRegistrationNumber = updated.vehicleRegistrationNumber;
        state.currentUser.batteryCapacityKwh = updated.batteryCapacityKwh;
        state.currentUser.preferredConnectorType = updated.preferredConnectorType;

        updateProfileDisplay(state.currentUser);
        closeModal("vehicle-modal");
        showToast("Vehicle specifications updated successfully", "success");
    } catch (err) {
        showToast(err.message, "error");
    }
}

// ==================== ADMIN GOVERNANCE ====================
async function loadAdminStations() {
    const container = document.getElementById("admin-stations-container");
    if (!container) return;

    try {
        const res = await fetch("/api/stations");
        if (!res.ok) return;
        const stations = await res.json();

        container.innerHTML = `
            <table class="custom-table">
                <thead>
                    <tr>
                        <th>Station Name</th>
                        <th>Locality / City</th>
                        <th>Operating Hours</th>
                        <th>Dispensers</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    ${stations.map(st => `
                        <tr>
                            <td><strong>${st.name}</strong><br><small class="text-muted">${st.address}</small></td>
                            <td>${st.area}, ${st.city}</td>
                            <td>${st.operatingHours || '24/7'}</td>
                            <td>
                                <div style="display: flex; gap: 6px; flex-wrap: wrap;">
                                    ${st.chargers.map(c => `
                                        <span class="badge ${c.status === 'AVAILABLE' ? 'badge-available' : 'badge-maintenance'}" style="cursor: pointer;" onclick="toggleChargerStatus(${c.id}, '${c.status}')" title="Click to Toggle Status">
                                            ${c.identifier} (${c.connectorType}): ${c.status}
                                        </span>
                                    `).join("")}
                                </div>
                            </td>
                            <td>
                                <div style="display: flex; gap: 6px;">
                                    <button class="btn btn-outline btn-sm" onclick="openAddChargerModal(${st.id})">
                                        + Gun
                                    </button>
                                    <button class="btn btn-danger btn-sm" onclick="deleteStation(${st.id})">
                                        <i class="fa-solid fa-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    `).join("")}
                </tbody>
            </table>
        `;
    } catch (err) {
        console.error("Admin stations error:", err);
    }
}

async function loadAdminBookings() {
    const container = document.getElementById("admin-all-bookings-container");
    if (!container) return;

    try {
        const res = await fetch("/api/bookings");
        if (!res.ok) return;
        const bookings = await res.json();

        container.innerHTML = `
            <table class="custom-table">
                <thead>
                    <tr>
                        <th>Booking Ref</th>
                        <th>Driver</th>
                        <th>Station & Dispenser</th>
                        <th>Window</th>
                        <th>Est. Units & Cost</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    ${bookings.map(b => `
                        <tr>
                            <td><code>${b.bookingReference}</code></td>
                            <td><strong>${b.driver.name}</strong><br><small class="text-muted">${b.driver.vehicleModel || 'EV'}</small></td>
                            <td>${b.station.name} (${b.charger.identifier})</td>
                            <td>${new Date(b.startTime).toLocaleString("en-IN", { dateStyle: "short", timeStyle: "short" })}</td>
                            <td>${b.estimatedKwh} kWh • ₹${b.estimatedCost}</td>
                            <td><span class="badge badge-${b.status.toLowerCase()}">${b.status}</span></td>
                        </tr>
                    `).join("")}
                </tbody>
            </table>
        `;
    } catch (err) {
        console.error("Admin bookings error:", err);
    }
}

async function loadAdminInvoices() {
    const container = document.getElementById("admin-all-invoices-container");
    if (!container) return;

    try {
        const res = await fetch("/api/payments/invoices");
        if (!res.ok) return;
        const invoices = await res.json();

        container.innerHTML = `
            <table class="custom-table">
                <thead>
                    <tr>
                        <th>Invoice Number</th>
                        <th>Driver</th>
                        <th>Energy (kWh)</th>
                        <th>Base Amount</th>
                        <th>GST (18%)</th>
                        <th>Total Settled</th>
                        <th>Status & Method</th>
                    </tr>
                </thead>
                <tbody>
                    ${invoices.map(i => `
                        <tr>
                            <td><code>${i.invoiceNumber}</code></td>
                            <td><strong>${i.driver.name}</strong></td>
                            <td>${i.unitsConsumedKwh} kWh</td>
                            <td>₹${i.baseAmount}</td>
                            <td>₹${i.gstAmount}</td>
                            <td><strong class="text-accent">₹${i.totalAmount}</strong></td>
                            <td>
                                <span class="badge ${i.paymentStatus === 'PAID' ? 'badge-available' : 'badge-danger'}">
                                    ${i.paymentStatus} ${i.paymentMethod ? `(${i.paymentMethod})` : ''}
                                </span>
                            </td>
                        </tr>
                    `).join("")}
                </tbody>
            </table>
        `;
    } catch (err) {
        console.error("Admin invoices error:", err);
    }
}

async function toggleChargerStatus(chargerId, currentStatus) {
    const nextStatus = currentStatus === "AVAILABLE" ? "MAINTENANCE" : "AVAILABLE";
    try {
        const res = await fetch(`/api/stations/chargers/${chargerId}/status?status=${nextStatus}`, {
            method: "PATCH"
        });
        if (!res.ok) throw new Error("Status update failed");
        showToast(`Charger status changed to ${nextStatus}`, "info");
        loadAdminStations();
        loadStations();
        loadDashboardStats();
    } catch (err) {
        showToast(err.message, "error");
    }
}

async function deleteStation(stationId) {
    if (!confirm("Are you sure you want to remove this station and all its chargers from the network?")) return;

    try {
        const res = await fetch(`/api/stations/${stationId}`, { method: "DELETE" });
        if (!res.ok) throw new Error("Delete failed");
        showToast("Station deleted successfully", "info");
        loadAdminStations();
        loadStations();
        loadDashboardStats();
    } catch (err) {
        showToast(err.message, "error");
    }
}

function openAddChargerModal(stationId) {
    document.getElementById("admin-ch-station-id").value = stationId;
    openModal("admin-charger-modal");
}

async function handleAdminChargerSubmit(e) {
    e.preventDefault();
    const stationId = parseInt(document.getElementById("admin-ch-station-id").value);
    const identifier = document.getElementById("admin-ch-identifier").value;
    const connectorType = document.getElementById("admin-ch-connector").value;
    const power = parseFloat(document.getElementById("admin-ch-power").value);
    const rate = parseFloat(document.getElementById("admin-ch-rate").value);

    try {
        const res = await fetch("/api/stations/chargers", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                stationId: stationId,
                identifier: identifier,
                connectorType: connectorType,
                powerRatingKw: power,
                ratePerKwh: rate
            })
        });
        if (!res.ok) throw new Error("Failed to add dispenser");
        closeModal("admin-charger-modal");
        showToast(`Charger ${identifier} added successfully!`, "success");
        loadAdminStations();
        loadStations();
        loadDashboardStats();
    } catch (err) {
        showToast(err.message, "error");
    }
}

// Admin Add Station Button Listener
document.getElementById("open-add-station-modal-btn")?.addEventListener("click", () => {
    openModal("admin-station-modal");
});

async function handleAdminStationSubmit(e) {
    e.preventDefault();
    const payload = {
        name: document.getElementById("admin-st-name").value,
        address: document.getElementById("admin-st-address").value,
        area: document.getElementById("admin-st-area").value,
        city: document.getElementById("admin-st-city").value,
        latitude: parseFloat(document.getElementById("admin-st-lat").value),
        longitude: parseFloat(document.getElementById("admin-st-lng").value),
        operatingHours: document.getElementById("admin-st-hours").value,
        contactPhone: document.getElementById("admin-st-phone").value,
        amenities: document.getElementById("admin-st-amenities").value
    };

    try {
        const res = await fetch("/api/stations", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });
        if (!res.ok) throw new Error("Station creation failed");
        closeModal("admin-station-modal");
        showToast(`Station "${payload.name}" provisioned on the network!`, "success");
        loadAdminStations();
        loadStations();
        loadDashboardStats();
    } catch (err) {
        showToast(err.message, "error");
    }
}

// Profile edit vehicle button listener
document.getElementById("open-edit-vehicle-modal-btn")?.addEventListener("click", () => {
    openModal("vehicle-modal");
});
document.getElementById("open-recharge-modal-btn")?.addEventListener("click", openRechargeModal);

// ==================== UTILITY MODALS & TOASTS ====================
function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) modal.style.display = "flex";
}

function closeModal(modalId) {
    if (modalId === "login-gate-modal" && !state.currentUser) {
        showToast("Please log in or create a profile to access the EV network.", "error");
        return;
    }
    const modal = document.getElementById(modalId);
    if (modal) modal.style.display = "none";
}

function showToast(message, type = "info") {
    const container = document.getElementById("toast-container");
    if (!container) return;

    const toast = document.createElement("div");
    toast.className = `toast toast-${type}`;

    const iconMap = {
        success: "fa-circle-check text-accent",
        error: "fa-triangle-exclamation text-danger",
        info: "fa-circle-info text-cyan"
    };

    toast.innerHTML = `
        <i class="fa-solid ${iconMap[type] || 'fa-info'}"></i>
        <span>${message}</span>
    `;

    container.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = "0";
        toast.style.transform = "translateY(10px)";
        toast.style.transition = "all 0.3s ease";
        setTimeout(() => toast.remove(), 300);
    }, 4000);
}

// ==================== DRIVER AUTH & PROFILE SESSION ====================
function initDriverLoginGate() {
    const storedUser = localStorage.getItem("volt_user");
    if (storedUser) {
        try {
            const user = JSON.parse(storedUser);
            setPersona(user);
        } catch (e) {
            console.warn("Failed to parse stored user, popping login gate", e);
            localStorage.removeItem("volt_user");
            state.currentUser = null;
            resetLoggedOutUI();
            openLoginModal(true);
        }
    } else {
        // First-time visit: User must log in or create a profile
        state.currentUser = null;
        resetLoggedOutUI();
        openLoginModal(true);
    }
}

function resetLoggedOutUI() {
    const topName = document.getElementById("topbar-driver-name");
    if (topName) topName.textContent = "Guest Driver";

    const topCar = document.getElementById("topbar-driver-car");
    if (topCar) topCar.textContent = "Create Profile to Begin";

    const sideName = document.getElementById("current-user-name");
    if (sideName) sideName.textContent = "Guest Driver";

    const sideRole = document.getElementById("current-user-role-badge");
    if (sideRole) sideRole.textContent = "Not Logged In";

    const avatar = document.getElementById("current-user-avatar");
    if (avatar) {
        avatar.innerHTML = '<i class="fa-solid fa-user"></i>';
        avatar.style.background = "rgba(255, 255, 255, 0.1)";
    }

    updateWalletDisplay(0);
}

function openLoginModal(isMandatory = false) {
    const modal = document.getElementById("login-gate-modal");
    if (!modal) return;

    const forceMandatory = isMandatory || !state.currentUser;
    const closeBtn = document.getElementById("login-gate-close-btn");
    if (closeBtn) {
        closeBtn.style.display = forceMandatory ? "none" : "flex";
    }

    const nameIn = document.getElementById("login-input-name");
    const emailIn = document.getElementById("login-input-email");
    const carIn = document.getElementById("login-input-car");
    const phoneIn = document.getElementById("login-input-phone");
    const regIn = document.getElementById("login-input-reg");

    if (state.currentUser && state.currentUser.role === "EV_DRIVER") {
        if (nameIn) nameIn.value = state.currentUser.name || "";
        if (emailIn) emailIn.value = state.currentUser.email || "";
        if (carIn) carIn.value = state.currentUser.vehicleModel || "Tata Nexon EV Max";
        if (phoneIn) phoneIn.value = state.currentUser.phone || "+91 98765 43210";
        if (regIn) regIn.value = state.currentUser.vehicleRegistrationNumber || "TS 09 EV 4521";
    } else {
        if (nameIn) nameIn.value = "";
        if (emailIn) emailIn.value = "";
        if (carIn) carIn.value = "";
        if (phoneIn) phoneIn.value = "";
        if (regIn) regIn.value = "";
    }

    modal.style.display = "flex";
}

function fillQuickDemo(name, email, car, phone, reg) {
    const nameIn = document.getElementById("login-input-name");
    const emailIn = document.getElementById("login-input-email");
    const carIn = document.getElementById("login-input-car");
    const phoneIn = document.getElementById("login-input-phone");
    const regIn = document.getElementById("login-input-reg");

    if (nameIn) nameIn.value = name;
    if (emailIn) emailIn.value = email;
    if (carIn) carIn.value = car;
    if (phoneIn) phoneIn.value = phone;
    if (regIn) regIn.value = reg;
}

async function handleDriverLoginSubmit(e) {
    e.preventDefault();
    const name = document.getElementById("login-input-name")?.value.trim();
    const email = document.getElementById("login-input-email")?.value.trim();
    const car = document.getElementById("login-input-car")?.value.trim();
    const phone = document.getElementById("login-input-phone")?.value.trim();
    const reg = document.getElementById("login-input-reg")?.value.trim();

    if (!name || !email || !car || !phone) {
        showToast("Please provide Name, Email, Car Model, and Phone Number.", "error");
        return;
    }

    const submitBtn = document.getElementById("driver-login-submit-btn");
    const originalText = submitBtn ? submitBtn.innerHTML : "";
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Authenticating with Smart Grid...';
    }

    try {
        const res = await fetch("/api/users/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                name: name,
                email: email,
                phone: phone,
                vehicleModel: car,
                vehicleRegistrationNumber: reg || ("IND " + Math.floor(1000 + Math.random() * 9000))
            })
        });

        if (!res.ok) {
            const errData = await res.json().catch(() => ({}));
            throw new Error(errData.message || "Failed to log in");
        }

        const driver = await res.json();
        state.currentUser = driver;
        localStorage.setItem("volt_user", JSON.stringify(driver));
        setPersona(driver);

        const modal = document.getElementById("login-gate-modal");
        if (modal) modal.style.display = "none";

        showToast(`Welcome ${driver.name}! Registered with ${driver.vehicleModel} (Wallet: ₹${driver.walletBalance})`, "success");
    } catch (err) {
        console.error("Login gate error:", err);
        showToast(err.message, "error");
    } finally {
        if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.innerHTML = originalText;
        }
    }
}

function handleUserLogout() {
    if (!confirm("Are you sure you want to log out of your EV driver profile?")) {
        return;
    }

    // 1. Clear session and storage
    localStorage.removeItem("volt_user");
    state.currentUser = null;

    // 2. Reset UI display
    resetLoggedOutUI();

    // 3. Clear driver specific lists
    const bookingsContainer = document.getElementById("driver-bookings-container");
    if (bookingsContainer) {
        bookingsContainer.innerHTML = `
            <div style="padding: 48px; text-align: center;">
                <i class="fa-solid fa-arrow-right-to-bracket" style="font-size: 32px; color: var(--text-muted); margin-bottom: 12px;"></i>
                <h4>Profile Logged Out</h4>
                <p class="text-muted">Please log in or create a profile to view and manage your charging bookings.</p>
            </div>
        `;
    }

    const invoicesContainer = document.getElementById("driver-invoices-list");
    if (invoicesContainer) {
        invoicesContainer.innerHTML = '<p class="text-muted text-sm">Please log in to view historical invoices.</p>';
    }

    // 4. Reset Simulator active state if running
    if (state.simulationTimer) {
        clearInterval(state.simulationTimer);
        state.simulationTimer = null;
    }
    state.activeSession = null;
    const simSetup = document.getElementById("sim-setup-container");
    if (simSetup) simSetup.style.display = "block";
    const simControls = document.getElementById("sim-active-controls");
    if (simControls) simControls.style.display = "none";
    const activeChip = document.getElementById("active-session-banner-btn");
    if (activeChip) activeChip.style.display = "none";
    const dot = document.getElementById("live-session-indicator");
    if (dot) dot.style.display = "none";

    // 5. Navigate to dashboard
    switchView("dashboard");

    // 6. Open login modal in mandatory mode so new profile or account must be entered
    openLoginModal(true);

    showToast("Logged out successfully. Create a new profile or log in to continue.", "info");
}

// Expose on global window for inline HTML onclick handlers
window.handleUserLogout = handleUserLogout;
window.openLoginModal = openLoginModal;
window.fillQuickDemo = fillQuickDemo;

// ==================== DEDICATED LOCATION SEARCH BAR ====================
const PAN_INDIA_LOCATIONS = {
    "delhi": { lat: 28.6139, lng: 77.2090, zoom: 11 },
    "new delhi": { lat: 28.6139, lng: 77.2090, zoom: 11 },
    "ncr": { lat: 28.6139, lng: 77.2090, zoom: 11 },
    "gurugram": { lat: 28.4595, lng: 77.0266, zoom: 12 },
    "noida": { lat: 28.5355, lng: 77.3910, zoom: 12 },
    "mumbai": { lat: 19.0760, lng: 72.8777, zoom: 11 },
    "vashi": { lat: 19.0664, lng: 72.9986, zoom: 12 },
    "navi mumbai": { lat: 19.0330, lng: 73.0297, zoom: 12 },
    "bengaluru": { lat: 12.9716, lng: 77.5946, zoom: 11 },
    "bangalore": { lat: 12.9716, lng: 77.5946, zoom: 11 },
    "hyderabad": { lat: 17.4375, lng: 78.4110, zoom: 12 },
    "chennai": { lat: 13.0827, lng: 80.2707, zoom: 11 },
    "pune": { lat: 18.5204, lng: 73.8567, zoom: 12 },
    "kolkata": { lat: 22.5726, lng: 88.3639, zoom: 12 },
    "ahmedabad": { lat: 23.0225, lng: 72.5714, zoom: 12 },
    "jaipur": { lat: 26.9124, lng: 75.7873, zoom: 12 },
    "chandigarh": { lat: 30.7333, lng: 76.7794, zoom: 12 },
    "kochi": { lat: 9.9816, lng: 76.2763, zoom: 12 },
    "goa": { lat: 15.4850, lng: 73.8150, zoom: 11 },
    "lucknow": { lat: 26.8500, lng: 80.9900, zoom: 12 },
    "bhopal": { lat: 23.2330, lng: 77.4340, zoom: 12 }
};

function initDedicatedLocationSearch() {
    const locInput = document.getElementById("dedicated-location-input");
    const locSubmit = document.getElementById("dedicated-location-submit-btn");
    const locClear = document.getElementById("loc-search-clear-btn");
    const cityPills = document.querySelectorAll(".city-pill");

    if (locInput) {
        locInput.addEventListener("input", () => {
            const val = locInput.value.trim();
            if (locClear) locClear.style.display = val ? "block" : "none";
            filterStationsByLocation(val);
        });

        locInput.addEventListener("keypress", (e) => {
            if (e.key === "Enter") {
                filterStationsByLocation(locInput.value.trim());
            }
        });
    }

    if (locSubmit) {
        locSubmit.addEventListener("click", () => {
            const val = locInput ? locInput.value.trim() : "";
            filterStationsByLocation(val);
        });
    }

    if (locClear) {
        locClear.addEventListener("click", () => {
            if (locInput) locInput.value = "";
            locClear.style.display = "none";
            filterStationsByLocation("");
        });
    }

    cityPills.forEach(pill => {
        pill.addEventListener("click", () => {
            cityPills.forEach(p => p.classList.remove("active"));
            pill.classList.add("active");
            const city = pill.getAttribute("data-city");
            if (locInput) {
                locInput.value = (city === "ALL") ? "" : city;
                if (locClear) locClear.style.display = (city === "ALL") ? "none" : "block";
            }
            filterStationsByLocation(city);
        });
    });
}

function updateLocationSearchCounter(stationsToCount) {
    if (!stationsToCount) return;
    let totalPorts = 0;
    let availPorts = 0;
    stationsToCount.forEach(st => {
        if (st.chargers) {
            totalPorts += st.chargers.length;
            availPorts += st.chargers.filter(c => c.status === "AVAILABLE").length;
        }
    });

    const countEl = document.getElementById("loc-live-available-count");
    if (countEl) countEl.textContent = `${availPorts} / ${totalPorts}`;
}

function filterStationsByLocation(query) {
    if (!state.stations || state.stations.length === 0) return;

    let matched = state.stations;
    let locationLabel = "All India";

    if (query && query !== "ALL") {
        const q = query.toLowerCase().trim();
        locationLabel = query;
        matched = state.stations.filter(st => {
            const nameMatch = st.name && st.name.toLowerCase().includes(q);
            const cityMatch = st.city && st.city.toLowerCase().includes(q);
            const areaMatch = st.area && st.area.toLowerCase().includes(q);
            const stateMatch = st.state && st.state.toLowerCase().includes(q);
            const addrMatch = st.address && st.address.toLowerCase().includes(q);
            return nameMatch || cityMatch || areaMatch || stateMatch || addrMatch;
        });
    }

    // Calculate total and available ports in matched stations
    let totalPorts = 0;
    let availPorts = 0;
    matched.forEach(st => {
        if (st.chargers) {
            totalPorts += st.chargers.length;
            availPorts += st.chargers.filter(c => c.status === "AVAILABLE").length;
        }
    });

    // Update Counter Strip
    const summaryEl = document.getElementById("loc-status-summary");
    const countEl = document.getElementById("loc-live-available-count");
    const activeNameEl = document.getElementById("loc-active-name");
    const featuredTitle = document.getElementById("featured-stations-title");

    if (activeNameEl) activeNameEl.textContent = locationLabel;
    if (countEl) countEl.textContent = `${availPorts} / ${totalPorts}`;
    if (summaryEl) {
        if (!query || query === "ALL") {
            summaryEl.innerHTML = `Showing All India Network: <strong>${matched.length} Stations</strong> with <strong class="text-emerald">${availPorts} available chargers</strong> (Total: ${totalPorts})`;
        } else {
            summaryEl.innerHTML = `Search "${locationLabel}": Found <strong>${matched.length} station${matched.length === 1 ? '' : 's'}</strong> with <strong class="text-emerald">${availPorts} available chargers</strong> ready`;
        }
    }
    if (featuredTitle) {
        featuredTitle.textContent = (!query || query === "ALL")
            ? "Available Charging Stations Across India"
            : `Available Charging Stations in "${locationLabel}" (${matched.length})`;
    }

    // Render filtered stations across views
    renderDashboardFeaturedStations(matched);
    renderStationsGrid(matched);
    renderRadarPins(matched);
    initGoogleMapMarkers(matched);

    // Pan map to location
    centerMapToLocation(locationLabel, matched);
}

function centerMapToLocation(locName, matchedStations) {
    let target = null;
    const lower = locName.toLowerCase().trim();

    for (const [key, coords] of Object.entries(PAN_INDIA_LOCATIONS)) {
        if (lower.includes(key) || key.includes(lower)) {
            target = coords;
            break;
        }
    }

    if (!target && matchedStations && matchedStations.length > 0) {
        target = {
            lat: matchedStations[0].latitude,
            lng: matchedStations[0].longitude,
            zoom: 12
        };
    }

    if (target && state.googleMap) {
        state.googleMap.panTo({ lat: target.lat, lng: target.lng });
        state.googleMap.setZoom(target.zoom || 12);
    } else if (!target && state.googleMap) {
        // Reset to all India
        state.googleMap.panTo({ lat: 21.7679, lng: 78.8718 });
        state.googleMap.setZoom(5);
    }
}
