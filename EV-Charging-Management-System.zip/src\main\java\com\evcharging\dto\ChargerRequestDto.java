package com.evcharging.dto;

import com.evcharging.model.ChargerStatus;
import com.evcharging.model.ConnectorType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public class ChargerRequestDto {

    @NotNull(message = "Station ID is required")
    private Long stationId;

    @NotBlank(message = "Charger identifier is required (e.g. CH-01)")
    private String identifier;

    @NotNull(message = "Connector type is required")
    private ConnectorType connectorType;

    @NotNull(message = "Power rating is required")
    @Positive(message = "Power rating must be positive")
    private Double powerRatingKw;

    @NotNull(message = "Rate per kWh is required")
    @Positive(message = "Rate per kWh must be positive")
    private Double ratePerKwh;

    private ChargerStatus status;

    public ChargerRequestDto() {}

    public Long getStationId() {
        return stationId;
    }

    public void setStationId(Long stationId) {
        this.stationId = stationId;
    }

    public String getIdentifier() {
        return identifier;
    }

    public void setIdentifier(String identifier) {
        this.identifier = identifier;
    }

    public ConnectorType getConnectorType() {
        return connectorType;
    }

    public void setConnectorType(ConnectorType connectorType) {
        this.connectorType = connectorType;
    }

    public Double getPowerRatingKw() {
        return powerRatingKw;
    }

    public void setPowerRatingKw(Double powerRatingKw) {
        this.powerRatingKw = powerRatingKw;
    }

    public Double getRatePerKwh() {
        return ratePerKwh;
    }

    public void setRatePerKwh(Double ratePerKwh) {
        this.ratePerKwh = ratePerKwh;
    }

    public ChargerStatus getStatus() {
        return status;
    }

    public void setStatus(ChargerStatus status) {
        this.status = status;
    }
}
