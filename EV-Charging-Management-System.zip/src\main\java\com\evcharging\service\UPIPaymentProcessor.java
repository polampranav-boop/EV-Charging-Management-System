package com.evcharging.service;

import com.evcharging.dto.PaymentRequestDto;
import com.evcharging.exception.PaymentFailedException;
import com.evcharging.model.Invoice;
import com.evcharging.model.PaymentType;
import com.evcharging.repository.InvoiceRepository;
import com.evcharging.repository.PaymentRecordRepository;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * OOP Polymorphism: UPI Payment Implementation.
 * Overrides fee calculation (0% surcharge for UPI) and verifies Virtual Payment Address (VPA).
 */
@Service
public class UPIPaymentProcessor extends AbstractPaymentProcessor {

    public UPIPaymentProcessor(InvoiceRepository invoiceRepository,
                               PaymentRecordRepository paymentRecordRepository) {
        super(invoiceRepository, paymentRecordRepository);
    }

    @Override
    public PaymentType getSupportedPaymentType() {
        return PaymentType.UPI;
    }

    @Override
    public String getGatewayDisplayName() {
        return "UPI (Google Pay / PhonePe / Paytm)";
    }

    @Override
    public BigDecimal calculateConvenienceFee(BigDecimal billAmount) {
        // Zero convenience fee on UPI in India
        return BigDecimal.ZERO;
    }

    @Override
    public BigDecimal calculateCashBackBonus(BigDecimal billAmount) {
        // 2% Green Mobility UPI Cashback reward
        return billAmount.multiply(BigDecimal.valueOf(0.02)).setScale(2, RoundingMode.HALF_UP);
    }

    @Override
    protected String executeGatewayAuthorization(Invoice invoice, PaymentRequestDto request, BigDecimal amount) {
        String upiId = request.getUpiId();
        if (upiId == null || !upiId.contains("@")) {
            throw new PaymentFailedException("Invalid UPI ID format. Expected format: user@okhdfcbank or 9876543210@upi");
        }
        return generateTransactionReference("UPI");
    }
}
