package com.evcharging.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/config")
@CrossOrigin(origins = "*")
public class ConfigController {

    @Value("${evcharging.google.maps.api-key:YOUR_GOOGLE_MAPS_API_KEY}")
    private String googleMapsApiKey;

    @GetMapping("/maps")
    public ResponseEntity<Map<String, Object>> getMapsConfig() {
        Map<String, Object> config = new HashMap<>();
        boolean isConfigured = googleMapsApiKey != null &&
                !googleMapsApiKey.isBlank() &&
                !"YOUR_GOOGLE_MAPS_API_KEY".equalsIgnoreCase(googleMapsApiKey.trim());

        config.put("apiKey", isConfigured ? googleMapsApiKey.trim() : "");
        config.put("hasValidKey", isConfigured);
        config.put("defaultCity", "Hyderabad");
        config.put("defaultLatitude", 17.4375);
        config.put("defaultLongitude", 78.4110);
        config.put("defaultZoom", 12);
        return ResponseEntity.ok(config);
    }
}
