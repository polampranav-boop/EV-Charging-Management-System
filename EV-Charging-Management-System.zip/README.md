# VoltPulse - EV Charging Management System

[![Java](https://img.shields.io/badge/Java-17%20%2F%2021%20%2F%2025-orange.svg)](https://www.oracle.com/java/)
[![Spring Boot](https://img.shields.io/badge/Spring%20Boot-3.3.4-brightgreen.svg)](https://spring.io/projects/spring-boot)
[![Maven](https://img.shields.io/badge/Maven-3.9+-blue.svg)](https://maven.apache.org/)
[![Database](https://img.shields.io/badge/Database-MySQL%20%2F%20H2-blue.svg)](https://www.mysql.com/)
[![License](https://img.shields.io/badge/Project-BTech%20CSE%20PBL-purple.svg)]()

A modern, responsive web application for managing Electric Vehicle (EV) fast-charging infrastructure, built as a **BTech CSE PBL (Project-Based Learning)** project. Demonstrates core **Object-Oriented Programming (OOP) principles in Java**, robust **Spring Boot 3 REST APIs**, **Spring Data JPA**, **MySQL persistent storage**, **Google Maps JavaScript API**, simulated telemetry sessions, and polymorphic digital payments.

---

## 🌟 Key Application Features

1. **Modern Live Dashboard**: Real-time KPI statistics including total active charging hubs, available dispensers, total energy delivered (kWh), and automated GST revenue.
2. **Charging Station Finder & Advanced Filtering**: Search by name, locality (Gachibowli, Hitec City, Jubilee Hills, Madhapur, Banjara Hills, Begumpet, Secunderabad, Miyapur), connector type (CCS2, Type 2, CHAdeMO, GB/T), minimum power output (kW), and instant availability.
3. **Geospatial Station Map**:
   - **Google Maps JavaScript API**: High-precision interactive map with custom pins, telemetry info windows, and 1-click booking triggers.
   - **Integrated Vector Radar Map**: Built-in fallback radar map of Hyderabad plotted with accurate GPS coordinates that operates out-of-the-box even without a Google Maps key!
4. **Slot Booking & Conflict Detection**: Reserve 30/45/60/90-minute charging slots with server-side collision validation, cost estimation (energy + 18% GST), and cancellation controls.
5. **Simulated Charging Session Controls**: Real-time charging telemetry with animated battery gauge, live speed (kW), energy dispensed (kWh), elapsed duration, and continuous running-cost calculation.
6. **Automated GST Bill Calculation**: Automatically calculates energy charges ($kWh \times rate$), Central & State GST (18%), and generates an official tax invoice.
7. **Polymorphic Payment Gateway**:
   - **UPI**: 0% convenience fee + 2% Green Mobility cashback reward.
   - **Credit / Debit Card**: 1.5% gateway surcharge + 1% reward points.
   - **EV Driver Wallet**: Instant checkout from pre-funded wallet + 5% eco-reward balance bonus.
8. **Driver EV Profile & Wallet**: Manage vehicle model, battery capacity (kWh), preferred connector, wallet balance top-ups, and past receipts.
9. **Admin Station & Charger Governance**: Add/edit/delete stations, provision dispensers, and toggle maintenance status.
10. **Driver Identification, Registration & Profile Logout**: Dedicated driver authentication gate, profile creation (Name, Email, Vehicle Model, Phone), persistent session storage, and explicit profile logout to register or access another account.

---

## 🏛️ Object-Oriented Programming (OOP) Architecture

| OOP Principle | Technical Java Implementation in Project |
| :--- | :--- |
| **Encapsulation** | All entity fields in `User`, `Station`, `Charger`, `Booking`, `Invoice`, etc., are declared `private`. Access is regulated via validated getters/setters and domain methods (`EVDriver.deductWallet()`, `Invoice.calculateBill()`, `Station.getMinRatePerKwh()`). |
| **Inheritance** | Base entity `User` with `@Inheritance(strategy = InheritanceType.JOINED)` is extended by `Admin` (with administrative clearance, department, employee code) and `EVDriver` (with vehicle specs, registration number, wallet). Entities also inherit from `BaseEntity`. |
| **Polymorphism** | Overridden methods `getRoleDescription()` and `getDashboardGreeting()`. Dynamic payment strategy pattern: `PaymentProcessor` interface is polymorphically implemented by `UPIPaymentProcessor`, `CreditCardPaymentProcessor`, and `EVWalletPaymentProcessor`. |
| **Abstraction** | Abstract classes (`BaseEntity`, `User`, `AbstractPaymentProcessor`) define contracts and template patterns, coupled with service interfaces (`StationService`, `BookingService`, `ChargingSimulatorService`). |
| **Exception Handling** | Custom runtime exceptions (`ResourceNotFoundException`, `SlotUnavailableException`, `InvalidBookingException`, `PaymentFailedException`) with a centralized `@RestControllerAdvice` (`GlobalExceptionHandler`). |
| **Java Collections** | Extensive usage of `List`, `Map`, `Set`, and Java 8+ Streams (`filter()`, `mapToDouble()`, `Collectors.groupingBy()`) for station lookups and dashboard metrics. |

---

## 🛠️ Technology Stack

- **Backend**: Java 17+ (tested with Java 25 LTS), Spring Boot 3.3.4
- **Persistence**: Spring Data JPA, Hibernate ORM
- **Database**: MySQL 8.0+ (Production / Persistent) with embedded H2 (Zero-Setup Local Dev)
- **Frontend**: Vanilla HTML5, CSS3 (High-Tech Glassmorphism & Animations), Modern Vanilla JavaScript (ES6+)
- **Build Tool**: Apache Maven 3.9+
- **APIs**: RESTful JSON APIs, Google Maps JavaScript API

---

## 📁 Project Structure

```
EV-Charging-Management-System/
├── pom.xml                                   # Maven dependencies & build configuration
├── mvn.cmd / mvnw.cmd                        # Maven wrapper scripts
├── README.md                                 # Documentation & setup guide
├── src/
│   ├── main/
│   │   ├── java/com/evcharging/
│   │   │   ├── EvChargingApplication.java    # Spring Boot main entry point
│   │   │   ├── config/
│   │   │   │   └── DataInitializer.java      # Seeder for realistic Hyderabad stations & demo users
│   │   │   ├── controller/                   # REST API Controllers
│   │   │   │   ├── AnalyticsController.java
│   │   │   │   ├── BookingController.java
│   │   │   │   ├── ChargingController.java
│   │   │   │   ├── ConfigController.java     # Safe Google Maps config exposure
│   │   │   │   ├── PaymentController.java
│   │   │   │   ├── StationController.java
│   │   │   │   └── UserController.java
│   │   │   ├── dto/                          # Request & Response Transfer Objects
│   │   │   │   ├── BookingRequestDto.java
│   │   │   │   ├── DashboardStatsDto.java
│   │   │   │   ├── PaymentRequestDto.java
│   │   │   │   └── StationRequestDto.java
│   │   │   ├── exception/                    # Custom Domain Exceptions & Global Handler
│   │   │   │   ├── GlobalExceptionHandler.java
│   │   │   │   ├── InvalidBookingException.java
│   │   │   │   ├── PaymentFailedException.java
│   │   │   │   ├── ResourceNotFoundException.java
│   │   │   │   └── SlotUnavailableException.java
│   │   │   ├── model/                        # OOP Domain Entities
│   │   │   │   ├── Admin.java                # Subclass of User
│   │   │   │   ├── BaseEntity.java           # Abstract Superclass
│   │   │   │   ├── Booking.java
│   │   │   │   ├── Charger.java
│   │   │   │   ├── ChargingSession.java
│   │   │   │   ├── EVDriver.java             # Subclass of User
│   │   │   │   ├── Invoice.java
│   │   │   │   ├── PaymentRecord.java
│   │   │   │   ├── Station.java
│   │   │   │   └── User.java                 # Abstract Base Class
│   │   │   ├── repository/                   # Spring Data JPA Repositories
│   │   │   └── service/                      # Business Services & Polymorphic Processors
│   │   │       ├── AbstractPaymentProcessor.java
│   │   │       ├── CreditCardPaymentProcessor.java
│   │   │       ├── EVWalletPaymentProcessor.java
│   │   │       ├── PaymentProcessor.java     # Abstraction Interface
│   │   │       ├── PaymentService.java
│   │   │       ├── StationServiceImpl.java
│   │   │       └── UPIPaymentProcessor.java
│   │   └── resources/
│   │       ├── application.properties        # Default configuration (Embedded H2 / MySQL toggle)
│   │       ├── application-mysql.properties  # MySQL production database profile
│   │       ├── schema-mysql.sql              # MySQL DDL table script
│   │       └── static/                       # Modern Frontend
│   │           ├── index.html
│   │           ├── css/styles.css
│   │           └── js/app.js
│   └── test/java/com/evcharging/
│       └── EvChargingApplicationTests.java   # Spring Boot context & integration test
```

---

## 🚀 Quick Start Guide (Zero-Docker Setup)

### 1. Prerequisites
- Java JDK 17, 21, or 25 installed (`java -version`).
- Maven (bundled `mvn.cmd` is included in the project directory).

### 2. Start the Application
Open a terminal (PowerShell or CMD) in the project directory:

```powershell
.\mvn.cmd spring-boot:run
```

The application starts on: **`http://localhost:8080`**

Open your web browser and navigate to:
👉 **`http://localhost:8080`**

The embedded database initializes automatically with all 8 Hyderabad fast-charging hubs, dispensers, demo users, and bookings!

---

## 🗄️ MySQL Database Setup & Configuration

To connect the application to your local MySQL server:

### Step 1: Create Database
Open MySQL Workbench or MySQL CLI:
```sql
CREATE DATABASE ev_charging_db;
```
*(Alternatively, you can run the SQL script located at `src/main/resources/schema-mysql.sql`).*

### Step 2: Configure Credentials
Open `src/main/resources/application.properties` or `src/main/resources/application-mysql.properties`:

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/ev_charging_db?createDatabaseIfNotExist=true&useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=Asia/Kolkata
spring.datasource.username=root
spring.datasource.password=your_mysql_password
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver
spring.jpa.database-platform=org.hibernate.dialect.MySQLDialect
spring.jpa.hibernate.ddl-auto=update
```

### Step 3: Run with MySQL Profile
```powershell
.\mvn.cmd spring-boot:run -Dspring-boot.run.profiles=mysql
```

---

## 🗺️ Google Maps JavaScript API Configuration

1. Obtain an API key from the [Google Cloud Console](https://console.cloud.google.com/google/maps-apis) with the **Maps JavaScript API** enabled.
2. In `src/main/resources/application.properties`, update:
   ```properties
   evcharging.google.maps.api-key=YOUR_ACTUAL_GOOGLE_MAPS_API_KEY
   ```
   *Or set an environment variable:*
   ```powershell
   $env:GOOGLE_MAPS_API_KEY="AIzaSy..."
   ```
3. Restart the application. The system will automatically detect the key and render the Google Maps view with custom markers and telemetry info windows.
4. *Note:* If left as default, the built-in **interactive vector radar map of Hyderabad** will activate automatically, ensuring full functionality with zero errors!

---

## 👤 Sample Demo Accounts

The project seeds sample accounts ready for live evaluation:

| Persona | Name | Email | Role | Vehicle / Details |
| :--- | :--- | :--- | :--- | :--- |
| **EV Driver 1** | Rahul Varma | `rahul@evcharge.in` | `EV_DRIVER` | Tata Nexon EV Max (TS 09 EV 4521), Wallet: ₹1,450.00 |
| **EV Driver 2** | Sneha Reddy | `sneha@evcharge.in` | `EV_DRIVER` | MG ZS EV Excite (TS 07 EV 8890), Wallet: ₹980.00 |
| **Admin** | Vikram Sharma | `admin@evcharge.in` | `ADMIN` | Telangana Grid Operations (ADM-HYD-01) |

Switch between accounts instantly using the persona selector in the top-right header!

---

## 🧪 Testing the Project

Run the test suite:
```powershell
.\mvn.cmd test
```

Package the executable JAR:
```powershell
.\mvn.cmd clean package
```

Run the standalone JAR:
```powershell
java -jar target/ev-charging-management-system-1.0.0.jar
```
