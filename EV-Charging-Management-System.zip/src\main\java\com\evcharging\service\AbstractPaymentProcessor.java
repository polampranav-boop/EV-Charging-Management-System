package com.evcharging.service;

import com.evcharging.dto.PaymentRequestDto;
import com.evcharging.dto.PaymentResponseDto;
import com.evcharging.model.Invoice;
import com.evcharging.model.PaymentRecord;
import com.evcharging.repository.InvoiceRepository;
import com.evcharging.repository.PaymentRecordRepository;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

/**
 * OOP Abstraction & Polymorphism: AbstractPaymentProcessor.
 * Provides reusable payment orchestration, transaction auditing, and status updates.
 */
public abstract class AbstractPaymentProcessor implements PaymentProcessor {

    protected final InvoiceRepository invoiceRepository;
    protected final PaymentRecordRepository paymentRecordRepository;

    public AbstractPaymentProcessor(InvoiceRepository invoiceRepository,
                                    PaymentRecordRepository paymentRecordRepository) {
        this.invoiceRepository = invoiceRepository;
        this.paymentRecordRepository = paymentRecordRepository;
    }

    protected String generateTransactionReference(String prefix) {
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
        String shortId = UUID.randomUUID().toString().substring(0, 6).toUpperCase();
        return prefix + "-" + timestamp + "-" + shortId;
    }

    @Override
    public PaymentResponseDto processPayment(Invoice invoice, PaymentRequestDto request) {
        BigDecimal fee = calculateConvenienceFee(invoice.getTotalAmount());
        BigDecimal totalToCharge = invoice.getTotalAmount().add(fee).setScale(2, RoundingMode.HALF_UP);
        BigDecimal cashback = calculateCashBackBonus(invoice.getTotalAmount());

        // Perform concrete gateway-specific authorization
        String txnRef = executeGatewayAuthorization(invoice, request, totalToCharge);

        // Update Invoice status
        invoice.setConvenienceFee(fee);
        invoice.setPaymentStatus("PAID");
        invoice.setPaymentMethod(getSupportedPaymentType());
        invoice.setPaymentTransactionId(txnRef);
        invoiceRepository.save(invoice);

        // Record persistent transaction audit
        PaymentRecord record = new PaymentRecord(
                txnRef,
                invoice,
                getSupportedPaymentType(),
                totalToCharge,
                fee,
                "SUCCESS",
                getGatewayDisplayName() + " authorized successfully. Cashback: ₹" + cashback
        );
        paymentRecordRepository.save(record);

        // Post-settlement hook (e.g. cashback credit)
        onPaymentSuccess(invoice, cashback);

        return new PaymentResponseDto(
                true,
                txnRef,
                getGatewayDisplayName(),
                totalToCharge,
                fee,
                cashback,
                "Payment of ₹" + totalToCharge + " processed successfully via " + getGatewayDisplayName()
        );
    }

    /**
     * Subclasses must provide polymorphic authorization logic.
     */
    protected abstract String executeGatewayAuthorization(Invoice invoice, PaymentRequestDto request, BigDecimal amount);

    /**
     * Optional hook for custom promotional actions.
     */
    protected void onPaymentSuccess(Invoice invoice, BigDecimal cashback) {
        // Default no-op
    }
}
