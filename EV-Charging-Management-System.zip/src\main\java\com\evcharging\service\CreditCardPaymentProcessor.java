package com.evcharging.service;

import com.evcharging.dto.PaymentRequestDto;
import com.evcharging.exception.PaymentFailedException;
import com.evcharging.model.Invoice;
import com.evcharging.model.PaymentType;
import com.evcharging.repository.InvoiceRepository;
import com.evcharging.repository.PaymentRecordRepository;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * OOP Polymorphism: Credit/Debit Card Payment Implementation.
 * Overrides fee calculation with banking interchange surcharge and validates card credentials.
 */
@Service
public class CreditCardPaymentProcessor extends AbstractPaymentProcessor {

    public CreditCardPaymentProcessor(InvoiceRepository invoiceRepository,
                                      PaymentRecordRepository paymentRecordRepository) {
        super(invoiceRepository, paymentRecordRepository);
    }

    @Override
    public PaymentType getSupportedPaymentType() {
        return PaymentType.CREDIT_CARD;
    }

    @Override
    public String getGatewayDisplayName() {
        return "Credit / Debit Card (Visa / Mastercard / RuPay)";
    }

    @Override
    public BigDecimal calculateConvenienceFee(BigDecimal billAmount) {
        // 1.5% payment gateway processing fee
        return billAmount.multiply(BigDecimal.valueOf(0.015)).setScale(2, RoundingMode.HALF_UP);
    }

    @Override
    public BigDecimal calculateCashBackBonus(BigDecimal billAmount) {
        // 1% reward points
        return billAmount.multiply(BigDecimal.valueOf(0.01)).setScale(2, RoundingMode.HALF_UP);
    }

    @Override
    protected String executeGatewayAuthorization(Invoice invoice, PaymentRequestDto request, BigDecimal amount) {
        String cardNumber = request.getCardNumber();
        String cvv = request.getCardCvv();
        if (cardNumber == null || cardNumber.replaceAll("\\s+", "").length() < 13) {
            throw new PaymentFailedException("Invalid card number. Card number must have at least 13 to 16 digits.");
        }
        if (cvv == null || cvv.trim().length() < 3) {
            throw new PaymentFailedException("Invalid CVV code. 3-digit security code is required.");
        }
        return generateTransactionReference("CARD");
    }
}
