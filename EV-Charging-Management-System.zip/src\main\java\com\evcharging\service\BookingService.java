package com.evcharging.service;

import com.evcharging.dto.BookingRequestDto;
import com.evcharging.model.Booking;
import java.util.List;

public interface BookingService {
    Booking createBooking(BookingRequestDto request);
    Booking cancelBooking(Long bookingId, String reason);
    Booking getBookingById(Long id);
    Booking getBookingByReference(String bookingReference);
    List<Booking> getBookingsByDriver(Long driverId);
    List<Booking> getAllBookings();
    List<Booking> getBookingsByStation(Long stationId);
}
