package com.evcharging.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

/**
 * Charger Entity represents an individual charging dispenser/gun at a station.
 */
@Entity
@Table(name = "chargers")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Charger extends BaseEntity {

    @NotBlank(message = "Charger identifier is required (e.g., CH-01)")
    @Column(nullable = false, length = 50)
    private String identifier;

    @NotNull(message = "Connector type is required")
    @Enumerated(EnumType.STRING)
    @Column(name = "connector_type", nullable = false, length = 30)
    private ConnectorType connectorType;

    @NotNull(message = "Power rating is required")
    @Positive(message = "Power rating must be greater than 0")
    @Column(name = "power_rating_kw", nullable = false)
    private Double powerRatingKw;

    @NotNull(message = "Rate per kWh is required")
    @Positive(message = "Rate per kWh must be greater than 0")
    @Column(name = "rate_per_kwh", nullable = false)
    private Double ratePerKwh;

    @NotNull(message = "Charger status is required")
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    private ChargerStatus status;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "station_id", nullable = false)
    @JsonBackReference
    private Station station;

    public Charger() {
        super();
        this.status = ChargerStatus.AVAILABLE;
    }

    public Charger(String identifier, ConnectorType connectorType, Double powerRatingKw,
                   Double ratePerKwh, ChargerStatus status, Station station) {
        super();
        this.identifier = identifier;
        this.connectorType = connectorType;
        this.powerRatingKw = powerRatingKw;
        this.ratePerKwh = ratePerKwh;
        this.status = status != null ? status : ChargerStatus.AVAILABLE;
        this.station = station;
    }

    public boolean isAvailable() {
        return this.status == ChargerStatus.AVAILABLE;
    }

    // Encapsulation: Getters and Setters
    public String getIdentifier() {
        return identifier;
    }

    public void setIdentifier(String identifier) {
        this.identifier = identifier;
    }

    public ConnectorType getConnectorType() {
        return connectorType;
    }

    public void setConnectorType(ConnectorType connectorType) {
        this.connectorType = connectorType;
    }

    public Double getPowerRatingKw() {
        return powerRatingKw;
    }

    public void setPowerRatingKw(Double powerRatingKw) {
        this.powerRatingKw = powerRatingKw;
    }

    public Double getRatePerKwh() {
        return ratePerKwh;
    }

    public void setRatePerKwh(Double ratePerKwh) {
        this.ratePerKwh = ratePerKwh;
    }

    public ChargerStatus getStatus() {
        return status;
    }

    public void setStatus(ChargerStatus status) {
        this.status = status;
    }

    public Station getStation() {
        return station;
    }

    public void setStation(Station station) {
        this.station = station;
    }
}
