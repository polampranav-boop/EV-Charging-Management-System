package com.evcharging.dto;

import java.math.BigDecimal;
import java.util.Map;

public class DashboardStatsDto {

    private long totalStations;
    private long totalChargers;
    private long availableChargers;
    private long occupiedChargers;
    private long maintenanceChargers;
    private long totalBookings;
    private long activeChargingSessions;
    private Double totalEnergyDeliveredKwh;
    private BigDecimal totalRevenue;
    private Map<String, Long> chargersByConnector;
    private Map<String, Long> stationsByArea;

    public DashboardStatsDto() {}

    public long getTotalStations() {
        return totalStations;
    }

    public void setTotalStations(long totalStations) {
        this.totalStations = totalStations;
    }

    public long getTotalChargers() {
        return totalChargers;
    }

    public void setTotalChargers(long totalChargers) {
        this.totalChargers = totalChargers;
    }

    public long getAvailableChargers() {
        return availableChargers;
    }

    public void setAvailableChargers(long availableChargers) {
        this.availableChargers = availableChargers;
    }

    public long getOccupiedChargers() {
        return occupiedChargers;
    }

    public void setOccupiedChargers(long occupiedChargers) {
        this.occupiedChargers = occupiedChargers;
    }

    public long getMaintenanceChargers() {
        return maintenanceChargers;
    }

    public void setMaintenanceChargers(long maintenanceChargers) {
        this.maintenanceChargers = maintenanceChargers;
    }

    public long getTotalBookings() {
        return totalBookings;
    }

    public void setTotalBookings(long totalBookings) {
        this.totalBookings = totalBookings;
    }

    public long getActiveChargingSessions() {
        return activeChargingSessions;
    }

    public void setActiveChargingSessions(long activeChargingSessions) {
        this.activeChargingSessions = activeChargingSessions;
    }

    public Double getTotalEnergyDeliveredKwh() {
        return totalEnergyDeliveredKwh;
    }

    public void setTotalEnergyDeliveredKwh(Double totalEnergyDeliveredKwh) {
        this.totalEnergyDeliveredKwh = totalEnergyDeliveredKwh;
    }

    public BigDecimal getTotalRevenue() {
        return totalRevenue;
    }

    public void setTotalRevenue(BigDecimal totalRevenue) {
        this.totalRevenue = totalRevenue;
    }

    public Map<String, Long> getChargersByConnector() {
        return chargersByConnector;
    }

    public void setChargersByConnector(Map<String, Long> chargersByConnector) {
        this.chargersByConnector = chargersByConnector;
    }

    public Map<String, Long> getStationsByArea() {
        return stationsByArea;
    }

    public void setStationsByArea(Map<String, Long> stationsByArea) {
        this.stationsByArea = stationsByArea;
    }
}
