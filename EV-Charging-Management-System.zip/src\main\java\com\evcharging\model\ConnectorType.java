package com.evcharging.model;

public enum ConnectorType {
    CCS2("Combined Charging System Type 2 (DC Fast)"),
    TYPE_2("Mennekes Type 2 (AC)"),
    CHADEMO("CHAdeMO (DC Fast)"),
    GB_T("GB/T (DC Fast)");

    private final String displayName;

    ConnectorType(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}
