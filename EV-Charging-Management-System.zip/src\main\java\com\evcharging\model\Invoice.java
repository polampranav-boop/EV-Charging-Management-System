package com.evcharging.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;

/**
 * Invoice Entity encapsulates financial calculations for completed EV charging.
 * Implements GST breakdown, rate calculation, and polymorphic payment settlement.
 */
@Entity
@Table(name = "invoices")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Invoice extends BaseEntity {

    @Column(name = "invoice_number", nullable = false, unique = true, length = 50)
    private String invoiceNumber;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "session_id", nullable = false)
    @JsonIgnore
    private ChargingSession session;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "driver_id", nullable = false)
    private EVDriver driver;

    @Column(name = "units_consumed_kwh", nullable = false)
    private Double unitsConsumedKwh;

    @Column(name = "rate_per_kwh", nullable = false)
    private Double ratePerKwh;

    @Column(name = "base_amount", precision = 10, scale = 2, nullable = false)
    private BigDecimal baseAmount;

    @Column(name = "gst_rate_percent")
    private Double gstRatePercent;

    @Column(name = "gst_amount", precision = 10, scale = 2, nullable = false)
    private BigDecimal gstAmount;

    @Column(name = "convenience_fee", precision = 10, scale = 2)
    private BigDecimal convenienceFee;

    @Column(name = "discount_amount", precision = 10, scale = 2)
    private BigDecimal discountAmount;

    @Column(name = "total_amount", precision = 10, scale = 2, nullable = false)
    private BigDecimal totalAmount;

    @Column(name = "payment_status", nullable = false, length = 30)
    private String paymentStatus;

    @Enumerated(EnumType.STRING)
    @Column(name = "payment_method", length = 30)
    private PaymentType paymentMethod;

    @Column(name = "payment_transaction_id", length = 100)
    private String paymentTransactionId;

    @Column(name = "invoice_date")
    private LocalDateTime invoiceDate;

    public Invoice() {
        super();
        this.gstRatePercent = 18.0; // Standard 18% GST for EV charging service in India
        this.convenienceFee = BigDecimal.ZERO;
        this.discountAmount = BigDecimal.ZERO;
        this.paymentStatus = "PENDING";
        this.invoiceDate = LocalDateTime.now();
    }

    public Invoice(String invoiceNumber, ChargingSession session, EVDriver driver,
                   Double unitsConsumedKwh, Double ratePerKwh) {
        super();
        this.invoiceNumber = invoiceNumber;
        this.session = session;
        this.driver = driver;
        this.unitsConsumedKwh = Math.max(unitsConsumedKwh != null ? unitsConsumedKwh : 0.0, 0.1);
        this.ratePerKwh = ratePerKwh != null ? ratePerKwh : 18.0;
        this.gstRatePercent = 18.0;
        this.convenienceFee = BigDecimal.ZERO;
        this.discountAmount = BigDecimal.ZERO;
        this.paymentStatus = "PENDING";
        this.invoiceDate = LocalDateTime.now();
        calculateBill();
    }

    // Encapsulated billing computation
    public void calculateBill() {
        double rawBase = this.unitsConsumedKwh * this.ratePerKwh;
        this.baseAmount = BigDecimal.valueOf(rawBase).setScale(2, RoundingMode.HALF_UP);
        double rawGst = rawBase * (this.gstRatePercent / 100.0);
        this.gstAmount = BigDecimal.valueOf(rawGst).setScale(2, RoundingMode.HALF_UP);
        BigDecimal subTotal = this.baseAmount.add(this.gstAmount)
                .add(this.convenienceFee != null ? this.convenienceFee : BigDecimal.ZERO);
        BigDecimal discount = this.discountAmount != null ? this.discountAmount : BigDecimal.ZERO;
        this.totalAmount = subTotal.subtract(discount).max(BigDecimal.ZERO).setScale(2, RoundingMode.HALF_UP);
    }

    // Encapsulation: Getters and Setters
    public String getInvoiceNumber() {
        return invoiceNumber;
    }

    public void setInvoiceNumber(String invoiceNumber) {
        this.invoiceNumber = invoiceNumber;
    }

    public ChargingSession getSession() {
        return session;
    }

    public void setSession(ChargingSession session) {
        this.session = session;
    }

    public EVDriver getDriver() {
        return driver;
    }

    public void setDriver(EVDriver driver) {
        this.driver = driver;
    }

    public Double getUnitsConsumedKwh() {
        return unitsConsumedKwh;
    }

    public void setUnitsConsumedKwh(Double unitsConsumedKwh) {
        this.unitsConsumedKwh = unitsConsumedKwh;
        calculateBill();
    }

    public Double getRatePerKwh() {
        return ratePerKwh;
    }

    public void setRatePerKwh(Double ratePerKwh) {
        this.ratePerKwh = ratePerKwh;
        calculateBill();
    }

    public BigDecimal getBaseAmount() {
        return baseAmount;
    }

    public void setBaseAmount(BigDecimal baseAmount) {
        this.baseAmount = baseAmount;
    }

    public Double getGstRatePercent() {
        return gstRatePercent;
    }

    public void setGstRatePercent(Double gstRatePercent) {
        this.gstRatePercent = gstRatePercent;
    }

    public BigDecimal getGstAmount() {
        return gstAmount;
    }

    public void setGstAmount(BigDecimal gstAmount) {
        this.gstAmount = gstAmount;
    }

    public BigDecimal getConvenienceFee() {
        return convenienceFee;
    }

    public void setConvenienceFee(BigDecimal convenienceFee) {
        this.convenienceFee = convenienceFee;
    }

    public BigDecimal getDiscountAmount() {
        return discountAmount;
    }

    public void setDiscountAmount(BigDecimal discountAmount) {
        this.discountAmount = discountAmount;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public PaymentType getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(PaymentType paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getPaymentTransactionId() {
        return paymentTransactionId;
    }

    public void setPaymentTransactionId(String paymentTransactionId) {
        this.paymentTransactionId = paymentTransactionId;
    }

    public LocalDateTime getInvoiceDate() {
        return invoiceDate;
    }

    public void setInvoiceDate(LocalDateTime invoiceDate) {
        this.invoiceDate = invoiceDate;
    }
}
