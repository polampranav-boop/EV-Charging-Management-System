package com.evcharging.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDateTime;

/**
 * ChargingSession Entity models real-time EV charging state and simulation metrics.
 */
@Entity
@Table(name = "charging_sessions")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class ChargingSession extends BaseEntity {

    @Column(name = "session_reference", nullable = false, unique = true, length = 40)
    private String sessionReference;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "booking_id")
    private Booking booking;

    @NotNull(message = "Driver is required")
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "driver_id", nullable = false)
    private EVDriver driver;

    @NotNull(message = "Charger is required")
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "charger_id", nullable = false)
    private Charger charger;

    @NotNull(message = "Station is required")
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "station_id", nullable = false)
    private Station station;

    @NotNull
    @Column(name = "start_time", nullable = false)
    private LocalDateTime startTime;

    @Column(name = "end_time")
    private LocalDateTime endTime;

    @Column(name = "initial_battery_percent")
    private Double initialBatteryPercent;

    @Column(name = "current_battery_percent")
    private Double currentBatteryPercent;

    @Column(name = "target_battery_percent")
    private Double targetBatteryPercent;

    @Column(name = "units_consumed_kwh")
    private Double unitsConsumedKwh;

    @Column(name = "charging_rate_per_kwh")
    private Double chargingRatePerKwh;

    @Column(name = "active_power_kw")
    private Double activePowerKw;

    @Enumerated(EnumType.STRING)
    @Column(name = "session_status", nullable = false, length = 30)
    private SessionStatus sessionStatus;

    @OneToOne(mappedBy = "session", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private Invoice invoice;

    public ChargingSession() {
        super();
        this.sessionStatus = SessionStatus.ACTIVE;
        this.startTime = LocalDateTime.now();
        this.unitsConsumedKwh = 0.0;
        this.initialBatteryPercent = 20.0;
        this.currentBatteryPercent = 20.0;
        this.targetBatteryPercent = 90.0;
    }

    public ChargingSession(String sessionReference, Booking booking, EVDriver driver,
                           Charger charger, Station station, Double initialBatteryPercent,
                           Double targetBatteryPercent) {
        super();
        this.sessionReference = sessionReference;
        this.booking = booking;
        this.driver = driver;
        this.charger = charger;
        this.station = station;
        this.startTime = LocalDateTime.now();
        this.initialBatteryPercent = initialBatteryPercent != null ? initialBatteryPercent : 20.0;
        this.currentBatteryPercent = this.initialBatteryPercent;
        this.targetBatteryPercent = targetBatteryPercent != null ? targetBatteryPercent : 85.0;
        this.unitsConsumedKwh = 0.0;
        this.chargingRatePerKwh = charger.getRatePerKwh();
        this.activePowerKw = charger.getPowerRatingKw();
        this.sessionStatus = SessionStatus.ACTIVE;
    }

    // Encapsulation: Getters and Setters
    public String getSessionReference() {
        return sessionReference;
    }

    public void setSessionReference(String sessionReference) {
        this.sessionReference = sessionReference;
    }

    public Booking getBooking() {
        return booking;
    }

    public void setBooking(Booking booking) {
        this.booking = booking;
    }

    public EVDriver getDriver() {
        return driver;
    }

    public void setDriver(EVDriver driver) {
        this.driver = driver;
    }

    public Charger getCharger() {
        return charger;
    }

    public void setCharger(Charger charger) {
        this.charger = charger;
    }

    public Station getStation() {
        return station;
    }

    public void setStation(Station station) {
        this.station = station;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }

    public Double getInitialBatteryPercent() {
        return initialBatteryPercent;
    }

    public void setInitialBatteryPercent(Double initialBatteryPercent) {
        this.initialBatteryPercent = initialBatteryPercent;
    }

    public Double getCurrentBatteryPercent() {
        return currentBatteryPercent;
    }

    public void setCurrentBatteryPercent(Double currentBatteryPercent) {
        this.currentBatteryPercent = currentBatteryPercent;
    }

    public Double getTargetBatteryPercent() {
        return targetBatteryPercent;
    }

    public void setTargetBatteryPercent(Double targetBatteryPercent) {
        this.targetBatteryPercent = targetBatteryPercent;
    }

    public Double getUnitsConsumedKwh() {
        return unitsConsumedKwh;
    }

    public void setUnitsConsumedKwh(Double unitsConsumedKwh) {
        this.unitsConsumedKwh = unitsConsumedKwh;
    }

    public Double getChargingRatePerKwh() {
        return chargingRatePerKwh;
    }

    public void setChargingRatePerKwh(Double chargingRatePerKwh) {
        this.chargingRatePerKwh = chargingRatePerKwh;
    }

    public Double getActivePowerKw() {
        return activePowerKw;
    }

    public void setActivePowerKw(Double activePowerKw) {
        this.activePowerKw = activePowerKw;
    }

    public SessionStatus getSessionStatus() {
        return sessionStatus;
    }

    public void setSessionStatus(SessionStatus sessionStatus) {
        this.sessionStatus = sessionStatus;
    }

    public Invoice getInvoice() {
        return invoice;
    }

    public void setInvoice(Invoice invoice) {
        this.invoice = invoice;
    }
}
