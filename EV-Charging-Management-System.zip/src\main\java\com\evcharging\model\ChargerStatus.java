package com.evcharging.model;

public enum ChargerStatus {
    AVAILABLE,
    OCCUPIED,
    MAINTENANCE,
    OUT_OF_SERVICE
}
