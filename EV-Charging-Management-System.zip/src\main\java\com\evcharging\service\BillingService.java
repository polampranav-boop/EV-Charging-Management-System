package com.evcharging.service;

import com.evcharging.exception.ResourceNotFoundException;
import com.evcharging.model.Invoice;
import com.evcharging.repository.InvoiceRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Transactional
public class BillingService {

    private final InvoiceRepository invoiceRepository;

    public BillingService(InvoiceRepository invoiceRepository) {
        this.invoiceRepository = invoiceRepository;
    }

    @Transactional(readOnly = true)
    public Invoice getInvoiceById(Long id) {
        return invoiceRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Invoice not found with ID: " + id));
    }

    @Transactional(readOnly = true)
    public Invoice getInvoiceByNumber(String invoiceNumber) {
        return invoiceRepository.findByInvoiceNumber(invoiceNumber)
                .orElseThrow(() -> new ResourceNotFoundException("Invoice not found with number: " + invoiceNumber));
    }

    @Transactional(readOnly = true)
    public List<Invoice> getInvoicesByDriver(Long driverId) {
        return invoiceRepository.findByDriverIdOrderByInvoiceDateDesc(driverId);
    }

    @Transactional(readOnly = true)
    public List<Invoice> getAllInvoices() {
        return invoiceRepository.findAll();
    }

    public Map<String, Object> calculateEstimate(Double unitsKwh, Double ratePerKwh) {
        double units = unitsKwh != null ? unitsKwh : 20.0;
        double rate = ratePerKwh != null ? ratePerKwh : 18.0;
        double base = units * rate;
        double gst = base * 0.18;
        double total = base + gst;

        Map<String, Object> map = new HashMap<>();
        map.put("unitsKwh", units);
        map.put("ratePerKwh", rate);
        map.put("baseAmount", BigDecimal.valueOf(base).setScale(2, RoundingMode.HALF_UP));
        map.put("gstRate", 18.0);
        map.put("gstAmount", BigDecimal.valueOf(gst).setScale(2, RoundingMode.HALF_UP));
        map.put("totalPayable", BigDecimal.valueOf(total).setScale(2, RoundingMode.HALF_UP));
        return map;
    }
}
