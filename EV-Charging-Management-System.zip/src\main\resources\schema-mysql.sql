-- ===================================================================
-- VoltPulse - EV Charging Management System
-- MySQL Relational Database Schema & Setup Script
-- BTech CSE PBL Project
-- ===================================================================

CREATE DATABASE IF NOT EXISTS ev_charging_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE ev_charging_db;

-- 1. Base Users Table (Inheritance: Root of Admin and EVDriver)
CREATE TABLE IF NOT EXISTS users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(120) NOT NULL UNIQUE,
    phone VARCHAR(20) NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 2. Admins Subclass Table (Inheritance: Joined Subclass)
CREATE TABLE IF NOT EXISTS admins (
    id BIGINT PRIMARY KEY,
    department VARCHAR(80),
    employee_code VARCHAR(30),
    admin_level VARCHAR(30),
    CONSTRAINT fk_admin_user FOREIGN KEY (id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 3. EV Drivers Subclass Table (Inheritance: Joined Subclass)
CREATE TABLE IF NOT EXISTS ev_drivers (
    id BIGINT PRIMARY KEY,
    vehicle_model VARCHAR(80),
    vehicle_registration_number VARCHAR(30),
    battery_capacity_kwh DOUBLE,
    preferred_connector_type VARCHAR(30),
    wallet_balance DECIMAL(10,2) DEFAULT 500.00,
    CONSTRAINT fk_driver_user FOREIGN KEY (id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 4. Stations Table
CREATE TABLE IF NOT EXISTS stations (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    address VARCHAR(255) NOT NULL,
    area VARCHAR(80) NOT NULL,
    city VARCHAR(80) NOT NULL,
    latitude DOUBLE NOT NULL,
    longitude DOUBLE NOT NULL,
    operating_hours VARCHAR(80),
    contact_phone VARCHAR(30),
    amenities VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 5. Chargers / Dispensers Table
CREATE TABLE IF NOT EXISTS chargers (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    station_id BIGINT NOT NULL,
    identifier VARCHAR(50) NOT NULL,
    connector_type VARCHAR(30) NOT NULL,
    power_rating_kw DOUBLE NOT NULL,
    rate_per_kwh DOUBLE NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'AVAILABLE',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_charger_station FOREIGN KEY (station_id) REFERENCES stations(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 6. Slot Bookings Table
CREATE TABLE IF NOT EXISTS bookings (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    booking_reference VARCHAR(40) NOT NULL UNIQUE,
    driver_id BIGINT NOT NULL,
    station_id BIGINT NOT NULL,
    charger_id BIGINT NOT NULL,
    start_time DATETIME NOT NULL,
    end_time DATETIME NOT NULL,
    duration_minutes INT,
    status VARCHAR(30) NOT NULL,
    estimated_kwh DOUBLE,
    estimated_cost DECIMAL(10,2),
    cancellation_reason VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_booking_driver FOREIGN KEY (driver_id) REFERENCES ev_drivers(id),
    CONSTRAINT fk_booking_station FOREIGN KEY (station_id) REFERENCES stations(id),
    CONSTRAINT fk_booking_charger FOREIGN KEY (charger_id) REFERENCES chargers(id)
) ENGINE=InnoDB;

-- 7. Charging Sessions Table
CREATE TABLE IF NOT EXISTS charging_sessions (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    session_reference VARCHAR(40) NOT NULL UNIQUE,
    booking_id BIGINT,
    driver_id BIGINT NOT NULL,
    charger_id BIGINT NOT NULL,
    station_id BIGINT NOT NULL,
    start_time DATETIME NOT NULL,
    end_time DATETIME,
    initial_battery_percent DOUBLE,
    current_battery_percent DOUBLE,
    target_battery_percent DOUBLE,
    units_consumed_kwh DOUBLE,
    charging_rate_per_kwh DOUBLE,
    active_power_kw DOUBLE,
    session_status VARCHAR(30) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_session_booking FOREIGN KEY (booking_id) REFERENCES bookings(id),
    CONSTRAINT fk_session_driver FOREIGN KEY (driver_id) REFERENCES ev_drivers(id),
    CONSTRAINT fk_session_charger FOREIGN KEY (charger_id) REFERENCES chargers(id),
    CONSTRAINT fk_session_station FOREIGN KEY (station_id) REFERENCES stations(id)
) ENGINE=InnoDB;

-- 8. Tax Invoices Table
CREATE TABLE IF NOT EXISTS invoices (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    invoice_number VARCHAR(50) NOT NULL UNIQUE,
    session_id BIGINT NOT NULL,
    driver_id BIGINT NOT NULL,
    units_consumed_kwh DOUBLE NOT NULL,
    rate_per_kwh DOUBLE NOT NULL,
    base_amount DECIMAL(10,2) NOT NULL,
    gst_rate_percent DOUBLE DEFAULT 18.0,
    gst_amount DECIMAL(10,2) NOT NULL,
    convenience_fee DECIMAL(10,2) DEFAULT 0.00,
    discount_amount DECIMAL(10,2) DEFAULT 0.00,
    total_amount DECIMAL(10,2) NOT NULL,
    payment_status VARCHAR(30) NOT NULL,
    payment_method VARCHAR(30),
    payment_transaction_id VARCHAR(100),
    invoice_date DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_invoice_session FOREIGN KEY (session_id) REFERENCES charging_sessions(id),
    CONSTRAINT fk_invoice_driver FOREIGN KEY (driver_id) REFERENCES ev_drivers(id)
) ENGINE=InnoDB;

-- 9. Polymorphic Payment Records Table
CREATE TABLE IF NOT EXISTS payment_records (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    transaction_reference VARCHAR(60) NOT NULL UNIQUE,
    invoice_id BIGINT NOT NULL,
    payment_type VARCHAR(30) NOT NULL,
    amount_paid DECIMAL(10,2) NOT NULL,
    fee_applied DECIMAL(10,2) DEFAULT 0.00,
    gateway_status VARCHAR(30) NOT NULL,
    payment_timestamp DATETIME NOT NULL,
    remarks VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_payment_invoice FOREIGN KEY (invoice_id) REFERENCES invoices(id)
) ENGINE=InnoDB;
